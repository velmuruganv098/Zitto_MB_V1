################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../DEBUG/debug_rtt.c 

O_SRCS += \
../DEBUG/debug_rtt.o \
../DEBUG/exception_debug.o 

OBJS += \
./DEBUG/debug_rtt.o 

C_DEPS += \
./DEBUG/debug_rtt.d 


# Each subdirectory must supply rules for building sources it contributes
DEBUG/%.o: ../DEBUG/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@DEBUG/debug_rtt.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


