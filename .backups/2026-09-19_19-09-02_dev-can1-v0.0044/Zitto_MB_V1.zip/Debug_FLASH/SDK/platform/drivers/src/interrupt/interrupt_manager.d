SDK/platform/drivers/src/interrupt/interrupt_manager.o: \
 ../SDK/platform/drivers/src/interrupt/interrupt_manager.c \
 C:/Projects/Zitto_MB_V1/SDK/platform/drivers/inc/interrupt_manager.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/device_registers.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/devassert.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/startup.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/device_registers.h

C:/Projects/Zitto_MB_V1/SDK/platform/drivers/inc/interrupt_manager.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/device_registers.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/common/s32_core_cm4.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/devassert.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/startup.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/device_registers.h:
