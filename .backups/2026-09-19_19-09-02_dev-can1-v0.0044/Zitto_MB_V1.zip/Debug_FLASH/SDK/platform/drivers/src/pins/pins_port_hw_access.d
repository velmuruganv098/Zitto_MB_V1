SDK/platform/drivers/src/pins/pins_port_hw_access.o: \
 ../SDK/platform/drivers/src/pins/pins_port_hw_access.c \
 ../SDK/platform/drivers/src/pins/pins_port_hw_access.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/drivers/inc/pins_driver.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/device_registers.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/devassert.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/status.h \
 ../SDK/platform/drivers/src/pins/pins_gpio_hw_access.h

../SDK/platform/drivers/src/pins/pins_port_hw_access.h:

C:/Projects/Zitto_MB_V1/SDK/platform/drivers/inc/pins_driver.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/device_registers.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/common/s32_core_cm4.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/devassert.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/status.h:

../SDK/platform/drivers/src/pins/pins_gpio_hw_access.h:
