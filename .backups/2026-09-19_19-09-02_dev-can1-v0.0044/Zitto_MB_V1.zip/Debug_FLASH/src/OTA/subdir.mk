################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/OTA/ota.c 

OBJS += \
./src/OTA/ota.o 

C_DEPS += \
./src/OTA/ota.d 


# Each subdirectory must supply rules for building sources it contributes
src/OTA/%.o: ../src/OTA/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/OTA/ota.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


