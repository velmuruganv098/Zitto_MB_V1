src/OTA/ota.o: ../src/OTA/ota.c C:/Projects/Zitto_MB_V1/src/OTA/ota.h \
 ../src/OTA/../APP/app_config.h ../src/OTA/../APP/app_status.h \
 ../src/OTA/../FLM/flm.h C:/Projects/Zitto_MB_V1/DEBUG/debug_rtt.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_ConfDefaults.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_Conf.h

C:/Projects/Zitto_MB_V1/src/OTA/ota.h:

../src/OTA/../APP/app_config.h:

../src/OTA/../APP/app_status.h:

../src/OTA/../FLM/flm.h:

C:/Projects/Zitto_MB_V1/DEBUG/debug_rtt.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_ConfDefaults.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_Conf.h:
