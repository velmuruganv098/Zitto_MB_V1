################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/boot_main.c \
../src/libc_compat.c \
../src/main.c \
../src/system_init.c 

OBJS += \
./src/boot_main.o \
./src/libc_compat.o \
./src/main.o \
./src/system_init.o 

C_DEPS += \
./src/boot_main.d \
./src/libc_compat.d \
./src/main.d \
./src/system_init.d 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/boot_main.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


