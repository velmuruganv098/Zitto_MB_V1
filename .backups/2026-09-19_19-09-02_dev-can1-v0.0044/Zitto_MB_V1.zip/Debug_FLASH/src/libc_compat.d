src/libc_compat.o: ../src/libc_compat.c
