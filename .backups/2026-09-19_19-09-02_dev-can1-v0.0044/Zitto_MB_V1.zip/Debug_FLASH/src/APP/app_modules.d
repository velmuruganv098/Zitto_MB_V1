src/APP/app_modules.o: ../src/APP/app_modules.c \
 C:/Projects/Zitto_MB_V1/src/APP/app_modules.h ../src/APP/app_config.h

C:/Projects/Zitto_MB_V1/src/APP/app_modules.h:

../src/APP/app_config.h:
