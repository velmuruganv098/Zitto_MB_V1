src/APP/app_main.o: ../src/APP/app_main.c ../src/APP/app_main.h \
 ../src/APP/../UART/uart_pkt_types.h ../src/APP/app_config.h \
 ../src/APP/../UART/uart_pkt.h ../src/APP/../UART/uart_pkt_types.h \
 ../src/APP/../CMD/cmd.h ../src/APP/../CMD/../UART/uart_pkt.h \
 ../src/APP/../CAN/can1.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h \
 ../src/APP/../CAN/can2.h ../src/APP/../GPIO/gpio_control.h \
 ../src/APP/../GPIO/../UART/uart_pkt.h ../src/APP/../IMU/imu.h \
 ../src/APP/../IMU/../UART/uart_pkt_types.h ../src/APP/../OTA/ota.h \
 ../src/APP/../FLM/flm.h ../src/APP/app_status.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/device_registers.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/devassert.h \
 C:/Projects/Zitto_MB_V1/src/APP/app_modules.h \
 C:/Projects/Zitto_MB_V1/DEBUG/debug_rtt.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_ConfDefaults.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_Conf.h

../src/APP/app_main.h:

../src/APP/../UART/uart_pkt_types.h:

../src/APP/app_config.h:

../src/APP/../UART/uart_pkt.h:

../src/APP/../UART/uart_pkt_types.h:

../src/APP/../CMD/cmd.h:

../src/APP/../CMD/../UART/uart_pkt.h:

../src/APP/../CAN/can1.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h:

../src/APP/../CAN/can2.h:

../src/APP/../GPIO/gpio_control.h:

../src/APP/../GPIO/../UART/uart_pkt.h:

../src/APP/../IMU/imu.h:

../src/APP/../IMU/../UART/uart_pkt_types.h:

../src/APP/../OTA/ota.h:

../src/APP/../FLM/flm.h:

../src/APP/app_status.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/device_registers.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/common/s32_core_cm4.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/devassert.h:

C:/Projects/Zitto_MB_V1/src/APP/app_modules.h:

C:/Projects/Zitto_MB_V1/DEBUG/debug_rtt.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_ConfDefaults.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_Conf.h:
