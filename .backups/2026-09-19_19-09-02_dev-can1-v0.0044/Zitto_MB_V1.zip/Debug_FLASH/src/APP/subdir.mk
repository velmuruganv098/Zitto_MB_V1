################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/APP/app_main.c \
../src/APP/app_modules.c \
../src/APP/app_status.c 

OBJS += \
./src/APP/app_main.o \
./src/APP/app_modules.o \
./src/APP/app_status.o 

C_DEPS += \
./src/APP/app_main.d \
./src/APP/app_modules.d \
./src/APP/app_status.d 


# Each subdirectory must supply rules for building sources it contributes
src/APP/%.o: ../src/APP/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/APP/app_main.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


