################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/CSA/csa.c 

OBJS += \
./src/CSA/csa.o 

C_DEPS += \
./src/CSA/csa.d 


# Each subdirectory must supply rules for building sources it contributes
src/CSA/%.o: ../src/CSA/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/CSA/csa.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


