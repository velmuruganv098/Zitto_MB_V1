src/CSA/csa.o: ../src/CSA/csa.c ../src/CSA/csa.h \
 ../src/CSA/../UART/uart_pkt.h ../src/CSA/../UART/uart_pkt_types.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_ConfDefaults.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_Conf.h \
 C:/Projects/Zitto_MB_V1/DEBUG/debug_rtt.h

../src/CSA/csa.h:

../src/CSA/../UART/uart_pkt.h:

../src/CSA/../UART/uart_pkt_types.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_ConfDefaults.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_Conf.h:

C:/Projects/Zitto_MB_V1/DEBUG/debug_rtt.h:
