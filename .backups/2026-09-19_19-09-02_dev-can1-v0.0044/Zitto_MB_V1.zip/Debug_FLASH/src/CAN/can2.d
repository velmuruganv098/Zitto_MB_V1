src/CAN/can2.o: ../src/CAN/can2.c ../src/CAN/can2.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h \
 c:\projects\zitto_mb_v1\debug\debug_rtt.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_ConfDefaults.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_Conf.h

../src/CAN/can2.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h:

c:\projects\zitto_mb_v1\debug\debug_rtt.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_ConfDefaults.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_Conf.h:
