################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/CAN/can1.c \
../src/CAN/can1_irq.c \
../src/CAN/can2.c 

OBJS += \
./src/CAN/can1.o \
./src/CAN/can1_irq.o \
./src/CAN/can2.o 

C_DEPS += \
./src/CAN/can1.d \
./src/CAN/can1_irq.d \
./src/CAN/can2.d 


# Each subdirectory must supply rules for building sources it contributes
src/CAN/%.o: ../src/CAN/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/CAN/can1.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


