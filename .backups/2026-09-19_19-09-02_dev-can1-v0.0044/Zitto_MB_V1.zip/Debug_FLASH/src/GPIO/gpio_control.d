src/GPIO/gpio_control.o: ../src/GPIO/gpio_control.c \
 ../src/GPIO/gpio_control.h \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h \
 ../src/GPIO/../UART/uart_pkt.h ../src/GPIO/../UART/uart_pkt_types.h \
 C:/Projects/Zitto_MB_V1/src/UART/uart_pkt.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_ConfDefaults.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_Conf.h \
 C:/Projects/Zitto_MB_V1/DEBUG/debug_rtt.h

../src/GPIO/gpio_control.h:

C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h:

../src/GPIO/../UART/uart_pkt.h:

../src/GPIO/../UART/uart_pkt_types.h:

C:/Projects/Zitto_MB_V1/src/UART/uart_pkt.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_ConfDefaults.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_Conf.h:

C:/Projects/Zitto_MB_V1/DEBUG/debug_rtt.h:
