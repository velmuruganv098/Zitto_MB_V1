src/system_init.o: ../src/system_init.c \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h \
 ../src/system_init.h

C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h:

../src/system_init.h:
