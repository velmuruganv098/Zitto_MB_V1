src/boot_main.o: ../src/boot_main.c ../src/boot_main.h \
 C:/Projects/Zitto_MB_V1/DEBUG/debug_rtt.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_ConfDefaults.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_Conf.h

../src/boot_main.h:

C:/Projects/Zitto_MB_V1/DEBUG/debug_rtt.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_ConfDefaults.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_Conf.h:
