src/UART/uart_pkt.o: ../src/UART/uart_pkt.c \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h \
 ../src/UART/uart_pkt.h ../src/UART/uart_pkt_types.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_ConfDefaults.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_Conf.h \
 C:/Projects/Zitto_MB_V1/DEBUG/debug_rtt.h

C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h:

../src/UART/uart_pkt.h:

../src/UART/uart_pkt_types.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_ConfDefaults.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_Conf.h:

C:/Projects/Zitto_MB_V1/DEBUG/debug_rtt.h:
