src/main.o: ../src/main.c \
 C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_ConfDefaults.h \
 C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_Conf.h ../src/system_init.h \
 ../src/UART/uart_pkt.h ../src/UART/uart_pkt_types.h ../src/IMU/imu.h \
 ../src/IMU/../UART/uart_pkt_types.h ../src/CSA/csa.h \
 ../src/CSA/../UART/uart_pkt.h ../src/CAN/can1.h ../src/CAN/can2.h \
 ../src/FLM/flm.h ../src/OTA/ota.h ../src/GPIO/gpio_control.h \
 ../src/GPIO/../UART/uart_pkt.h C:/Projects/Zitto_MB_V1/DEBUG/debug_rtt.h

C:/Projects/Zitto_MB_V1/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_ConfDefaults.h:

C:/Projects/Zitto_MB_V1/RTT/SEGGER_RTT_Conf.h:

../src/system_init.h:

../src/UART/uart_pkt.h:

../src/UART/uart_pkt_types.h:

../src/IMU/imu.h:

../src/IMU/../UART/uart_pkt_types.h:

../src/CSA/csa.h:

../src/CSA/../UART/uart_pkt.h:

../src/CAN/can1.h:

../src/CAN/can2.h:

../src/FLM/flm.h:

../src/OTA/ota.h:

../src/GPIO/gpio_control.h:

../src/GPIO/../UART/uart_pkt.h:

C:/Projects/Zitto_MB_V1/DEBUG/debug_rtt.h:
