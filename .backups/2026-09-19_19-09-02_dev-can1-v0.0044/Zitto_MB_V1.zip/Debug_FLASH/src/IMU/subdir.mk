################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/IMU/imu.c 

OBJS += \
./src/IMU/imu.o 

C_DEPS += \
./src/IMU/imu.d 


# Each subdirectory must supply rules for building sources it contributes
src/IMU/%.o: ../src/IMU/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/IMU/imu.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


