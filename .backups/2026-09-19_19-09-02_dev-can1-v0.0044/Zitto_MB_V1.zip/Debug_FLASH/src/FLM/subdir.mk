################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/FLM/flm.c 

OBJS += \
./src/FLM/flm.o 

C_DEPS += \
./src/FLM/flm.d 


# Each subdirectory must supply rules for building sources it contributes
src/FLM/%.o: ../src/FLM/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: Standard S32DS C Compiler'
	arm-none-eabi-gcc "@src/FLM/flm.args" -MMD -MP -MF"$(@:%.o=%.d)" -MT"$(@)" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


