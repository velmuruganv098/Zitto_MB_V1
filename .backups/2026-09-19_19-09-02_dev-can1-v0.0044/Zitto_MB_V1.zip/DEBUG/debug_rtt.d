src/DEBUG/debug_rtt.o: ../src/DEBUG/debug_rtt.c ../src/DEBUG/debug_rtt.h \
 C:/Users/Velu/workspaceS32DS.3.4/Zitto_MB_V1/RTT/SEGGER_RTT.h \
 C:/Users/Velu/workspaceS32DS.3.4/Zitto_MB_V1/RTT/SEGGER_RTT_ConfDefaults.h \
 C:/Users/Velu/workspaceS32DS.3.4/Zitto_MB_V1/RTT/SEGGER_RTT_Conf.h

../src/DEBUG/debug_rtt.h:

C:/Users/Velu/workspaceS32DS.3.4/Zitto_MB_V1/RTT/SEGGER_RTT.h:

C:/Users/Velu/workspaceS32DS.3.4/Zitto_MB_V1/RTT/SEGGER_RTT_ConfDefaults.h:

C:/Users/Velu/workspaceS32DS.3.4/Zitto_MB_V1/RTT/SEGGER_RTT_Conf.h:
