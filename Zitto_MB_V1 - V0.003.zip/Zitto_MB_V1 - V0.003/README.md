Just initial code 
