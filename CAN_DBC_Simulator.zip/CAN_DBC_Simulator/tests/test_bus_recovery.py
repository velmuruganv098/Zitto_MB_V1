"""Bus-off recovery with a fake PCAN driver:  python tests/test_bus_recovery.py"""
import sys
import time
from pathlib import Path

import can

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from simulator.can_interface import BusManager          # noqa: E402

BUSOFF_MSG = "Failed to send: Bus error: the CAN controller is in bus-off state"


class FakePcan:
    """Mimics python-can PcanBus: status() codes, reset() = CAN_Reset, bus-off on send."""
    reset_clears = True
    opened = 0

    def __init__(self):
        FakePcan.opened += 1
        self.busoff = False

    def status(self):
        return 0x10 if self.busoff else 0x0

    def reset(self):
        if FakePcan.reset_clears:
            self.busoff = False
        return True

    def send(self, msg, timeout=None):
        if self.busoff:
            raise can.CanOperationError(BUSOFF_MSG)

    def recv(self, timeout=None):
        time.sleep(timeout or 0.01)
        return None

    def shutdown(self):
        pass

    @property
    def state(self):
        return can.BusState.ACTIVE


def make():
    bm = BusManager()
    bm._open = lambda: FakePcan()
    bm.connect("pcan", "PCAN_USBBUS1", 500)
    return bm


FRAME = can.Message(arbitration_id=0x123, data=[1, 2, 3])


def test_manual_reset_uses_can_reset():
    FakePcan.reset_clears = True
    bm = make()
    bm.auto_recover = False
    bm._bus.busoff = True
    assert not bm.send(FRAME) and bm._bus_off
    assert bm.status()["state"] == "BUS OFF"
    opened = FakePcan.opened
    res = bm.reset()
    assert res["ok"], res
    assert any("CAN_Reset -> OK" in s for s in res["steps"])
    assert FakePcan.opened == opened                    # no re-init needed
    assert bm.send(FRAME) and bm.status()["level"] == "ok"
    bm.disconnect()


def test_reset_falls_back_to_reinit():
    FakePcan.reset_clears = False                       # controller stays bus-off after CAN_Reset
    bm = make()
    bm.auto_recover = False
    bm._bus.busoff = True
    opened = FakePcan.opened
    res = bm.reset()
    assert res["ok"], res
    assert FakePcan.opened == opened + 1 and any("re-initialised" in s for s in res["steps"])
    assert bm.send(FRAME)
    bm.disconnect()


def test_auto_recovery_watchdog():
    FakePcan.reset_clears = True
    bm = make()
    bm.auto_recover = True
    bm._bus.busoff = True
    bm.send(FRAME)                                      # driver reports bus-off
    t0 = time.time()
    while time.time() - t0 < 3 and (bm._bus_off or bm.recoveries == 0):
        time.sleep(0.05)
    assert bm.recoveries >= 1 and not bm._bus_off, bm.status()
    assert bm.send(FRAME)
    assert bm.status()["recovery_log"]
    bm.disconnect()


if __name__ == "__main__":
    for fn in [v for k, v in dict(globals()).items() if k.startswith("test_")]:
        t = time.time()
        fn()
        print(f"PASS {fn.__name__} ({time.time() - t:.1f}s)")
