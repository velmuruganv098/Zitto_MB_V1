"""Battery model physics tests:  python tests/test_battery_model.py"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from simulator import dbc_library                       # noqa: E402
from simulator.battery_model import BatteryModel, ocv, soc_from_ocv  # noqa: E402
from simulator.can_interface import BusManager          # noqa: E402
from simulator.engine import Engine                     # noqa: E402

TEC = "BMS/TEC_EnergyCompany/TEC_CAN_V3_5_1Sept23_CAN_speed_250Kbps.dbc"
DALY = "BMS/Daly/Daly_BMS_CAN_V1.0_from_spec.dbc"


def run(bm, sim_seconds, dt=1.0):
    """Advance the model by sim_seconds of simulated time."""
    steps = int(sim_seconds / (dt * bm.cfg["time_scale"]))
    for _ in range(steps):
        bm.step(dt)


def test_inverse_ocv():
    for chem in ("NMC", "LFP"):
        for soc in (5, 20, 50, 80, 95):
            assert abs(soc_from_ocv(chem, ocv(chem, soc)) - soc) < 0.01


def test_balancing_time_matches_bleed_current():
    bm = BatteryModel()
    bm.configure(enabled=True, capacity_ah=10, capacity_spread_pct=0, mode="rest", bal_when="always",
                 bal_start_mv=20, bal_stop_mv=5, bal_current_ma=100, bal_min_v=3.0, time_scale=600)
    v = [3.90] * 8
    v[3] = 3.95                                           # one high cell
    bm.reset(v, [30.0])
    excess_ah = (bm.cells[3]["soc"] - bm.cells[0]["soc"]) / 100 * 10
    predicted_h = excess_ah / 0.1
    eta = bm.balance_eta_s() / 3600
    assert abs(eta - predicted_h) < 0.01
    t0 = None
    for _ in range(200000):
        bm.step(1.0)
        if bm.bal_session and t0 is None:
            t0 = bm.sim_time
        if t0 is not None and not bm.bal_session:
            break
    took_h = (bm.sim_time - t0) / 3600
    # stops at the 5 mV stop delta, so slightly less than the full excess
    assert 0.5 * predicted_h < took_h <= predicted_h * 1.05, (took_h, predicted_h)
    assert bm.cells[3]["bleed"] is False
    print(f"    balancing: predicted {predicted_h:.2f} h, simulated {took_h:.2f} h (stop at 5 mV)")


def test_cc_cv_charge_finishes():
    bm = BatteryModel()
    bm.configure(enabled=True, capacity_ah=20, capacity_spread_pct=0, charge_a=10, time_scale=60, bal_enabled=False)
    bm.reset([3.6] * 4, [25.0])
    bm.configure(mode="charge")
    phases = set()
    for _ in range(20000):
        bm.step(1.0)
        phases.add(bm.phase)
        if bm.phase == "DONE":
            break
    assert {"CC", "CV", "DONE"} <= phases, phases
    assert max(bm.cell_v(c) for c in bm.cells) <= bm.cfg["cv_v"] + 0.02
    assert bm.pack_soc() > 90
    print(f"    CC-CV: done after {bm.sim_time / 3600:.2f} h, SOC {bm.pack_soc():.1f} %")


def test_discharge_stops_at_uv_and_sets_flags():
    eng = Engine(BusManager())
    eng.load(dbc_library.load(DALY), "BMS")
    eng.set_dynamics({"battery": {"enabled": True, "time_scale": 3600, "discharge_a": 50, "capacity_ah": 20,
                                  "bal_enabled": False}})
    eng.set_dynamics({"battery": {"mode": "discharge"}})
    for _ in range(400):
        with eng.lock:
            eng._step_dynamics(0.1)
        if eng.bm.phase == "UV STOP":
            break
    assert eng.bm.phase == "UV STOP" and "CELL_UV" in eng.bm.prot and not eng.bm.dsg_mos
    uv_sigs = eng._prot_sigs["CELL_UV"]
    assert uv_sigs, "Daly DBC should expose cell-low bits"
    assert all(eng.values[m][s] == 1 for m, s in uv_sigs)
    assert eng.role_values["bms.discharge_mos"] == 0
    print(f"    UV stop: {len(uv_sigs)} fault bits set, SOC {eng.bm.pack_soc():.1f} %")
    eng.shutdown()


def test_ui_edit_sticks_with_model_on():
    eng = Engine(BusManager())
    eng.load(dbc_library.load(TEC), "BMS")
    eng.set_dynamics({"battery": {"enabled": True, "mode": "rest", "bal_enabled": False}})
    eng.set_role(eng.analysis.cells[2], 3.95)
    eng.set_role(eng.analysis.temps[0], 44.0)
    with eng.lock:
        eng._step_dynamics(0.1)
    assert abs(eng.role_values[eng.analysis.cells[2]] - 3.95) < 0.003
    assert abs(eng.role_values[eng.analysis.temps[0]] - 44.0) < 0.1
    eng.shutdown()


def test_user_temperature_holds_at_high_time_scale():
    bm = BatteryModel()
    bm.configure(enabled=True, time_scale=3600, mode="rest")
    bm.reset([3.7] * 4, [30.0, 30.0])
    bm.set_temp(0, 55.0)
    for _ in range(50):
        bm.step(0.1)                                   # 5 simulated hours
    assert abs(bm.temps[0] - 55.0) < 0.5 and abs(bm.temps[1] - 30.0) < 0.5
    bm.configure(mode="discharge", discharge_a=100)
    for _ in range(10):
        bm.step(0.1)
    assert bm.temps[0] > 55.0                          # heating adds on top of the imposed value


if __name__ == "__main__":
    for fn in [v for k, v in dict(globals()).items() if k.startswith("test_")]:
        t = time.time()
        fn()
        print(f"PASS {fn.__name__} ({time.time() - t:.1f}s)")
