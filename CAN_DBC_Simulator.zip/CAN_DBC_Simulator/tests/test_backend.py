"""Backend tests - run with:  python -m pytest -q   (or  python tests/test_backend.py)"""
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from simulator import dbc_library                    # noqa: E402
from simulator.can_interface import BusManager       # noqa: E402
from simulator.engine import Engine, ocv             # noqa: E402
from simulator.server import create_app              # noqa: E402

TEC = "BMS/TEC_EnergyCompany/TEC_CAN_V3_5_1Sept23_CAN_speed_250Kbps.dbc"


def all_ids():
    return [f["id"] for s in dbc_library.list_library()["systems"] for f in s["files"]]


def test_every_library_dbc_loads_and_encodes():
    eng = Engine(BusManager())
    bad = []
    for dbc_id in all_ids():
        try:
            eng.load(dbc_library.load(dbc_id), dbc_id.split("/")[0])
            for name, info in eng.msgs.items():
                if info["supported"] and eng._build_frame(name, info) is None:
                    bad.append(f"{dbc_id}:{name}:{info.get('last_error')}")
            eng.model()
        except Exception as e:  # noqa: BLE001
            bad.append(f"{dbc_id}: {e}")
    eng.shutdown()
    assert len(bad) == 0, "\n".join(bad[:40])


def test_cells_drive_pack_voltage_and_stats():
    eng = Engine(BusManager())
    eng.load(dbc_library.load(TEC), "BMS")
    a = eng.analysis
    assert len(a.cells) == 20
    eng.set_role(a.cells[4], 3.9)
    eng.set_role(a.cells[7], 3.2)
    rv = eng.role_values
    assert abs(rv["bms.pack_voltage"] - (18 * 3.7 + 3.9 + 3.2)) < 0.01
    assert abs(rv["bms.max_cell_v"] - 3.9) < 1e-6 and rv.get("bms.min_cell_v") == 3.2
    # the CAN signal follows the role (TEC cell signals are in V, scale 0.001)
    b = a.roles[a.cells[4]].bindings[0]
    assert abs(eng.values[b.msg][b.sig] - 3.9) < 1e-6
    eng.shutdown()


def test_ocv_monotonic():
    for chem in ("NMC", "LFP", "LTO"):
        vals = [ocv(chem, s) for s in range(0, 101, 5)]
        assert vals == sorted(vals)


def test_virtual_bus_roundtrip():
    app = create_app()
    c = app.test_client()
    r = c.post("/api/dbc/load", json={"id": TEC}).get_json()
    assert r["ok"] and r["model"]["analysis"]["cells"]
    assert c.post("/api/bus/connect", json={"interface": "virtual", "channel": "vcan0",
                                           "bitrate_kbps": 250}).get_json()["ok"]
    c.post("/api/messages", json={"mode": "all"})
    c.post("/api/tx", json={"running": True})
    time.sleep(0.6)
    p = c.get("/api/poll?trace=1&msgs=1").get_json()
    assert p["bus"]["connected"] and p["bus"]["tx_frames"] > 10, p["bus"]
    assert p["trace"] and p["trace"][-1]["dir"] == "TX"
    c.post("/api/tx", json={"running": False})
    c.post("/api/bus/disconnect")
    app.extensions["sim"]["engine"].shutdown()


if __name__ == "__main__":
    for fn in [v for k, v in dict(globals()).items() if k.startswith("test_")]:
        t = time.time()
        fn()
        print(f"PASS {fn.__name__} ({time.time() - t:.1f}s)")
