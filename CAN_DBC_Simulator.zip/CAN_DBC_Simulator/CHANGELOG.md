# Changelog

All notable changes to the CAN DBC Simulator. Versioning: `MAJOR.MINOR.PATCH`
(`VERSION` file is the single source of truth - shown in the UI header and `/api/version`).

## [1.1.0] - 2026-09-25
### Battery simulator, bus-off recovery, spec-to-DBC conversion
- **Battery simulator** (`simulator/battery_model.py`): per-cell SOC / capacity (with spread) / internal resistance,
  V = OCV(SOC) - I*R with a low-SOC knee (NMC / LFP / LTO), modes Manual / Rest / Discharge / Charge CC-CV
  (CV taper, ends at C/20), time scale 1x ... 3600x, cycle counting, I2R heating with cooling to ambient.
- **Passive cell balancing in real time**: start / stop delta (mV), minimum cell voltage, bleed current (mA),
  when (charging / charging + idle / always); time to balance = excess Ah / bleed current, live delta, bleeding
  cells and ETA; balancing bits of the DBC are driven.
- **Protections** with hysteresis: cell OV -> charge MOS off, cell UV -> discharge MOS off (discharge stops),
  OT -> both off, UT -> charge off; matching fault bits of the DBC (e.g. Daly Cell_Volt_High_L1) are set.
- UI edits go into the model and stick: cell voltage -> that cell's SOC, pack SOC, current, MOSFETs,
  temperatures (held as an imposed offset on top of the modelled heating).
- **Bus-off recovery**: Reset = PCAN-Basic CAN_Reset (same as PCAN-View Reset, PCAN-View not needed); if the
  controller stays bus-off / passive / heavy the channel is re-initialised. Auto-recover (on by default):
  driver PCAN_BUSOFF_AUTORESET + watchdog with back-off, TX paused while bus-off, recovery log in the UI.
- **Fix: temperature (and other numeric) controls could not be changed** when the DBC value table only named
  special codes (NO_VALUE / ERROR / SNA): they were shown as drop-downs. Numeric vs enum is now decided once
  (`signal_kind`) for backend and UI; 2-bit state signals no longer bind to numeric roles.
- Controls keep the value you are dragging / typing (editing guard instead of focus checks); temperature cards
  have -/+ steppers and wider cells.
- **Spec conversion** (`tools/convert_bb_docs.py`): Daly BMS protocol, EF BMS 0.4, TEC V3.5 (PDF), River TEL
  PRD 3.6, Log9 immobilization, EzeeInfo J1939 PGNs -> `*_from_spec.dbc` (see BB CAN DBC/Converted_DBC/CONVERSION_REPORT.md).
- Tests: `tests/test_battery_model.py`, `tests/test_bus_recovery.py` (fake PCAN driver).

## [1.0.0] - 2026-09-25
### Initial release
- Local HTTP server (Flask) + Python backend, vanilla-JS web UI (no build step).
- DBC library `dbc_library/<System>/<Customer>/` seeded with the 183 unique DBCs from *BB CAN DBC*
  (55 byte-identical copies skipped, see `dbc_library/IMPORT_MANIFEST.csv`).
- System -> DBC drop-downs, DBC upload (validated, stored in the chosen System/Customer folder).
- Baud rate 125 / 250 / 500 / 1000 kbps, auto-suggested from the DBC / file name / system.
- PEAK PCAN (python-can `pcan`) and a Virtual bus; PCAN status (error warning / passive / bus-off),
  TX/RX fps, measured and estimated bus load, error counters, controller reset.
- Semantic analyzer maps signals to roles (cells, temperatures, SOC, pack V/I, rpm, torque, speed, odometer,
  charger set-points ...) - panels are generated from the DBC:
  - Battery: SOC gauge, pack KPIs, per-cell grid (inactive slots greyed for smaller packs), temperatures,
    balancing, auto max/min/avg/delta + ids, pack V = sum of cells, MOSFET switches, fault flags.
  - Motor, Vehicle, Charger panels with gauges, driver inputs, flags and all remaining signals.
  - All-signals editor, TX message table (enable, cycle time, send once, live hex), live bus trace.
- Live battery model (SOC coulomb counting, NMC/LFP/LTO OCV, I2R heating) and drive model
  (throttle -> rpm -> speed -> odometer, DC current back into the battery).
- Multiplexed messages sent round-robin; alive counters auto-incremented; tolerant DBC loader
  (NaN ranges, 29-bit ids without flag, factor 0).
