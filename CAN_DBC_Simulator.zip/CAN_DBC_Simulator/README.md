# CAN DBC Simulator

DBC-driven, UI-controllable EV ECU simulator for a PEAK **PCAN** adapter.
Pick a product (Battery / MCU / Vehicle / Charger …) and a DBC, change values in the browser
(cell voltages, SOC, rpm, speed, faults …) and the matching CAN frames go out on the bus.

- **Local HTTP server + Python backend** (Flask, python-can, cantools) - no build step, no internet needed
- **183 customer DBCs** pre-loaded in `dbc_library/`, plus upload of new DBCs
- **Screens are generated from the DBC**: an 8-cell pack shows 8 cells, a 16-cell pack shows 16; unused slots are greyed out
- **PCAN bus status** live: state (error active / warning / passive / bus-off), TX/RX per second, bus load, errors

Version: see [`VERSION`](VERSION) · history: [`CHANGELOG.md`](CHANGELOG.md) · [`REVISION_NOTES.md`](REVISION_NOTES.md)

---

## Quick start

```bat
run.bat
```
or
```bash
python -m pip install -r requirements.txt
python run.py            # http://127.0.0.1:8080 opens in the browser
```

Requirements: Python 3.10+, and for real hardware the **PEAK PCAN driver** (`PCANBasic.dll`, installed with
the PEAK "PCAN-Basic" / device driver package). Without an adapter use the **Virtual** interface.

## Using it

1. **System** drop-down → **DBC** drop-down (grouped by customer). The baud rate is set from the DBC
   (attribute, or a `250Kbps` style file name, or the system default: J1939 = 250 k, others = 500 k).
2. **Interface** `PEAK PCAN` + **Channel** `PCAN_USBBUS1` (a `●` marks detected channels) + **Baud rate**
   (125 / 250 / 500 / 1000 kbps) → **Connect**. Changing the baud rate while connected re-connects.
3. **Start TX**. By default the messages of the chosen system are sent (e.g. only BMS frames when you
   picked *Battery*); change it in **TX messages** (enable / cycle time / send once).
4. Change values on the product tabs - every change is in the next frame.

| Tab | What you get |
|---|---|
| 🔋 Battery (BMS) | SOC gauge, pack V / I / SOH / power / capacity / cycles, **cell grid** (slider + mV box per cell, MAX / MIN marks, balancing dots, *Set all*, *Randomize*, layout 8…192 with inactive cells greyed), temperature sensors, auto max/min/avg/Δ with cell numbers, MOSFET switches, every fault/status flag of the BMS messages, battery model |
| ⚙️ Motor (MCU) | rpm / torque / speed gauges, throttle, brake, gear, drive mode, DC bus V / I, phase current, motor & controller temperature, MCU flags, drive model |
| 🛵 Vehicle / VCU | speed, rpm, SOC, ignition, side stand, gear, mode, odometer / trip / range, GPS, lights & indicators, vehicle flags |
| 🔌 Charger | output V / I, voltage / current request, AC input, station flags |
| All signals | every signal of the DBC, editable (physical units), search |
| TX messages | enable, cycle time, send once, live payload hex, estimated bus load |
| Bus trace | live TX / RX frames with message names, filter, pause |

Only the tabs that the DBC actually supports are shown.

### Battery simulator (Battery tab, top card)
Switch **Simulate battery** on and the pack behaves like a real series string, starting from the values on screen:

| | |
|---|---|
| Cell model | own SOC, capacity (± spread) and internal resistance per cell; V = OCV(SOC) − I·R (NMC / LFP / LTO curves with the low-SOC knee) |
| Modes | **Manual** (Pack current slider or drive model), **Rest**, **Discharge** (constant current until a cell hits UV), **Charge CC-CV** (CC until the highest cell reaches CV, taper, finished at C/20) |
| Balancing | passive bleed: starts at *Start Δ*, stops at *Stop Δ*, only cells above *Min cell V*, bleed current in mA, when *charging / charging + idle / always*. Time to balance = excess Ah ÷ bleed current (1 Ah @ 50 mA = 20 h), shown as ETA |
| Protections | cell OV → charge MOS off, cell UV → discharge MOS off, OT → both off, UT → charge off (with hysteresis). Matching fault bits in the DBC are set |
| Thermal | I²R heating, cooling to ambient. A temperature you set is held (hot spot / heater) and heating adds on top |
| Time | 1× real time … 3600× (1 s = 1 h) |

Editing a cell voltage while it runs changes that cell's SOC (so an imbalanced cell stays imbalanced until the
balancer bleeds it), editing SOC shifts all cells, MOSFET switches are honoured. An imbalanced pack stops charging
when its highest cell reaches CV — exactly why balancing matters.

### Bus-off / error recovery
**Reset controller** (sidebar) = PCAN-Basic `CAN_Reset`, the same call as PCAN-View's *Reset* — PCAN-View does not
have to be open. If the controller is still bus-off / error-passive / bus-heavy afterwards, the channel is
un-initialised and initialised again. **Auto-recover** (on by default) enables the driver's
`PCAN_BUSOFF_AUTORESET` and a watchdog that resets with back-off (1 s → 10 s); TX pauses while the controller is
bus-off. Recoveries are listed in the sidebar. Bus-off itself means the bus is unhealthy (no other node ACKs,
bit-rate mismatch, wiring / 120 Ω termination) — recovery only restarts the controller.

### Simulation helpers
- **Pack V = Σ cells**, **auto max/min/avg/Δ**, **Power = V × I**, **Link MCU DC bus to pack**, **auto alive counters** (Battery → Simulation).
- **Live battery model**: SOC integrates the pack current (capacity in Ah), cells follow the NMC / LFP / LTO
  OCV curve + IR drop + your per-cell offsets, temperatures follow I²R heating.
- **Live drive model**: throttle → rpm → speed → odometer / trip, torque, DC current (fed back to the battery current).

### Uploading a DBC
**Upload DBC** → choose the system folder and a customer folder (new or existing) → drop the file.
The file is parsed first; invalid files are rejected. It is stored in
`dbc_library/<System>/<Customer>/<name>.dbc` and loaded immediately. Same name → `_2`, `_3` … unless *Overwrite*.

## Project layout

```
CAN_DBC_Simulator/
├─ VERSION                  single source of the version number
├─ run.py / run.bat         start the server
├─ simulator/
│  ├─ config.py             systems, baud rates, interfaces, paths
│  ├─ dbc_library.py        library scan, tolerant DBC loader (repairs), upload
│  ├─ analyzer.py           signal -> role mapping (cells, temps, SOC, rpm, speed …) => panels
│  ├─ engine.py             values, derivations, drive model, TX scheduler, mux round-robin
│  ├─ battery_model.py      per-cell pack model: CC-CV, balancing, protections, thermal
│  ├─ can_interface.py      PCAN / virtual bus, RX thread, status, bus load, trace
│  └─ server.py             REST API + static files
├─ web/                     index.html, css/app.css, js/ (app, api, store, ui, panels/*)
├─ dbc_library/             <System>/<Customer>/*.dbc  (+ IMPORT_MANIFEST.csv)
├─ tools/                   import_bb_dbc.py, convert_bb_docs.py, analyze_report.py, bump_version.py
└─ tests/test_backend.py
```

### How the UI follows the DBC
`analyzer.py` tokenises every signal / message name (`BMS_bat_max_cellvtg` → `bms bat max cell vtg`),
looks at units, sizes and value tables and maps the signal to a **role** such as `bms.cell_v.7`,
`bms.soc`, `mcu.rpm`, `veh.speed`, `chg.set_current`. A role can drive several signals (e.g. SOC in three
messages) with unit conversion (V↔mV, A↔mA, °C↔K, km/h↔m/s). Signals that are not mapped still appear
as flags / enums / "more signals" on the product tab of their message, and always in **All signals**.
Check what a DBC maps to with:

```bash
python tools/analyze_report.py TEC -v
```

### REST API (for scripting)
`GET /api/library` · `POST /api/library/upload` · `POST /api/dbc/load {id}` · `POST /api/roles {updates:{role:value}}` ·
`POST /api/signals {updates:[{msg,sig,value}]}` · `POST /api/bus/connect {interface,channel,bitrate_kbps}` ·
`POST /api/tx {running}` · `POST /api/messages/<name> {enabled,cycle_ms}` · `GET /api/poll`

## Tests
```bash
python tests/test_backend.py         # every DBC loads / encodes, derivations, virtual bus
python tests/test_battery_model.py   # OCV, balancing time, CC-CV, UV stop + fault bits, held temperatures
python tests/test_bus_recovery.py    # CAN_Reset, re-init fallback, auto recovery (fake PCAN driver)
```
Loads **every** library DBC, encodes every message, checks cell → pack-voltage derivation and a virtual-bus TX round-trip.

## Notes / limits (v1.0.0)
- Classic CAN only; messages with DLC > 8 (CAN FD) are listed but not sent.
- Checksums / CRC signals are sent as set (not calculated); alive counters are auto-incremented.
- DBCs converted from PDF / Word / Excel specs are marked `_from_spec`; assumptions are in their CM_ comments and in
  `BB CAN DBC/Converted_DBC/CONVERSION_REPORT.md`.
- Multi-pack DBCs: every pack's cells are shown separately, but pack-level values (SOC, pack V) are shared across packs.
- If the PCAN is the only node on the bus, frames are not acknowledged → the status shows *error warning / passive*
  and a hint; connect a receiver (or a second node) and 120 Ω termination.
- Role detection is heuristic; everything it misses is still editable in **All signals**.
