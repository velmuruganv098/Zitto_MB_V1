// DOM helpers and reusable, live-bound controls.
import { api } from "./api.js";
import { S, onRole, onSignal, publishRoles } from "./store.js";

export const $ = (sel, root = document) => root.querySelector(sel);

export function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === undefined || v === null || v === false) continue;
    if (k === "class") el.className = v;
    else if (k === "style" && typeof v === "object") Object.assign(el.style, v);
    else if (k.startsWith("on") && typeof v === "function") el.addEventListener(k.slice(2), v);
    else if (k === "html") el.innerHTML = v;
    else if (k in el && typeof v !== "string") el[k] = v;
    else el.setAttribute(k, v === true ? "" : v);
  }
  for (const c of kids.flat()) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
  return el;
}

export function unitLabel(u) {
  if (!u) return "";
  if (u === "degC") return "°C";
  return u;
}

export function decimals(step) {
  if (!step || step >= 1) return 0;
  return Math.min(4, Math.max(0, Math.ceil(-Math.log10(step) - 1e-9)));
}

export function fmt(v, step = 0.01) {
  if (v === undefined || v === null || Number.isNaN(v)) return "—";
  const d = decimals(step);
  return Number(v).toFixed(d);
}

export function toast(msg, kind = "info", ms = 3500) {
  const t = h("div", { class: `toast ${kind}` }, msg);
  $("#toasts").append(t);
  setTimeout(() => t.remove(), ms);
}

// ---------------------------------------------------------------- senders
const pending = new Map();
function throttled(key, fn, ms = 70) {
  const p = pending.get(key) || { last: 0, timer: null, fn: null };
  p.fn = fn;
  pending.set(key, p);
  const now = performance.now();
  if (now - p.last >= ms && !p.timer) { p.last = now; fn(); return; }
  if (!p.timer) p.timer = setTimeout(() => { p.timer = null; p.last = performance.now(); p.fn(); }, ms);
}

export function sendRole(key, value) {
  S.roles[key] = value;
  throttled("r:" + key, () =>
    api.setRoles({ [key]: value }).then((r) => publishRoles(r.state.roles)).catch((e) => toast(e.message, "err")));
}

export function sendSignal(msg, sig, value) {
  throttled("s:" + msg + sig, () =>
    api.setSignals([{ msg, sig, value }]).catch((e) => toast(e.message, "err")));
}

// "busy" = user is interacting; live updates must not fight the pointer
let pointerDown = false;
document.addEventListener("pointerdown", () => { pointerDown = true; });
document.addEventListener("pointerup", () => { pointerDown = false; });
export function isBusy(el) {
  return document.activeElement === el || (pointerDown && document.activeElement === el);
}

// ------------------------------------------------------ editing guard
// While the user drags / types in a control, live values from the server must not overwrite it.
// (Relying on :focus alone is not enough: some browsers don't focus a range input on click.)
const editingUntil = new WeakMap();
export function guard(el) {
  const on = () => editingUntil.set(el, Infinity);
  const off = () => editingUntil.set(el, performance.now() + 600);
  el.addEventListener("pointerdown", on);
  el.addEventListener("focus", on);
  el.addEventListener("keydown", on);
  el.addEventListener("pointerup", off);
  el.addEventListener("pointercancel", off);
  el.addEventListener("blur", off);
  el.addEventListener("change", off);
  return el;
}
export function isEditing(el) {
  return (editingUntil.get(el) || 0) > performance.now();
}
document.addEventListener("pointerup", () => {       // pointer released outside the element
  document.querySelectorAll("input[type=range]").forEach((r) => {
    if (editingUntil.get(r) === Infinity && document.activeElement !== r) editingUntil.set(r, performance.now() + 600);
  });
});

// -------------------------------------------------------------- controls
function numberBox(min, max, step, value, onChange) {
  const range = guard(h("input", { type: "range", min, max, step: step || "any" }));
  const num = guard(h("input", { type: "number", step: step || "any" }));
  const set = (v) => {
    if (!isEditing(range)) range.value = v;
    if (!isEditing(num)) num.value = fmt(v, step);
  };
  set(value ?? min);
  range.addEventListener("input", () => { num.value = fmt(+range.value, step); onChange(+range.value); });
  num.addEventListener("change", () => { const v = +num.value; if (!Number.isNaN(v)) { range.value = v; onChange(v); } });
  num.addEventListener("keydown", (e) => { if (e.key === "Enter") num.blur(); });
  return { range, num, set };
}

export function switchEl(checked, onChange) {
  const inp = h("input", { type: "checkbox" });
  inp.checked = !!checked;
  inp.addEventListener("change", () => onChange(inp.checked ? 1 : 0));
  return { el: h("label", { class: "switch" }, inp, h("span")), inp };
}

export function selectEl(choices, value, onChange) {
  const sel = h("select");
  for (const [k, lab] of Object.entries(choices || {})) sel.append(h("option", { value: k }, `${k}: ${lab}`));
  sel.value = String(Math.round(value ?? 0));
  sel.addEventListener("change", () => onChange(+sel.value));
  return sel;
}

/** A control bound to an analyzer role (canonical units). */
export function roleControl(role, opts = {}) {
  const v0 = S.roles[role.key];
  const locked = opts.locked;
  const wrap = h("div", { class: "ctl" + (role.derived || locked ? " derived" : ""), title: tip(role) });
  const valEl = h("span", { class: "val" }, fmt(v0, role.step));
  const head = h("div", { class: "head" }, h("span", { class: "lbl" }, opts.label || role.label),
    role.derived || locked ? h("span", { class: "tag auto" }, locked || "auto") : null,
    role.bindings.length > 1 ? h("span", { class: "tag", title: role.bindings.map((b) => `${b.msg}.${b.sig}`).join("\n") }, `×${role.bindings.length}`) : null);
  wrap.append(head);
  if (role.kind === "bool") {
    const sw = switchEl(v0, (v) => sendRole(role.key, v));
    const txt = h("span", { class: "muted" }, v0 ? "ON" : "OFF");
    wrap.append(h("div", { class: "row" }, sw.el, txt));
    onRole(role.key, (v) => { sw.inp.checked = !!v; txt.textContent = v ? "ON" : "OFF"; });
  } else if (role.kind === "enum" && role.choices) {
    const sel = selectEl(role.choices, v0, (v) => sendRole(role.key, v));
    wrap.append(sel);
    onRole(role.key, (v) => { if (document.activeElement !== sel) sel.value = String(Math.round(v)); });
  } else {
    wrap.append(h("div", { class: "row" }, valEl, h("span", { class: "unit" }, unitLabel(role.unit))));
    const nb = numberBox(role.min, role.max, role.step, v0, (v) => { valEl.textContent = fmt(v, role.step); sendRole(role.key, v); });
    wrap.append(h("div", { class: "row" }, nb.range, nb.num));
    if (locked) { nb.range.disabled = true; nb.num.disabled = true; }
    onRole(role.key, (v) => { valEl.textContent = fmt(v, role.step); nb.set(v); });
  }
  return wrap;
}

function tip(role) {
  return `${role.key}\nrange ${role.min} … ${role.max} ${unitLabel(role.unit)}\n` +
    role.bindings.map((b) => `→ ${b.msg}.${b.sig}`).join("\n");
}

export function sigKind(sig) {
  if (sig.kind) return sig.kind;            // decided by the backend (special-value tables stay numeric)
  if (sig.length === 1) return "bool";
  if (sig.choices && Object.keys(sig.choices).length === 2 && sig.length <= 2) return "bool";
  if (sig.choices && Object.keys(sig.choices).length > 1) return "enum";
  return "number";
}

/** Inline control for one raw DBC signal (physical DBC units). */
export function signalControl(msg, sig) {
  const kind = sigKind(sig);
  const cur = S.signals[msg]?.[sig.name] ?? 0;
  const box = h("div", { class: "ctlbox" });
  if (kind === "bool") {
    const sw = switchEl(cur, (v) => sendSignal(msg, sig.name, v));
    const lab = h("span", { class: "muted" }, sig.choices ? (sig.choices[cur] ?? cur) : (cur ? "1" : "0"));
    box.append(sw.el, lab);
    onSignal(msg, sig.name, (v) => { sw.inp.checked = !!v; lab.textContent = sig.choices ? (sig.choices[v] ?? v) : (v ? "1" : "0"); });
  } else if (kind === "enum") {
    const sel = selectEl(sig.choices, cur, (v) => sendSignal(msg, sig.name, v));
    box.append(sel);
    onSignal(msg, sig.name, (v) => { if (document.activeElement !== sel) sel.value = String(Math.round(v)); });
  } else {
    const nb = numberBox(sig.min, sig.max, sig.step, cur, (v) => sendSignal(msg, sig.name, v));
    box.append(nb.range, nb.num);
    onSignal(msg, sig.name, (v) => nb.set(v));
  }
  return box;
}

/** Compact toggle / select row used for fault & status flags. */
export function flagControl(msg, sig) {
  const kind = sigKind(sig);
  const cur = S.signals[msg]?.[sig.name] ?? 0;
  const fault = /fault|err|fail|alarm|warn|protect|over|under|short|trip|abnormal/i.test(sig.name);
  const row = h("div", { class: "flag" + (fault ? " fault" : "") + (cur ? " on" : ""), title: `${msg}.${sig.name}` });
  row.append(h("span", { class: "lbl" }, sig.name));
  if (kind === "enum") {
    const sel = selectEl(sig.choices, cur, (v) => sendSignal(msg, sig.name, v));
    row.append(sel);
    onSignal(msg, sig.name, (v) => { if (document.activeElement !== sel) sel.value = String(Math.round(v)); row.classList.toggle("on", !!v); });
  } else {
    const sw = switchEl(cur, (v) => { row.classList.toggle("on", !!v); sendSignal(msg, sig.name, v); });
    row.prepend(sw.el);
    onSignal(msg, sig.name, (v) => { sw.inp.checked = !!v; row.classList.toggle("on", !!v); });
  }
  return row;
}

// ----------------------------------------------------------------- gauge
export function gauge(role, label) {
  const R = 80, cx = 100, cy = 95, a0 = -210, a1 = 30;
  const pt = (deg, r = R) => [cx + r * Math.cos(deg * Math.PI / 180), cy + r * Math.sin(deg * Math.PI / 180)];
  const arc = (from, to) => {
    const [x0, y0] = pt(from), [x1, y1] = pt(to);
    return `M ${x0} ${y0} A ${R} ${R} 0 ${to - from > 180 ? 1 : 0} 1 ${x1} ${y1}`;
  };
  const ns = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(ns, "svg");
  svg.setAttribute("viewBox", "0 0 200 150");
  svg.innerHTML = `<path d="${arc(a0, a1)}" stroke="#2a3242" stroke-width="12" fill="none" stroke-linecap="round"/>
    <path class="fill" d="${arc(a0, a0 + 0.01)}" stroke="url(#gg${role.key.replace(/\W/g, "")})" stroke-width="12" fill="none" stroke-linecap="round"/>
    <defs><linearGradient id="gg${role.key.replace(/\W/g, "")}" gradientUnits="userSpaceOnUse" x1="20" y1="0" x2="180" y2="0"><stop offset="0" stop-color="#2fbf71"/><stop offset=".6" stop-color="#f0b429"/><stop offset="1" stop-color="#ef4b4b"/></linearGradient></defs>
    <text x="100" y="98" text-anchor="middle" class="g-val">0</text>
    <text x="100" y="118" text-anchor="middle" class="g-unit">${unitLabel(role.unit)}</text>
    <text x="22" y="140" class="g-unit">${fmt(role.min, role.step >= 1 ? 1 : 0.1)}</text>
    <text x="178" y="140" text-anchor="end" class="g-unit">${fmt(role.max, role.step >= 1 ? 1 : 0.1)}</text>`;
  const fill = svg.querySelector(".fill"), txt = svg.querySelector(".g-val");
  const update = (v) => {
    const f = Math.max(0, Math.min(1, (v - role.min) / ((role.max - role.min) || 1)));
    fill.setAttribute("d", arc(a0, a0 + Math.max(0.01, f * (a1 - a0))));
    txt.textContent = fmt(v, role.step >= 1 ? 1 : 0.1);
  };
  const nb = numberBox(role.min, role.max, role.step, S.roles[role.key], (v) => { update(v); sendRole(role.key, v); });
  update(S.roles[role.key] ?? role.min);
  onRole(role.key, (v) => { update(v); nb.set(v); });
  return h("div", { class: "gauge", title: tip(role) }, svg, h("div", { class: "g-lbl" }, label || role.label),
    h("div", { class: "row", style: { display: "flex", gap: "6px" } }, nb.range, nb.num));
}

export function section(title, sub, ...body) {
  return h("div", { class: "card" }, h("header", {}, h("h2", {}, title), sub ? h("span", { class: "sub" }, sub) : null), ...body);
}
