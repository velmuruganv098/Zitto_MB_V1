// Shared pieces for the product panels: auto-collected flags and "more signals".
import { S } from "../store.js";
import { h, section, flagControl, signalControl, sigKind, unitLabel } from "../ui.js";

/** Signals of messages that belong to `panel` and are not already bound to a role. */
export function panelExtras(panel) {
  const flags = [], enums = [], numbers = [];
  for (const m of S.model.messages) {
    if (m.system !== panel) continue;
    for (const s of m.signals) {
      if (s.role || s.mux || s.auto) continue;
      const k = sigKind(s);
      (k === "bool" ? flags : k === "enum" ? enums : numbers).push({ msg: m.name, sig: s });
    }
  }
  return { flags, enums, numbers };
}

/** Faults / status toggles + enum selects, with a filter box when long. */
export function flagsSection(title, items) {
  if (!items.length) return null;
  const grid = h("div", { class: "grid flags" });
  const rows = items.map(({ msg, sig }) => {
    const r = flagControl(msg, sig);
    r.dataset.q = (msg + " " + sig.name).toLowerCase();
    return r;
  });
  grid.append(...rows);
  const filter = items.length > 24 ? h("input", {
    type: "text", placeholder: `Filter ${items.length} signals…`, style: { maxWidth: "260px" },
    oninput: (e) => { const q = e.target.value.toLowerCase(); rows.forEach((r) => r.classList.toggle("hidden", !r.dataset.q.includes(q))); },
  }) : null;
  return section(title, `${items.length} from DBC`, filter ? h("div", { class: "toolbar" }, filter) : null, grid);
}

/** Collapsible list of remaining numeric signals of this system, grouped by message. */
export function moreSignals(title, items) {
  if (!items.length) return null;
  const det = h("details", { class: "more" }, h("summary", {}, `${title} — ${items.length} more signal(s) from this system`));
  let built = false;
  det.addEventListener("toggle", () => {
    if (!det.open || built) return;
    built = true;
    const byMsg = new Map();
    for (const it of items) { if (!byMsg.has(it.msg)) byMsg.set(it.msg, []); byMsg.get(it.msg).push(it.sig); }
    for (const [msg, sigs] of byMsg) {
      det.append(h("div", { class: "muted", style: { margin: "10px 0 4px", fontWeight: 600 } }, msg));
      for (const s of sigs) {
        det.append(h("div", { class: "sigrow" },
          h("span", { class: "sn", title: s.comment || s.name }, s.name),
          signalControl(msg, s),
          h("span", { class: "muted" }, unitLabel(s.unit)),
          h("span", { class: "meta" }, `${s.start}|${s.length}@${s.byte_order === "little_endian" ? 1 : 0}${s.signed ? "-" : "+"} ×${s.scale}`)));
      }
    }
  });
  return h("div", { class: "card" }, det);
}

export function rolesFor(panel, section) {
  const a = S.model.analysis;
  return (a.panel_roles[panel] || []).map((k) => a.roles[k]).filter((r) => !section || [].concat(section).includes(r.section));
}
