// Battery (BMS) panel: battery simulator, pack KPIs, per-cell voltages, temperatures, stats, flags.
import { api } from "../api.js";
import { S, onRole, onBm, publishRoles } from "../store.js";
import { h, section, roleControl, gauge, toast, fmt, switchEl, guard, isEditing } from "../ui.js";
import { panelExtras, flagsSection, moreSignals, rolesFor } from "./common.js";

const CHEM = {
  NMC: { lo: 2.5, hi: 4.3, warnLo: 3.2, warnHi: 4.15, nom: 3.70 },
  LFP: { lo: 2.0, hi: 3.8, warnLo: 2.9, warnHi: 3.60, nom: 3.25 },
  LTO: { lo: 1.5, hi: 2.9, warnLo: 2.0, warnHi: 2.75, nom: 2.30 },
};
const LAYOUTS = [8, 12, 14, 16, 20, 24, 28, 32, 48, 64, 96, 128, 144, 160, 192];
const SCALES = [[1, "1× real time"], [10, "10×"], [60, "60× (1 min = 1 h)"], [300, "300×"], [1800, "1800×"],
  [3600, "3600× (1 s = 1 h)"]];
const ui = { layout: "auto" };

const hms = (s) => {
  if (s === null || s === undefined) return "—";
  s = Math.max(0, Math.round(s));
  const d = Math.floor(s / 86400), hh = Math.floor(s % 86400 / 3600), mm = Math.floor(s % 3600 / 60), ss = s % 60;
  return (d ? `${d}d ` : "") + `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}:${String(ss).padStart(2, "0")}`;
};

function setDyn(patch, rerender) {
  return api.dynamics({ battery: patch }).then((j) => { S.model.dynamics = j.dynamics; if (rerender) rerender(); })
    .catch((e) => toast(e.message, "err"));
}

export function renderBattery(root, rerender) {
  const a = S.model.analysis;
  const opts = S.model.options;
  const cfg = S.model.dynamics.battery;
  const chem = CHEM[cfg.chemistry] || CHEM.NMC;
  const cells = a.cells.map((k) => a.roles[k]);
  const temps = a.temps.map((k) => a.roles[k]);
  const sim = cfg.enabled;

  root.append(simulatorCard(cfg, rerender, cells.length));

  // ---------------------------------------------------------------- pack
  const kpiRoles = rolesFor("battery", ["kpi", "limits"]);
  const soc = kpiRoles.find((r) => r.key === "bms.soc");
  const kpis = h("div", { class: "grid kpis" });
  for (const r of kpiRoles) {
    if (r === soc) continue;
    let locked = null;
    if (r.key === "bms.pack_voltage" && opts.auto_pack_voltage && cells.length) locked = "Σ cells";
    else if (r.key === "bms.power" && opts.auto_power) locked = "V × I";
    else if (sim && ["bms.remaining_cap", "bms.full_cap", "bms.cycles"].includes(r.key)) locked = "model";
    kpis.append(roleControl(r, { locked }));
  }
  const packBody = h("div", { class: "packgrid", style: { gridTemplateColumns: soc ? "230px 1fr" : "1fr" } },
    soc ? gauge(soc, "State of charge") : null, kpis);
  root.append(section("Pack", `${cells.length} cells · ${temps.length} temperature sensors in this DBC`, packBody));

  root.append(cellsCard(cells, a, chem));
  if (temps.length) root.append(tempsCard(temps));

  const stats = rolesFor("battery", "stats");
  if (stats.length) {
    root.append(section("Cell statistics", opts.auto_stats ? "auto-calculated from the cells / sensors" : "manual",
      h("div", { class: "grid kpis" }, stats.map((r) => roleControl(r, { locked: opts.auto_stats && (cells.length || temps.length) ? "auto" : null })))));
  }
  const sw = rolesFor("battery", "switch");
  const ex = panelExtras("battery");
  if (sw.length) root.append(section("Switches", sim ? "MOSFET state - the model opens them on protection" : "MOSFET / contactor state",
    h("div", { class: "grid kpis" }, sw.map((r) => roleControl(r)))));
  const fl = flagsSection("Faults & status flags", [...ex.flags, ...ex.enums]);
  if (fl) root.append(fl);
  root.append(optionsCard(opts, rerender));
  const more = moreSignals("Battery", ex.numbers);
  if (more) root.append(more);
}

// ============================================================ simulator
function simulatorCard(cfg, rerender, nCells) {
  const en = switchEl(cfg.enabled, (v) => setDyn({ enabled: !!v }, rerender)
    .then(() => toast(v ? "Battery simulator ON - started from the values shown" : "Battery simulator OFF", v ? "ok" : "info")));
  const badge = h("span", { class: "badge" }, cfg.enabled ? "RUNNING" : "OFF");
  const num = (k, step, w = 80) => {
    const i = guard(h("input", { type: "number", value: cfg[k], step, style: { width: w + "px" } }));
    i.addEventListener("change", () => setDyn({ [k]: +i.value }));
    return i;
  };
  const sel = (k, pairs, rr) => {
    const s = h("select", {}, pairs.map(([v, t]) => h("option", { value: v }, t)));
    s.value = String(cfg[k]);
    s.addEventListener("change", () => setDyn({ [k]: isNaN(+s.value) ? s.value : +s.value }, rr ? rerender : null));
    return s;
  };

  // ---- mode buttons
  const modes = [["manual", "✋ Manual"], ["rest", "⏸ Rest"], ["discharge", "⬇ Discharge"], ["charge", "⬆ Charge CC-CV"]];
  const modeBtns = modes.map(([m, t]) => {
    const b = h("button", { class: "btn small seg", "data-mode": m, disabled: !cfg.enabled }, t);
    b.addEventListener("click", () => setDyn({ mode: m }).then(() => markMode(m)));
    return b;
  });
  const markMode = (m) => modeBtns.forEach((b) => b.classList.toggle("on", b.dataset.mode === m));
  markMode(cfg.mode);

  // ---- live chips
  const chip = (label) => { const v = h("b", {}, "—"); return { el: h("span", { class: "chip" }, label, " ", v), v }; };
  const cTime = chip("Sim time"), cI = chip("Current"), cPhase = chip("Phase"), cCyc = chip("Cycles"),
    cSoc = chip("Pack SOC"), cRem = chip("Remaining");
  const mosC = h("span", { class: "chip" }, "CHG MOS"), mosD = h("span", { class: "chip" }, "DSG MOS");
  const prot = h("span", { class: "prots" });

  // ---- balancing live
  const bΔ = h("b", { class: "mono" }, "—"), bState = h("span", { class: "badge" }, "idle"), bCells = h("span", { class: "muted" }, "");
  const bEta = h("b", { class: "mono" }, "—"), bEtaS = h("span", { class: "muted" }, "");

  onBm((st) => {
    const on = !!st;
    badge.textContent = on ? `RUNNING · ${st.mode.toUpperCase()}${st.phase && st.phase !== "-" ? " · " + st.phase : ""}` : "OFF";
    badge.className = "badge " + (on ? (st.protections.length ? "err" : "ok") : "");
    modeBtns.forEach((b) => { b.disabled = !on; });
    if (!on) return;
    markMode(st.mode);
    cTime.v.textContent = hms(st.sim_time_s);
    cI.v.textContent = `${fmt(st.current_a, 0.1)} A` + (Math.abs(st.requested_a - st.current_a) > 0.05 && st.mode === "manual" ? ` (req ${fmt(st.requested_a, 0.1)})` : "");
    cPhase.v.textContent = st.phase;
    cCyc.v.textContent = fmt(st.cycles, 0.001);
    cSoc.v.textContent = `${fmt(st.pack_soc, 0.01)} %`;
    cRem.v.textContent = `${fmt(st.remaining_ah, 0.01)} / ${fmt(st.full_ah, 0.01)} Ah`;
    mosC.className = "chip " + (st.chg_mos ? "on" : "off");
    mosD.className = "chip " + (st.dsg_mos ? "on" : "off");
    prot.replaceChildren(...(st.protections.length ? st.protections.map((p) => h("span", { class: "badge err" }, p)) : [h("span", { class: "badge ok" }, "no protection active")]));
    bΔ.textContent = `${fmt(st.delta_mv, 0.1)} mV`;
    bState.textContent = st.bal_session ? "BALANCING" : "idle";
    bState.className = "badge " + (st.bal_session ? "accent" : "");
    bCells.textContent = st.bleeding.length ? `bleeding: ${st.bleeding.length > 12 ? st.bleeding.length + " cells" : "C" + st.bleeding.join(", C")}` : "";
    bEta.textContent = st.bal_session ? hms(st.bal_eta_s) : "—";
    bEtaS.textContent = st.bal_session && st.time_scale !== 1 ? `(≈ ${hms(st.bal_eta_scaled_s)} at ${st.time_scale}×)` : "";
  });

  const chemSel = sel("chemistry", Object.keys(CHEM).map((c) => [c, c]), true);
  const sign = h("select", {}, h("option", { value: "1" }, "+ = discharge"), h("option", { value: "0" }, "+ = charge"));
  sign.value = cfg.discharge_positive ? "1" : "0";
  sign.addEventListener("change", () => setDyn({ discharge_positive: sign.value === "1" }));
  const balEn = switchEl(cfg.bal_enabled, (v) => setDyn({ bal_enabled: !!v }));
  const protEn = switchEl(cfg.protections, (v) => setDyn({ protections: !!v }));

  return h("div", { class: "card sim" + (cfg.enabled ? " running" : "") },
    h("header", {}, h("h2", {}, "🔋 Battery simulator"), badge,
      h("span", { class: "sub" }, "per-cell SOC / OCV / IR model, CC-CV charging, passive balancing, protections")),
    h("div", { class: "toolbar" }, h("label", {}, en.el, h("b", {}, "Simulate battery")), h("span", { class: "vsep" }),
      ...modeBtns, h("span", { class: "vsep" }), h("label", {}, "Time", sel("time_scale", SCALES))),
    h("div", { class: "toolbar" },
      h("label", {}, "Discharge (A)", num("discharge_a", 1)), h("label", {}, "Charge (A)", num("charge_a", 1)),
      h("label", {}, "CV (V/cell)", num("cv_v", 0.01)), h("label", {}, "End at (C)", num("cutoff_c_rate", 0.01, 64)),
      h("span", { class: "muted" }, "Manual: the Pack current slider (or the drive model) sets the current.")),
    h("div", { class: "chips" }, cTime.el, cI.el, cPhase.el, cSoc.el, cRem.el, cCyc.el, mosC, mosD, prot),
    h("div", { class: "subgrid" },
      h("div", { class: "subcard" }, h("h3", {}, "Cell balancing (passive)"),
        h("div", { class: "toolbar" }, h("label", {}, balEn.el, "Enabled"),
          h("label", {}, "When", sel("bal_when", [["charge", "charging only"], ["charge_idle", "charging + idle"], ["always", "always"]]))),
        h("div", { class: "toolbar" }, h("label", {}, "Start Δ (mV)", num("bal_start_mv", 1, 64)),
          h("label", {}, "Stop Δ (mV)", num("bal_stop_mv", 1, 64)), h("label", {}, "Min cell (V)", num("bal_min_v", 0.01, 70)),
          h("label", {}, "Bleed (mA)", num("bal_current_ma", 5, 70))),
        h("div", { class: "toolbar" }, h("span", {}, "Δ now ", bΔ), bState, h("span", {}, "ETA ", bEta), bEtaS),
        h("div", {}, bCells),
        h("div", { class: "muted small" }, "Time to balance = excess Ah of the highest cell ÷ bleed current " +
          "(e.g. 1 Ah at 50 mA = 20 h). Use the time scale to watch it faster.")),
      h("div", { class: "subcard" }, h("h3", {}, "Pack & protection"),
        h("div", { class: "toolbar" }, h("label", {}, "Chemistry", chemSel), h("label", {}, "Capacity (Ah)", num("capacity_ah", 1, 70)),
          h("label", {}, "Spread (%)", num("capacity_spread_pct", 0.5, 60)), h("label", {}, "Cell R (mΩ)", num("cell_r_mohm", 0.1, 64))),
        h("div", { class: "toolbar" }, h("label", {}, "Ambient (°C)", num("ambient_c", 1, 60)), h("label", {}, "Noise (mV)", num("noise_mv", 0.5, 56)),
          h("label", {}, "Current sign", sign)),
        h("div", { class: "toolbar" }, h("label", {}, protEn.el, "Protections"), h("label", {}, "OV", num("ov_v", 0.01, 64)),
          h("label", {}, "UV", num("uv_v", 0.01, 64)), h("label", {}, "OT (°C)", num("ot_c", 1, 56)),
          h("label", {}, "UT chg (°C)", num("ut_charge_c", 1, 56))),
        h("div", { class: "toolbar" },
          h("button", { class: "btn small", disabled: !cfg.enabled, onclick: () => setDyn({ action: "sync" }).then(() => toast("Model restarted from the values shown", "ok")) }, "⟳ Restart from UI values"),
          h("button", { class: "btn small", disabled: !cfg.enabled, onclick: () => setDyn({ action: "clear_protections" }).then(() => toast("Protections cleared", "ok")) }, "Clear protections"),
          nCells ? null : h("span", { class: "muted" }, "No per-cell signals: the model runs one lumped cell × series count.")))));
}

function optionsCard(opts, rerender) {
  const setOpt = (k, v) => api.options({ [k]: v }).then((j) => { S.model.options = j.options; rerender(); });
  const opt = (k, label) => { const s = switchEl(opts[k], (v) => setOpt(k, !!v)); return h("label", {}, s.el, label); };
  return section("Auto-calculation", "applies with and without the simulator",
    h("div", { class: "toolbar" }, opt("auto_pack_voltage", "Pack V = Σ cells"), opt("auto_stats", "Auto max/min/avg/Δ"),
      opt("auto_power", "Power = V × I"), opt("link_dc_bus", "Link MCU DC bus ↔ battery"), opt("counters", "Auto alive counters")));
}

// ================================================================ cells
function cellsCard(cells, a, chem) {
  const n = cells.length;
  const auto = Math.max(8, Math.ceil(n / 8) * 8);
  const slots = ui.layout === "auto" ? auto : Math.max(n, +ui.layout);
  const layoutSel = h("select", {}, h("option", { value: "auto" }, `Auto (${auto})`),
    LAYOUTS.map((L) => h("option", { value: L, disabled: L < n }, `${L} cells${L < n ? " (DBC has more)" : ""}`)));
  layoutSel.value = ui.layout;
  const grid = h("div", { class: "cells" });
  const card = section("Cell voltages", n ? `${n} cell voltage signals in this DBC — ${slots - n} slot(s) inactive` : "this DBC has no per-cell voltage signals");
  layoutSel.addEventListener("change", () => { ui.layout = layoutSel.value; card.replaceWith(cellsCard(cells, a, chem)); });

  const setAll = h("input", { type: "number", value: Math.round(chem.nom * 1000), step: 1 });
  const spread = h("input", { type: "number", value: 20, step: 1 });
  const applyMany = (fn) => {
    const upd = {};
    cells.forEach((r, i) => { upd[r.key] = Math.min(r.max, Math.max(r.min, fn(i))); });
    api.setRoles(upd).then((j) => publishRoles(j.state.roles)).catch((e) => toast(e.message, "err"));
  };
  card.append(h("div", { class: "toolbar" },
    h("label", {}, "Layout", layoutSel),
    h("label", {}, "Set all (mV)", setAll), h("button", { class: "btn small", onclick: () => applyMany(() => +setAll.value / 1000), disabled: !n }, "Apply"),
    h("label", {}, "Imbalance ± (mV)", spread),
    h("button", { class: "btn small", disabled: !n, onclick: () => applyMany(() => +setAll.value / 1000 + (Math.random() * 2 - 1) * (+spread.value / 1000)) }, "Randomize"),
    h("button", { class: "btn small", disabled: !n, onclick: () => applyMany((i) => +setAll.value / 1000 + (i === 0 ? +spread.value / 1000 : 0)) }, "One high cell"),
    h("span", { class: "spacer" }),
    h("span", { class: "legend" }, h("span", {}, h("i", { style: { background: "var(--cell-hi)" } }), "max"),
      h("span", {}, h("i", { style: { background: "var(--cell-lo)" } }), "min"),
      h("span", {}, h("i", { style: { background: "var(--info)" } }), "balancing / bleeding"),
      h("span", {}, h("i", { style: { background: "#444" } }), "inactive (not in DBC)"))), grid);

  const els = [];
  for (let i = 0; i < slots; i++) {
    const r = cells[i];
    if (!r) {
      grid.append(h("div", { class: "cell inactive", title: "Not defined in this DBC" },
        h("div", { class: "top" }, h("span", {}, `C${i + 1}`), h("span", {}, "—")),
        h("div", { class: "bar" }), h("div", { class: "mv" }, "N/A"), h("div", { class: "dim tiny" }, "not in DBC")));
      continue;
    }
    const lo = Math.max(r.min, chem.lo), hi = Math.min(r.max, chem.hi);
    const fill = h("i"), mv = h("div", { class: "mv" }), mark = h("span", { class: "mark" });
    const socEl = h("div", { class: "cellsoc" });
    const range = guard(h("input", { type: "range", min: lo, max: hi, step: 0.001 }));
    const num = guard(h("input", { type: "number", step: 1 }));
    const balKey = a.balance[String(i + 1)];
    const balDot = h("span", { class: "bal", title: balKey ? "Balancing (click to toggle)" : "Model bleeding indicator" });
    if (balKey) {
      balDot.addEventListener("click", () => api.setRoles({ [balKey]: S.roles[balKey] ? 0 : 1 }).then((j) => publishRoles(j.state.roles)));
      onRole(balKey, (v) => balDot.classList.toggle("on", !!v));
      balDot.classList.toggle("on", !!S.roles[balKey]);
    }
    const el = h("div", { class: "cell", title: `${r.source}\n${r.bindings.map((b) => b.msg + "." + b.sig).join("\n")}` },
      h("div", { class: "top" }, h("span", {}, r.label), mark, balDot), h("div", { class: "bar" }, fill), mv, socEl, range, num);
    const show = (v) => {
      if (v === undefined) return;
      mv.textContent = Math.round(v * 1000);
      fill.style.height = `${Math.max(2, Math.min(100, ((v - lo) / (hi - lo)) * 100))}%`;
      el.classList.toggle("lowv", v < chem.warnLo);
      el.classList.toggle("highv", v > chem.warnHi);
      if (!isEditing(range)) range.value = v;
      if (!isEditing(num)) num.value = Math.round(v * 1000);
    };
    const send = (v) => {
      show(v);
      S.roles[r.key] = v;
      api.setRoles({ [r.key]: v }).then((j) => publishRoles(j.state.roles)).catch((e) => toast(e.message, "err"));
    };
    let t = null;
    range.addEventListener("input", () => { const v = +range.value; mv.textContent = Math.round(v * 1000); clearTimeout(t); t = setTimeout(() => send(v), 40); });
    num.addEventListener("change", () => send(+num.value / 1000));
    num.addEventListener("keydown", (e) => { if (e.key === "Enter") num.blur(); });
    show(S.roles[r.key]);
    onRole(r.key, show);
    els.push({ el, mark, key: r.key, socEl, balDot, hasBal: !!balKey });
    grid.append(el);
  }
  const marks = () => {
    if (!els.length) return;
    let mx = els[0], mn = els[0];
    for (const e of els) {
      if ((S.roles[e.key] ?? 0) > (S.roles[mx.key] ?? 0)) mx = e;
      if ((S.roles[e.key] ?? 0) < (S.roles[mn.key] ?? 0)) mn = e;
    }
    for (const e of els) { e.el.classList.remove("max", "min"); e.mark.textContent = ""; }
    if (mx !== mn) {
      mx.el.classList.add("max"); mx.mark.textContent = "MAX";
      mn.el.classList.add("min"); mn.mark.textContent = "MIN";
    }
  };
  marks();
  onRole("*", marks);
  onBm((st) => {
    els.forEach((e, i) => {
      const soc = st?.cell_soc?.[i];
      e.socEl.textContent = soc !== undefined ? `${soc.toFixed(2)} %` : "";
      const bleeding = !!st && st.bleeding.includes(i + 1);
      e.el.classList.toggle("bleeding", bleeding);
      if (!e.hasBal) e.balDot.classList.toggle("on", bleeding);
    });
  });
  return card;
}

// ================================================================ temps
function tempsCard(temps) {
  const n = temps.length;
  const slots = Math.max(4, Math.ceil(n / 4) * 4);
  const grid = h("div", { class: "cells" });
  const setAll = h("input", { type: "number", value: 30, step: 0.5 });
  const card = section("Temperatures", `${n} sensor(s) in DBC - drag, type a value or use −/+`,
    h("div", { class: "toolbar" }, h("label", {}, "Set all (°C)", setAll),
      h("button", { class: "btn small", onclick: () => {
        const upd = {}; temps.forEach((r) => { upd[r.key] = +setAll.value; });
        api.setRoles(upd).then((j) => publishRoles(j.state.roles)).catch((e) => toast(e.message, "err"));
      } }, "Apply")), grid);
  for (let i = 0; i < slots; i++) {
    const r = temps[i];
    if (!r) {
      grid.append(h("div", { class: "cell temp inactive" }, h("div", { class: "top" }, h("span", {}, `T${i + 1}`)),
        h("div", { class: "bar" }), h("div", { class: "mv" }, "N/A")));
      continue;
    }
    const lo = Math.max(r.min, -40), hi = Math.min(r.max, 125);
    const fill = h("i"), val = h("div", { class: "mv" });
    const range = guard(h("input", { type: "range", min: lo, max: hi, step: 0.5 }));
    const num = guard(h("input", { type: "number", step: 0.5, min: lo, max: hi }));
    const el = h("div", { class: "cell temp", title: `${r.source}\nrange ${lo} … ${hi} °C` });
    const show = (v) => {
      if (v === undefined) return;
      val.textContent = fmt(v, 0.1);
      fill.style.height = `${Math.max(2, Math.min(100, ((v - lo) / (hi - lo)) * 100))}%`;
      el.classList.toggle("hot", v > 50);
      el.classList.toggle("cold", v < 0);
      if (!isEditing(range)) range.value = v;
      if (!isEditing(num)) num.value = fmt(v, 0.1);
    };
    const send = (v) => {
      v = Math.min(hi, Math.max(lo, v));
      show(v);
      S.roles[r.key] = v;
      api.setRoles({ [r.key]: v }).then((j) => publishRoles(j.state.roles)).catch((e) => toast(e.message, "err"));
    };
    let t = null;
    range.addEventListener("input", () => { val.textContent = fmt(+range.value, 0.1); clearTimeout(t); t = setTimeout(() => send(+range.value), 40); });
    num.addEventListener("change", () => send(+num.value));
    num.addEventListener("keydown", (e) => { if (e.key === "Enter") num.blur(); });
    const step = (d) => send((S.roles[r.key] ?? 25) + d);
    el.append(h("div", { class: "top" }, h("span", {}, r.label), h("span", {}, "°C")), h("div", { class: "bar" }, fill), val, range,
      h("div", { class: "stepper" }, h("button", { class: "btn tiny", onclick: () => step(-1) }, "−"), num,
        h("button", { class: "btn tiny", onclick: () => step(1) }, "+")));
    show(S.roles[r.key]);
    onRole(r.key, show);
    grid.append(el);
  }
  return card;
}
