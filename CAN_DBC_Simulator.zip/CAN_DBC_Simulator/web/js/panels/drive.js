// Motor (MCU), Vehicle / VCU and Charger panels - same layout, different roles.
import { api } from "../api.js";
import { S } from "../store.js";
import { h, section, roleControl, gauge, toast, switchEl } from "../ui.js";
import { panelExtras, flagsSection, moreSignals, rolesFor } from "./common.js";

const LIGHTS = /light|lamp|indicator|turn|hazard|blink|horn|beam|drl|tail|brake_?light|head/i;

function driveModelCard(rerender) {
  const d = S.model.dynamics.drive;
  const set = (k, v) => api.dynamics({ drive: { [k]: v } }).then((j) => { S.model.dynamics = j.dynamics; })
    .catch((e) => toast(e.message, "err"));
  const en = switchEl(d.enabled, (v) => set("enabled", !!v));
  const num = (k, step) => { const i = h("input", { type: "number", value: d[k], step }); i.addEventListener("change", () => set(k, +i.value)); return i; };
  return section("Drive model", "throttle → rpm → speed → odometer, torque, DC current, temperatures",
    h("div", { class: "toolbar" }, h("label", {}, en.el, h("b", {}, "Live drive model")),
      h("span", { class: "muted" }, "Move the throttle (and brake) and the MCU / vehicle / battery values follow.")),
    h("div", { class: "toolbar" }, h("label", {}, "Max rpm", num("max_rpm", 100)), h("label", {}, "Top speed (km/h)", num("top_speed_kmh", 1)),
      h("label", {}, "Max torque (Nm)", num("max_torque_nm", 1)), h("label", {}, "Response (s)", num("response_s", 0.1))));
}

function controlsGrid(roles) {
  return h("div", { class: "grid kpis" }, roles.map((r) => roleControl(r)));
}

export function renderMotor(root, rerender) {
  const g = rolesFor("motor", "gauge");
  const inputs = rolesFor("motor", "input");
  const power = rolesFor("motor", "power");
  const thermal = rolesFor("motor", "thermal");
  const vs = S.model.analysis.roles["veh.speed"];
  if (g.length || vs) root.append(section("Motor", "live gauges — drag the slider under a gauge to set it",
    h("div", { class: "gauges" }, g.map((r) => gauge(r)), vs ? gauge(vs, "Vehicle speed") : null)));
  if (inputs.length) root.append(section("Driver inputs", "throttle, brake, gear, mode", controlsGrid(inputs)));
  if (power.length || thermal.length) root.append(section("Power & thermal", "", controlsGrid([...power, ...thermal])));
  root.append(driveModelCard(rerender));
  const ex = panelExtras("motor");
  const fl = flagsSection("MCU faults & status flags", [...ex.flags, ...ex.enums]);
  if (fl) root.append(fl);
  const more = moreSignals("Motor", ex.numbers);
  if (more) root.append(more);
}

export function renderVehicle(root, rerender) {
  const a = S.model.analysis;
  const g = rolesFor("vehicle", "gauge");
  const trip = rolesFor("vehicle", "trip");
  const sw = rolesFor("vehicle", "switch");
  const gps = rolesFor("vehicle", "gps");
  const shared = ["mcu.gear", "mcu.mode", "mcu.throttle", "bms.soc"].map((k) => a.roles[k]).filter(Boolean);
  if (g.length || a.roles["mcu.rpm"]) root.append(section("Vehicle", "",
    h("div", { class: "gauges" }, g.map((r) => gauge(r)), a.roles["mcu.rpm"] ? gauge(a.roles["mcu.rpm"]) : null,
      a.roles["bms.soc"] ? gauge(a.roles["bms.soc"], "Battery SOC") : null)));
  if (sw.length || shared.length) root.append(section("Driver & state", "ignition, side stand, gear, mode",
    controlsGrid([...sw, ...shared.filter((r) => r.key !== "bms.soc")])));
  if (trip.length) root.append(section("Distance", "odometer, trip, range", controlsGrid(trip)));
  if (gps.length) root.append(section("GPS", "", controlsGrid(gps)));
  const ex = panelExtras("vehicle");
  const lights = ex.flags.filter((f) => LIGHTS.test(f.sig.name));
  const rest = ex.flags.filter((f) => !LIGHTS.test(f.sig.name));
  const lf = flagsSection("Lights, indicators & switches", lights);
  if (lf) root.append(lf);
  if (a.roles["mcu.rpm"] || a.roles["veh.speed"]) root.append(driveModelCard(rerender));
  const fl = flagsSection("Vehicle status & fault flags", [...rest, ...ex.enums]);
  if (fl) root.append(fl);
  const more = moreSignals("Vehicle", ex.numbers);
  if (more) root.append(more);
}

export function renderCharger(root) {
  const out = rolesFor("charger", "output");
  const setp = rolesFor("charger", "setpoint");
  const inp = rolesFor("charger", "input");
  if (out.length) root.append(section("Charger output", "", h("div", { class: "gauges" }, out.map((r) => gauge(r)))));
  if (setp.length || inp.length) root.append(section("Setpoints & input", "voltage / current request, AC input", controlsGrid([...setp, ...inp])));
  const ex = panelExtras("charger");
  const fl = flagsSection("Charger / station status & faults", [...ex.flags, ...ex.enums]);
  if (fl) root.append(fl);
  const more = moreSignals("Charger", ex.numbers);
  if (more) root.append(more);
}
