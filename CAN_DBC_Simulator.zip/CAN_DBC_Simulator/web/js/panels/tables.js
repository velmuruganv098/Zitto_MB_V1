// All-signals editor, TX message table and live bus trace.
import { api } from "../api.js";
import { S } from "../store.js";
import { h, section, signalControl, toast, unitLabel } from "../ui.js";

export const hexId = (m) => (m.ext ? "0x" + m.id.toString(16).toUpperCase().padStart(8, "0") : "0x" + m.id.toString(16).toUpperCase().padStart(3, "0"));
const SYS_LABEL = { battery: "BMS", motor: "MCU", vehicle: "VCU", charger: "CHG" };
const sysTag = (s) => h("span", {}, h("span", { class: `sysdot sys-${s}` }), SYS_LABEL[s] || s);

// ------------------------------------------------------------ all signals
export function renderSignals(root) {
  const q = h("input", { type: "text", placeholder: "Search message or signal…", style: { minWidth: "280px" } });
  const list = h("div");
  const cards = [];
  for (const m of S.model.messages) {
    const det = h("details", { class: "msgcard" });
    det.dataset.q = (m.name + " " + hexId(m) + " " + m.signals.map((s) => s.name).join(" ")).toLowerCase();
    det.append(h("summary", {}, h("span", { class: "id" }, hexId(m)), h("span", { class: "nm" }, m.name),
      sysTag(m.system), h("span", { class: "badge" }, `DLC ${m.dlc}`), h("span", { class: "badge" }, `${m.signals.length} sig`),
      m.mux_variants ? h("span", { class: "badge warn", title: "Multiplexed: variants are sent round-robin" }, `mux ×${m.mux_variants}`) : null,
      !m.supported ? h("span", { class: "badge err" }, "CAN FD") : null));
    let built = false;
    det.addEventListener("toggle", () => {
      if (!det.open || built) return;
      built = true;
      for (const s of m.signals) {
        det.append(h("div", { class: "sigrow" },
          h("span", { class: "sn", title: s.comment || s.name }, s.name, " ",
            s.role ? h("span", { class: "tag", title: "controlled by panel role" }, s.role.replace(/^\w+\./, "")) : null,
            s.auto ? h("span", { class: "tag auto" }, s.auto) : null, s.mux ? h("span", { class: "tag" }, "MUX") : null),
          signalControl(m.name, s),
          h("span", { class: "muted" }, unitLabel(s.unit)),
          h("span", { class: "meta", title: "start|length@order sign  ×scale +offset  [min..max]" },
            `${s.start}|${s.length}@${s.byte_order === "little_endian" ? 1 : 0}${s.signed ? "-" : "+"} ×${s.scale} +${s.offset}`)));
      }
    });
    cards.push(det);
  }
  list.append(...cards);
  q.addEventListener("input", () => {
    const v = q.value.toLowerCase();
    cards.forEach((c) => c.classList.toggle("hidden", !!v && !c.dataset.q.includes(v)));
  });
  root.append(section("All signals", `${S.model.dbc.messages} messages · ${S.model.dbc.signals} signals — every signal is editable here`,
    h("div", { class: "toolbar" }, q, h("span", { class: "muted" }, "Values are physical (DBC units). Changes go straight into the next frame.")), list));
}

// --------------------------------------------------------------- messages
export function renderMessages(root, rerender) {
  const rows = new Map();
  const tbody = h("tbody");
  for (const m of S.model.messages) {
    const en = h("input", { type: "checkbox", checked: m.enabled, disabled: !m.supported });
    en.addEventListener("change", () => api.message(m.name, { enabled: en.checked }).then(() => { m.enabled = en.checked; })
      .catch((e) => toast(e.message, "err")));
    const cyc = h("input", { type: "number", value: m.cycle_ms, min: 5, step: 5 });
    cyc.addEventListener("change", () => api.message(m.name, { cycle_ms: +cyc.value }).then(() => { m.cycle_ms = +cyc.value; }));
    const cnt = h("td", { class: "mono" }, "0");
    const data = h("td", { class: "data" }, "");
    const send = h("button", { class: "btn small", title: "Send this frame once" }, "Send");
    send.addEventListener("click", () => api.sendOnce(m.name).catch((e) => toast(e.message, "err")));
    const tr = h("tr", {}, h("td", {}, en), h("td", { class: "id" }, hexId(m)), h("td", {}, m.name), h("td", {}, sysTag(m.system)),
      h("td", {}, m.ext ? "29-bit" : "11-bit"), h("td", {}, m.dlc), h("td", {}, cyc), cnt, data, h("td", {}, send));
    rows.set(m.name, { cnt, data, en });
    tbody.append(tr);
  }
  const est = h("span", { class: "badge", id: "estLoad" }, "");
  root.append(section("TX messages", "enable, cycle time, live payload",
    h("div", { class: "toolbar" },
      h("button", { class: "btn small", onclick: () => api.messagesBulk("all").then(() => sync(rows, true)) }, "Enable all"),
      h("button", { class: "btn small", onclick: () => api.messagesBulk("none").then(() => sync(rows, false)) }, "Disable all"),
      h("button", { class: "btn small", onclick: () => api.messagesBulk("focus").then(() => sync(rows, null)) }, `Only ${S.model.dbc.system} messages`),
      h("span", { class: "spacer" }), h("span", { class: "muted" }, "Estimated TX bus load"), est),
    h("div", { class: "tbl-wrap" }, h("table", { class: "tbl" },
      h("thead", {}, h("tr", {}, ["TX", "ID", "Message", "System", "Frame", "DLC", "Cycle ms", "Sent", "Data (hex)", ""].map((t) => h("th", {}, t)))), tbody))));
  return (stats) => {
    for (const [name, st] of Object.entries(stats || {})) {
      const r = rows.get(name);
      if (!r) continue;
      r.cnt.textContent = st.tx;
      r.data.textContent = st.data;
      if (document.activeElement !== r.en) r.en.checked = st.en;
    }
    est.textContent = `${S.estLoad ?? 0}%`;
    est.className = "badge " + (S.estLoad > 70 ? "err" : S.estLoad > 40 ? "warn" : "ok");
  };
}

function sync(rows, state) {
  for (const m of S.model.messages) {
    const v = state === null ? m.focus && m.supported : state && m.supported;
    m.enabled = v;
    const r = rows.get(m.name);
    if (r) r.en.checked = v;
  }
}

// ------------------------------------------------------------------ trace
const tr = { paused: false, rows: [], filter: "", dir: "all" };

export function renderTrace(root) {
  const tbody = h("tbody");
  const info = h("span", { class: "muted" });
  const filt = h("input", { type: "text", placeholder: "Filter id / name / data…", value: tr.filter });
  const dirSel = h("select", {}, ["all", "TX", "RX"].map((d) => h("option", { value: d }, d === "all" ? "TX + RX" : d)));
  dirSel.value = tr.dir;
  const pause = h("button", { class: "btn small" }, tr.paused ? "Resume" : "Pause");
  pause.addEventListener("click", () => { tr.paused = !tr.paused; pause.textContent = tr.paused ? "Resume" : "Pause"; });
  const draw = () => {
    const f = tr.filter.toLowerCase();
    const shown = tr.rows.filter((r) => (tr.dir === "all" || r.dir === tr.dir) &&
      (!f || r.name.toLowerCase().includes(f) || r.idh.toLowerCase().includes(f) || r.data.toLowerCase().includes(f))).slice(-400).reverse();
    tbody.replaceChildren(...shown.map((r) => h("tr", { class: r.err ? "errf" : r.dir.toLowerCase() },
      h("td", { class: "mono" }, r.t.toFixed(4)), h("td", { class: "dir" }, r.dir), h("td", { class: "id" }, r.idh),
      h("td", {}, r.ext ? "X" : "S"), h("td", {}, r.dlc), h("td", { class: "data" }, r.data), h("td", {}, r.name || (r.err ? "ERROR FRAME" : "")))));
    info.textContent = `${tr.rows.length} frame(s) buffered · showing latest ${shown.length}`;
  };
  filt.addEventListener("input", () => { tr.filter = filt.value; draw(); });
  dirSel.addEventListener("change", () => { tr.dir = dirSel.value; draw(); });
  root.append(section("Bus trace", "live TX / RX frames (newest first)",
    h("div", { class: "toolbar" }, pause, h("button", { class: "btn small", onclick: () => { tr.rows = []; draw(); } }, "Clear"), dirSel, filt, h("span", { class: "spacer" }), info),
    h("div", { class: "tbl-wrap" }, h("table", { class: "tbl" },
      h("thead", {}, h("tr", {}, ["Time s", "Dir", "ID", "Type", "DLC", "Data", "Message"].map((t) => h("th", {}, t)))), tbody))));
  draw();
  return (frames) => {
    if (!frames?.length || tr.paused) return;
    for (const f of frames) {
      tr.rows.push({ ...f, idh: f.ext ? f.id.toString(16).toUpperCase().padStart(8, "0") : f.id.toString(16).toUpperCase().padStart(3, "0") });
    }
    if (tr.rows.length > 3000) tr.rows.splice(0, tr.rows.length - 3000);
    draw();
  };
}
