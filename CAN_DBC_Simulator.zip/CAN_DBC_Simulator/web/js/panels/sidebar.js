// Right-hand side: PCAN bus status + DBC information.
import { api } from "../api.js";
import { S } from "../store.js";
import { h, toast, switchEl } from "../ui.js";

let els = null;

export function renderSidebar(root) {
  root.replaceChildren();
  const dot = h("span", { class: "dot" });
  const state = h("b", {}, "DISCONNECTED");
  const sub = h("div", { class: "muted" }, "No bus");
  const kv = h("dl", { class: "kv" });
  const meter = h("div", { class: "meter" }, h("i", { style: { width: "0%" } }));
  const est = h("div", { class: "meter" }, h("i", { style: { width: "0%" } }));
  const loadTxt = h("span", { class: "mono" }, "0 %");
  const estTxt = h("span", { class: "mono" }, "0 %");
  const notes = h("ul", { class: "notes" });
  const reset = h("button", { class: "btn small", title: "CAN_Reset like PCAN-View's Reset; re-initialises the channel if it stays bus-off" }, "⟲ Reset controller");
  reset.addEventListener("click", async () => {
    reset.disabled = true;
    try {
      const r = await api.reset();
      toast((r.result.ok ? "Bus recovered: " : "Reset done, bus still unhealthy: ") + r.result.steps.join(" · "), r.result.ok ? "ok" : "warn", 7000);
    } catch (e) { toast(e.message, "err"); } finally { reset.disabled = false; }
  });
  const auto = switchEl(true, (v) => api.busOptions({ auto_recover: !!v }).then(() => toast(v ? "Auto bus-off recovery ON" : "Auto bus-off recovery OFF")));
  const recLog = h("ul", { class: "warnlist", style: { color: "var(--muted)" } });
  root.append(h("div", { class: "card" }, h("h2", {}, "PCAN bus status"),
    h("div", { class: "state-big" }, dot, h("div", {}, state, sub)),
    h("div", { class: "toolbar", style: { justifyContent: "space-between", marginBottom: "4px" } }, h("span", { class: "muted" }, "Bus load (measured)"), loadTxt), meter,
    h("div", { class: "toolbar", style: { justifyContent: "space-between", margin: "8px 0 4px" } }, h("span", { class: "muted" }, "TX set (estimated)"), estTxt), est,
    h("div", { style: { height: "10px" } }), kv, notes,
    h("div", { class: "toolbar", style: { marginTop: "10px", marginBottom: 0 } }, reset,
      h("label", { title: "Recover automatically from bus-off (driver auto-reset + CAN_Reset / re-init with back-off)" }, auto.el, "Auto-recover")),
    recLog));
  const dbcCard = h("div", { class: "card" });
  root.append(dbcCard);
  els = { dot, state, sub, kv, meter, est, loadTxt, estTxt, notes, reset, dbcCard, auto, recLog };
  renderDbcInfo();
}

export function renderDbcInfo() {
  if (!els) return;
  const c = els.dbcCard;
  c.replaceChildren(h("h2", {}, "DBC"));
  if (!S.model) { c.append(h("div", { class: "muted" }, "No DBC loaded")); return; }
  const d = S.model.dbc, a = S.model.analysis;
  c.append(h("dl", { class: "kv" },
    h("dt", {}, "File"), h("dd", { title: d.id }, d.file),
    h("dt", {}, "Library"), h("dd", { title: d.id }, d.id.split("/").slice(0, -1).join(" / ")),
    h("dt", {}, "Messages"), h("dd", {}, d.messages),
    h("dt", {}, "Signals"), h("dd", {}, d.signals),
    h("dt", {}, "29-bit frames"), h("dd", {}, d.extended),
    h("dt", {}, "Cells / temps"), h("dd", {}, `${a.cells.length} / ${a.temps.length}`),
    h("dt", {}, "Mapped roles"), h("dd", {}, Object.keys(a.roles).length),
    h("dt", {}, "Suggested baud"), h("dd", {}, `${d.baud_hint_kbps} kbps`),
    h("dt", {}, "Nodes"), h("dd", { title: d.nodes.join(", ") }, d.nodes.join(", ") || "—")));
  c.append(h("div", { class: "toolbar", style: { marginTop: "10px" } }, a.panels.map((p) => h("span", { class: "badge ok" }, p.label))));
  if (d.warnings.length) {
    c.append(h("details", {}, h("summary", { class: "muted" }, `${d.warnings.length} DBC note(s)`),
      h("ul", { class: "warnlist" }, d.warnings.map((w) => h("li", {}, w)))));
  }
}

export function updateBus(st, estPct) {
  if (!els) return;
  const lvl = st.connected ? st.level : "off";
  els.dot.className = "dot " + (lvl === "off" ? "" : lvl) + (st.connected && S.txRunning ? " blink" : "");
  els.state.textContent = st.state;
  els.sub.textContent = st.connected ? `${st.interface?.toUpperCase()} · ${st.channel} · ${st.bitrate_kbps} kbps · up ${st.uptime_s}s` : "Not connected";
  const load = st.bus_load_pct || 0;
  els.meter.firstChild.style.width = Math.min(100, load) + "%";
  els.meter.className = "meter" + (load > 80 ? " err" : load > 50 ? " warn" : "");
  els.loadTxt.textContent = `${load} %`;
  els.est.firstChild.style.width = Math.min(100, estPct || 0) + "%";
  els.est.className = "meter" + (estPct > 80 ? " err" : estPct > 50 ? " warn" : "");
  els.estTxt.textContent = `${estPct ?? 0} %`;
  const rows = [["TX frames", st.tx_frames], ["TX / s", st.tx_fps], ["RX frames", st.rx_frames], ["RX / s", st.rx_fps],
    ["TX errors", st.tx_errors], ["Error frames", st.rx_error_frames], ["Recoveries", st.recoveries ?? 0]];
  if (st.status_code) rows.push(["PCAN status", st.status_code]);
  if (st.python_can_state) rows.push(["Controller", st.python_can_state]);
  els.kv.replaceChildren(...rows.flatMap(([k, v]) => [h("dt", {}, k), h("dd", {}, v ?? 0)]));
  const notes = [...(st.detail || [])];
  if (st.last_error) notes.push(st.last_error);
  els.notes.replaceChildren(...notes.map((n) => h("li", {}, n)));
  els.reset.disabled = !st.connected;
  if (st.auto_recover !== undefined && document.activeElement !== els.auto.inp) els.auto.inp.checked = st.auto_recover;
  els.recLog.replaceChildren(...(st.recovery_log || []).slice().reverse().map((t) => h("li", {}, t)));
  // header pill
  const pd = document.getElementById("busDot"), pt = document.getElementById("busText");
  pd.className = els.dot.className;
  pt.textContent = st.connected ? `${st.state} · ${st.bitrate_kbps}k · TX ${st.tx_fps}/s · RX ${st.rx_fps}/s · ${load}%` : "DISCONNECTED";
}
