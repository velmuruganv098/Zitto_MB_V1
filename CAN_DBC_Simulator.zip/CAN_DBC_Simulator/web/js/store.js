// Shared client state + live-update registry.
export const S = {
  config: null,        // /api/config
  library: null,       // /api/library
  model: null,         // loaded DBC model (messages, analysis, options, dynamics)
  roles: {},           // role key -> value (canonical units)
  signals: {},         // msg -> sig -> value
  msgStats: {},        // msg -> {tx, data, en, cyc}
  bus: null,           // last bus status
  txRunning: false,
  vseq: -1,
  tseq: 0,
  tab: null,
  estLoad: 0,
};

// live registry: role key / "msg\u0001sig" -> Set(fn(value))
const roleSubs = new Map();
const sigSubs = new Map();
export const SEP = "\u0001";

export function onRole(key, fn) {
  if (!roleSubs.has(key)) roleSubs.set(key, new Set());
  roleSubs.get(key).add(fn);
}
export function onSignal(msg, sig, fn) {
  const k = msg + SEP + sig;
  if (!sigSubs.has(k)) sigSubs.set(k, new Set());
  sigSubs.get(k).add(fn);
}
export function clearSubs() { roleSubs.clear(); sigSubs.clear(); }

export function publishRoles(roles) {
  for (const [k, v] of Object.entries(roles)) {
    S.roles[k] = v;
    const subs = roleSubs.get(k);
    if (subs) subs.forEach((fn) => fn(v));
  }
  const all = roleSubs.get("*");
  if (all) all.forEach((fn) => fn(S.roles));
}
export function publishSignals(signals) {
  S.signals = signals;
  if (!sigSubs.size) return;
  for (const [k, subs] of sigSubs) {
    const [m, s] = k.split(SEP);
    const v = signals[m]?.[s];
    if (v !== undefined) subs.forEach((fn) => fn(v));
  }
}
export function wantsSignals() { return sigSubs.size > 0; }

// battery-model status (null when the model is off)
const bmSubs = new Set();
export function onBm(fn) { bmSubs.add(fn); }
export function publishBm(st) { S.bm = st; bmSubs.forEach((fn) => fn(st)); }
export function clearBmSubs() { bmSubs.clear(); }
