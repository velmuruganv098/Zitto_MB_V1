// Thin REST client for the Python backend.
async function call(method, url, body) {
  const opt = { method, headers: {} };
  if (body instanceof FormData) opt.body = body;
  else if (body !== undefined) { opt.headers["Content-Type"] = "application/json"; opt.body = JSON.stringify(body); }
  const r = await fetch(url, opt);
  let j = {};
  try { j = await r.json(); } catch { /* non-json */ }
  if (!r.ok || j.ok === false) throw new Error(j.error || `${r.status} ${r.statusText}`);
  return j;
}

export const api = {
  config: () => call("GET", "/api/config"),
  library: () => call("GET", "/api/library"),
  upload: (fd) => call("POST", "/api/library/upload", fd),
  load: (id, system) => call("POST", "/api/dbc/load", { id, system }),
  setRoles: (updates) => call("POST", "/api/roles", { updates }),
  setSignals: (updates) => call("POST", "/api/signals", { updates }),
  options: (o) => call("POST", "/api/options", o),
  dynamics: (d) => call("POST", "/api/dynamics", d),
  message: (name, cfg) => call("POST", `/api/messages/${encodeURIComponent(name)}`, cfg),
  sendOnce: (name) => call("POST", `/api/messages/${encodeURIComponent(name)}/send`, {}),
  messagesBulk: (mode) => call("POST", "/api/messages", { mode }),
  tx: (running) => call("POST", "/api/tx", { running }),
  connect: (iface, channel, bitrate_kbps) => call("POST", "/api/bus/connect", { interface: iface, channel, bitrate_kbps }),
  disconnect: () => call("POST", "/api/bus/disconnect", {}),
  reset: () => call("POST", "/api/bus/reset", {}),
  busOptions: (o) => call("POST", "/api/bus/options", o),
  poll: (q) => call("GET", "/api/poll?" + new URLSearchParams(q).toString()),
};
