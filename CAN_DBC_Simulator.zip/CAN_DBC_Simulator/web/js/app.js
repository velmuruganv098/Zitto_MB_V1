// CAN DBC Simulator - main controller.
import { api } from "./api.js";
import { S, clearSubs, clearBmSubs, publishBm, publishRoles, publishSignals, wantsSignals } from "./store.js";
import { $, h, toast } from "./ui.js";
import { renderBattery } from "./panels/battery.js";
import { renderMotor, renderVehicle, renderCharger } from "./panels/drive.js";
import { renderSignals, renderMessages, renderTrace } from "./panels/tables.js";
import { renderSidebar, renderDbcInfo, updateBus } from "./panels/sidebar.js";

const PANELS = {
  battery: { label: "🔋 Battery (BMS)", render: renderBattery },
  motor: { label: "⚙️ Motor (MCU)", render: renderMotor },
  vehicle: { label: "🛵 Vehicle / VCU", render: renderVehicle },
  charger: { label: "🔌 Charger", render: renderCharger },
};
const TOOLS = {
  signals: { label: "All signals", render: renderSignals },
  messages: { label: "TX messages", render: renderMessages },
  trace: { label: "Bus trace", render: renderTrace },
};
let tabUpdater = null;

const store = {
  get(k) { try { return JSON.parse(localStorage.getItem("cds." + k)); } catch { return null; } },
  set(k, v) { try { localStorage.setItem("cds." + k, JSON.stringify(v)); } catch { /* private mode */ } },
};

// ------------------------------------------------------------------ init
async function init() {
  renderSidebar($("#side"));
  try {
    S.config = await api.config();
  } catch (e) {
    toast("Backend not reachable: " + e.message, "err", 8000);
    return;
  }
  $("#verBadge").textContent = "v" + S.config.version;
  document.title = `CAN DBC Simulator v${S.config.version}`;
  $("#footer").textContent = `CAN DBC Simulator v${S.config.version} · python-can + cantools · library: dbc_library/<System>/<Customer>/`;

  fillSelect($("#baudSel"), S.config.baudrates.map((b) => [b, `${b} kbps`]), store.get("baud") || 500);
  fillSelect($("#ifSel"), Object.entries(S.config.interfaces).map(([k, v]) => [k, v.label]), store.get("iface") || "pcan");
  fillChannels();
  await refreshLibrary();

  const sys = store.get("system") || S.config.systems[0].key;
  $("#sysSel").value = sys;
  fillDbcs();
  const last = store.get("dbc");
  if (last && [...$("#dbcSel").options].some((o) => o.value === last)) {
    $("#dbcSel").value = last;
    await loadDbc(last);
  }
  wire();
  poll();
}

function fillSelect(sel, pairs, value) {
  sel.replaceChildren(...pairs.map(([v, t]) => h("option", { value: v }, t)));
  if (value !== undefined && pairs.some(([v]) => String(v) === String(value))) sel.value = value;
}

function fillChannels() {
  const inf = S.config.interfaces[$("#ifSel").value];
  const det = new Set(inf.detected || []);
  fillSelect($("#chSel"), inf.channels.map((c) => [c, det.has(c) ? `${c} ●` : c]), store.get("channel") || inf.channels[0]);
}

async function refreshLibrary() {
  S.library = (await api.library()).systems;
  const cur = $("#sysSel").value;
  fillSelect($("#sysSel"), S.library.map((s) => [s.key, `${s.label} (${s.count})`]), cur || undefined);
}

function fillDbcs() {
  const sys = S.library.find((s) => s.key === $("#sysSel").value);
  const sel = $("#dbcSel");
  sel.replaceChildren(h("option", { value: "" }, sys?.count ? `— select DBC (${sys.count}) —` : "— no DBC in this system, upload one —"));
  const byCust = new Map();
  for (const f of sys?.files || []) {
    if (!byCust.has(f.customer)) byCust.set(f.customer, []);
    byCust.get(f.customer).push(f);
  }
  for (const [cust, files] of byCust) {
    sel.append(h("optgroup", { label: cust.replace(/_/g, " ") }, files.map((f) => h("option", { value: f.id }, f.file))));
  }
}

// ------------------------------------------------------------------ load
async function loadDbc(id) {
  if (!id) return;
  const sys = $("#sysSel").value;
  try {
    const r = await api.load(id, sys);
    S.model = r.model;
    S.roles = {};
    S.vseq = -1;
    store.set("dbc", id);
    store.set("system", sys);
  } catch (e) {
    toast(e.message, "err", 6000);
    return;
  }
  const hint = S.model.dbc.baud_hint_kbps;
  if (hint && String(hint) !== $("#baudSel").value) {
    $("#baudSel").value = hint;
    toast(`Baud rate set to ${hint} kbps (DBC / system default)`, "info");
    if (S.bus?.connected) await reconnect();
  }
  // fetch values once so controls start with the right numbers
  const p = await api.poll({ vseq: -1, signals: 1 });
  if (p.state) { S.vseq = p.state.vseq; publishRoles(p.state.roles); S.signals = p.state.signals || {}; }
  buildTabs();
  renderDbcInfo();
  $("#txBtn").disabled = false;
  const a = S.model.analysis;
  toast(`Loaded ${S.model.dbc.file}: ${S.model.dbc.messages} msgs, ${a.cells.length} cells, ${a.temps.length} temps, ${Object.keys(a.roles).length} roles`, "ok");
}

function buildTabs() {
  const nav = $("#tabs");
  const a = S.model.analysis;
  const panels = a.panels.map((p) => p.key);
  const focus = S.config.systems.find((s) => s.key === S.model.dbc.system)?.panel;
  const tabs = [...panels.map((k) => [k, PANELS[k].label]), ...Object.entries(TOOLS).map(([k, v]) => [k, v.label])];
  nav.replaceChildren(...tabs.map(([k, label]) => h("button", { class: "tab", "data-tab": k, onclick: () => showTab(k) }, label,
    k === "signals" ? h("span", { class: "count" }, S.model.dbc.signals) : k === "messages" ? h("span", { class: "count" }, S.model.dbc.messages) : null)));
  const want = S.tab && tabs.some(([k]) => k === S.tab) && S.tabDbc === S.model.dbc.id ? S.tab
    : panels.includes(focus) ? focus : panels[0] || "signals";
  showTab(want);
}

function showTab(k) {
  S.tab = k;
  S.tabDbc = S.model.dbc.id;
  document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("active", t.dataset.tab === k));
  clearSubs();
  clearBmSubs();
  const view = $("#view");
  view.replaceChildren();
  const def = PANELS[k] || TOOLS[k];
  tabUpdater = def.render(view, () => showTab(k)) || null;
  S.vseq = -1;            // force a fresh value push to the new controls
}

// ------------------------------------------------------------------ bus
async function connect() {
  const iface = $("#ifSel").value, ch = $("#chSel").value, baud = +$("#baudSel").value;
  const btn = $("#connBtn");
  btn.disabled = true;
  try {
    const r = await api.connect(iface, ch, baud);
    S.bus = r.status;
    store.set("iface", iface); store.set("channel", ch); store.set("baud", baud);
    toast(`Connected ${ch} @ ${baud} kbps`, "ok");
  } catch (e) {
    toast(e.message.includes("PCAN") || iface === "pcan" ? `PCAN connect failed: ${e.message}. Check the USB adapter / driver, or use the Virtual interface.` : e.message, "err", 9000);
  } finally {
    btn.disabled = false;
  }
}

async function reconnect() {
  await api.disconnect().catch(() => null);
  await connect();
}

function wire() {
  $("#sysSel").addEventListener("change", () => { fillDbcs(); store.set("system", $("#sysSel").value); });
  $("#dbcSel").addEventListener("change", () => loadDbc($("#dbcSel").value));
  $("#ifSel").addEventListener("change", fillChannels);
  $("#baudSel").addEventListener("change", async () => {
    store.set("baud", +$("#baudSel").value);
    if (S.bus?.connected) { toast(`Re-connecting at ${$("#baudSel").value} kbps`); await reconnect(); }
  });
  $("#connBtn").addEventListener("click", async () => {
    if (S.bus?.connected) { await api.disconnect(); toast("Disconnected"); } else await connect();
  });
  $("#txBtn").addEventListener("click", async () => {
    try {
      const r = await api.tx(!S.txRunning);
      S.txRunning = r.running;
      if (r.running && !S.bus?.connected) toast("TX running in preview mode - connect a bus to put frames on the wire", "warn", 5000);
    } catch (e) { toast(e.message, "err"); }
  });
  wireUpload();
}

// ---------------------------------------------------------------- upload
function wireUpload() {
  const dlg = $("#uploadDlg"), file = $("#upFile"), drop = $("#upDrop");
  let chosen = null;
  const pick = (f) => { chosen = f; $("#upName").textContent = f ? `${f.name} (${(f.size / 1024).toFixed(1)} kB)` : "no file selected"; };
  $("#uploadBtn").addEventListener("click", () => {
    fillSelect($("#upSys"), S.library.map((s) => [s.key, s.label]), $("#sysSel").value);
    fillCust();
    $("#upMsg").textContent = "";
    pick(null);
    dlg.showModal();
  });
  const fillCust = () => {
    const sys = S.library.find((s) => s.key === $("#upSys").value);
    $("#upCustList").replaceChildren(...(sys?.customers || []).map((c) => h("option", { value: c })));
  };
  $("#upSys").addEventListener("change", fillCust);
  drop.addEventListener("click", () => file.click());
  file.addEventListener("change", () => pick(file.files[0]));
  drop.addEventListener("dragover", (e) => { e.preventDefault(); drop.classList.add("over"); });
  drop.addEventListener("dragleave", () => drop.classList.remove("over"));
  drop.addEventListener("drop", (e) => { e.preventDefault(); drop.classList.remove("over"); pick(e.dataTransfer.files[0]); });
  $("#uploadForm").addEventListener("submit", async (e) => {
    if (e.submitter?.value === "cancel") return;
    e.preventDefault();
    if (!chosen) { $("#upMsg").textContent = "Choose a .dbc file first."; return; }
    const fd = new FormData();
    fd.append("file", chosen);
    fd.append("system", $("#upSys").value);
    fd.append("customer", $("#upCust").value || "Uploaded");
    if ($("#upOverwrite").checked) fd.append("overwrite", "1");
    $("#upGo").disabled = true;
    $("#upMsg").textContent = "Validating…";
    try {
      const r = await api.upload(fd);
      dlg.close();
      toast(`Stored ${r.id} (${r.messages} msgs, ${r.signals} signals)`, "ok", 5000);
      if (r.warnings?.length) toast(`${r.warnings.length} note(s): ${r.warnings[0]}`, "warn", 7000);
      await refreshLibrary();
      $("#sysSel").value = r.system;
      fillDbcs();
      $("#dbcSel").value = r.id;
      await loadDbc(r.id);
    } catch (err) {
      $("#upMsg").textContent = "Rejected: " + err.message;
    } finally {
      $("#upGo").disabled = false;
    }
  });
}

// ------------------------------------------------------------------ poll
async function poll() {
  try {
    const q = { vseq: S.vseq, tseq: S.tseq, baud: $("#baudSel").value };
    if (S.model && wantsSignals()) q.signals = 1;
    if (S.tab === "messages") q.msgs = 1;
    if (S.tab === "trace") q.trace = 1;
    const p = await api.poll(q);
    S.bus = p.bus;
    S.txRunning = p.tx_running;
    S.estLoad = p.tx_est_load_pct ?? 0;
    updateBus(p.bus, S.estLoad);
    const tb = $("#txBtn");
    tb.innerHTML = S.txRunning ? "&#9632; Stop TX" : "&#9654; Start TX";
    tb.className = "btn " + (S.txRunning ? "danger" : "go");
    const cb = $("#connBtn");
    cb.textContent = p.bus.connected ? "Disconnect" : "Connect";
    cb.className = "btn " + (p.bus.connected ? "danger" : "primary");
    if (p.state) {
      S.vseq = p.state.vseq;
      publishRoles(p.state.roles);
      if (p.state.signals) publishSignals(p.state.signals);
      publishBm(p.state.bm || null);
    }
    if (p.msgs && tabUpdater) tabUpdater(p.msgs);
    if (p.trace) {
      if (p.trace.length) S.tseq = p.trace[p.trace.length - 1].seq;
      if (tabUpdater) tabUpdater(p.trace);
    }
  } catch (e) {
    updateBus({ connected: false, state: "SERVER OFFLINE", level: "error", detail: [String(e.message)] }, 0);
  }
  setTimeout(poll, 250);
}

init();
