"""Start the CAN DBC Simulator.

    python run.py                 # http://127.0.0.1:8080, opens the browser
    python run.py --port 9000 --no-browser
"""
import argparse
import logging
import threading
import webbrowser

from simulator.config import VERSION
from simulator.server import create_app


def main():
    ap = argparse.ArgumentParser(description=f"CAN DBC Simulator v{VERSION}")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8080)
    ap.add_argument("--no-browser", action="store_true")
    args = ap.parse_args()

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    logging.getLogger("werkzeug").setLevel(logging.WARNING)
    logging.getLogger("cantools").setLevel(logging.ERROR)
    logging.getLogger("can").setLevel(logging.WARNING)

    app = create_app()
    url = f"http://{args.host}:{args.port}"
    print(f"\n  CAN DBC Simulator v{VERSION}\n  -> {url}\n  Ctrl+C to stop\n")
    if not args.no_browser:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    app.run(host=args.host, port=args.port, threaded=True, use_reloader=False)


if __name__ == "__main__":
    main()
