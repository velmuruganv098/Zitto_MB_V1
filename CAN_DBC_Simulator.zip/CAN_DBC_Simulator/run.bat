@echo off
REM CAN DBC Simulator - start the local server and open the browser
cd /d "%~dp0"
python -c "import flask, cantools, can" 2>nul || (
  echo Installing Python dependencies...
  python -m pip install -r requirements.txt || goto :fail
)
python run.py %*
goto :eof
:fail
echo Dependency install failed. Run:  python -m pip install -r requirements.txt
pause
