"""DBC library on disk: dbc_library/<System>/<Customer>/<file>.dbc

- list_library()  : scan the folder tree
- load(dbc_id)    : parse with cantools (tolerant, cached by mtime)
- save_upload()   : validate an uploaded DBC and store it in the right folder
"""
from __future__ import annotations

import re
import threading
from dataclasses import dataclass, field
from pathlib import Path

import cantools

from .config import LIBRARY_ROOT, SYSTEMS, BAUDRATES_KBPS, MAX_UPLOAD_BYTES

_cache: dict[str, tuple[float, "LoadedDbc"]] = {}
_lock = threading.Lock()
_SAFE_NAME = re.compile(r"[^A-Za-z0-9_.\- ]+")


class DbcError(Exception):
    pass


@dataclass
class LoadedDbc:
    dbc_id: str
    path: Path
    db: cantools.database.can.Database
    warnings: list[str] = field(default_factory=list)
    baud_hint_kbps: int | None = None


# --------------------------------------------------------------------- paths
def _safe_part(name: str, fallback: str) -> str:
    name = _SAFE_NAME.sub("_", (name or "").strip()).strip(" .")
    return name[:80] or fallback


def resolve(dbc_id: str) -> Path:
    """Map a library id ('BMS/TEC/x.dbc') to a path, refusing traversal."""
    p = (LIBRARY_ROOT / dbc_id).resolve()
    if LIBRARY_ROOT.resolve() not in p.parents or p.suffix.lower() != ".dbc":
        raise DbcError(f"Invalid DBC id: {dbc_id}")
    if not p.is_file():
        raise DbcError(f"DBC not found: {dbc_id}")
    return p


def list_library() -> dict:
    systems = []
    for key, meta in SYSTEMS.items():
        root = LIBRARY_ROOT / key
        root.mkdir(parents=True, exist_ok=True)
        files = []
        for f in sorted(root.rglob("*.dbc"), key=lambda p: (p.parent.name.lower(), p.name.lower())):
            rel = f.relative_to(LIBRARY_ROOT).as_posix()
            customer = f.parent.name if f.parent != root else "General"
            files.append({"id": rel, "file": f.name, "customer": customer,
                          "size": f.stat().st_size, "mtime": f.stat().st_mtime})
        customers = sorted({p.name for p in root.iterdir() if p.is_dir()})
        systems.append({"key": key, **meta, "count": len(files), "files": files, "customers": customers})
    return {"systems": systems}


# ------------------------------------------------------------------- parsing
_BO_RE = re.compile(r"^(BO_\s+)(\d+)", re.M)
_ID_REF_RE = r"^((?:BO_TX_BU_|VAL_|SG_MUL_VAL_|CM_\s+(?:BO_|SG_)|BA_\s+\"[^\"]*\"\s+(?:BO_|SG_))\s+){id}\b"


def _sanitize(text: str) -> tuple[str, list[str]]:
    """Repair common DBC defects that make cantools refuse a file."""
    notes = []
    if re.search(r"\[\s*-?NaN\s*\|", text, re.I) or re.search(r"\|\s*-?NaN\s*\]", text, re.I):
        text = re.sub(r"\[\s*-?NaN\s*\|\s*-?NaN\s*\]", "[0|0]", text, flags=re.I)
        notes.append("Replaced NaN signal ranges with [0|0].")
    # 29-bit ids written without the extended flag (bit 31)
    bad = sorted({int(m.group(2)) for m in _BO_RE.finditer(text) if 0x7FF < int(m.group(2)) < 0x80000000})
    for fid in bad:
        new = fid | 0x80000000
        text = re.sub(rf"^(BO_\s+){fid}\b", rf"\g<1>{new}", text, flags=re.M)
        text = re.sub(_ID_REF_RE.format(id=fid), rf"\g<1>{new}", text, flags=re.M)
    if bad:
        notes.append(f"Marked {len(bad)} message(s) with ids > 0x7FF as extended (29-bit).")
    # attribute definitions with missing default / enum oddities
    text = re.sub(r'^BA_DEF_DEF_\s+"VFrameFormat"\s+"[^"]*"\s*;\s*$', "", text, flags=re.M)
    return text, notes


def _read_text(path: Path) -> str:
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("latin-1", "replace")


def parse_text(text: str) -> tuple[cantools.database.can.Database, list[str]]:
    try:
        return cantools.database.load_string(text, database_format="dbc", strict=False), []
    except Exception as first:  # noqa: BLE001 - cantools raises many types
        fixed, notes = _sanitize(text)
        try:
            db = cantools.database.load_string(fixed, database_format="dbc", strict=False)
            return db, notes or [f"Loaded after repair: {first}"]
        except Exception:
            # last resort: drop the frame-format attribute block entirely
            fixed2 = re.sub(r'^BA_\s+"VFrameFormat".*$', "", fixed, flags=re.M)
            fixed2 = re.sub(r'^BA_DEF_\s+BO_\s+"VFrameFormat".*$', "", fixed2, flags=re.M)
            try:
                db = cantools.database.load_string(fixed2, database_format="dbc", strict=False)
                return db, notes + ["Ignored VFrameFormat attributes (inconsistent in file)."]
            except Exception as e:
                raise DbcError(f"Cannot parse DBC: {e}") from e


def _repair_signals(db) -> list[str]:
    """Fix signal definitions that would break encoding (factor 0)."""
    from cantools.database.conversion import BaseConversion
    notes = []
    for m in db.messages:
        touched = False
        for s in m.signals:
            if not s.scale:
                s.conversion = BaseConversion.factory(scale=1, offset=s.offset or 0, choices=s.choices,
                                                      is_float=s.is_float)
                notes.append(f"{m.name}.{s.name}: factor 0 in DBC - using 1.")
                touched = True
        if touched:
            m.refresh(strict=False)
    return notes


def baud_hint(path: Path, db) -> int | None:
    for attr in ("Baudrate", "BusSpeed", "Bitrate"):
        try:
            v = db.dbc.attributes.get(attr)
            if v is not None:
                val = int(float(v.value))
                val = val // 1000 if val > 5000 else val
                if val in BAUDRATES_KBPS:
                    return val
        except Exception:  # noqa: BLE001
            pass
    m = re.search(r"(125|250|500|1000)\s*k(?:bps|b)?", path.name, re.I)
    return int(m.group(1)) if m else None


def load(dbc_id: str) -> LoadedDbc:
    path = resolve(dbc_id)
    mtime = path.stat().st_mtime
    with _lock:
        hit = _cache.get(dbc_id)
        if hit and hit[0] == mtime:
            return hit[1]
    db, warnings = parse_text(_read_text(path))
    warnings += _repair_signals(db)
    for m in db.messages:
        if m.length > 8:
            warnings.append(f"{m.name}: DLC {m.length} > 8 (CAN FD) - disabled for classic CAN.")
    loaded = LoadedDbc(dbc_id, path, db, warnings, baud_hint(path, db))
    with _lock:
        _cache[dbc_id] = (mtime, loaded)
    return loaded


# -------------------------------------------------------------------- upload
def save_upload(system: str, customer: str, filename: str, data: bytes, overwrite: bool = False) -> dict:
    if system not in SYSTEMS:
        raise DbcError(f"Unknown system '{system}'.")
    if not data:
        raise DbcError("Empty file.")
    if len(data) > MAX_UPLOAD_BYTES:
        raise DbcError("File too large (max 8 MB).")
    name = _safe_part(Path(filename or "uploaded.dbc").stem, "uploaded") + ".dbc"
    customer = _safe_part(customer, "Uploaded")

    text = None
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            text = data.decode(enc); break
        except UnicodeDecodeError:
            continue
    if text is None or "BO_" not in text:
        raise DbcError("Not a DBC file (no BO_ message definitions found).")
    db, warnings = parse_text(text)
    warnings += _repair_signals(db)
    if not db.messages:
        raise DbcError("DBC parsed but contains no messages.")

    folder = LIBRARY_ROOT / system / customer
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / name
    if target.exists() and not overwrite:
        stem, i = target.stem, 2
        while (folder / f"{stem}_{i}.dbc").exists():
            i += 1
        target = folder / f"{stem}_{i}.dbc"
    target.write_bytes(data)
    rel = target.relative_to(LIBRARY_ROOT).as_posix()
    with _lock:
        _cache.pop(rel, None)
    return {"id": rel, "system": system, "customer": customer, "file": target.name,
            "messages": len(db.messages), "signals": sum(len(m.signals) for m in db.messages),
            "warnings": warnings}
