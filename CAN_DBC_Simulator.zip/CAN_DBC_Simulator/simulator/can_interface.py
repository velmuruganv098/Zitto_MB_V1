"""CAN bus manager: PEAK PCAN (python-can 'pcan') or a virtual bus.

Owns the python-can Bus, an RX thread, TX/RX statistics, bus-load estimate
and a trace ring buffer the UI polls.
"""
from __future__ import annotations

import collections
import logging
import threading
import time

import can

from .config import INTERFACES, TRACE_BUFFER

log = logging.getLogger(__name__)

# PCAN status bits (PCANBasic.h)
_PCAN_BITS = [
    (0x00001, "TX queue full"), (0x00002, "RX overrun (controller)"), (0x00004, "Bus light (error warning)"),
    (0x00008, "Bus heavy (error warning)"), (0x40000, "Bus passive"), (0x00010, "BUS OFF"),
    (0x00040, "RX queue overrun"), (0x00080, "TX queue overrun"),
    (0x00400, "Hardware already in use"), (0x01400, "Illegal hardware / not connected"),
    (0x02000, "Illegal net"), (0x04000, "Illegal parameter"),
]


def frame_bits(dlc: int, ext: bool) -> int:
    """Approximate on-wire bits incl. worst-case-ish stuffing (for bus load)."""
    base = (67 if ext else 47) + 8 * dlc
    stuff = ((54 if ext else 34) + 8 * dlc - 1) // 4
    return base + stuff


class BusManager:
    def __init__(self):
        self._bus: can.BusABC | None = None
        self._lock = threading.RLock()
        self._rx_thread: threading.Thread | None = None
        self._stop = threading.Event()
        self.interface = None
        self.channel = None
        self.bitrate_kbps = None
        self.connected_at = None
        self.decoder = None            # callable(frame_id) -> message name | None
        self.last_error = ""
        self._reset_stats()
        self.trace = collections.deque(maxlen=TRACE_BUFFER)
        self._seq = 0
        self.auto_recover = True
        self.recoveries = 0
        self.recovery_log = collections.deque(maxlen=20)
        self._bus_off = False
        self._tx_hold = False
        self._tx_err_streak = 0
        self.tx_skipped = 0
        threading.Thread(target=self._watchdog, name="can-watchdog", daemon=True).start()

    # ------------------------------------------------------------ stats
    def _reset_stats(self):
        self.tx_frames = self.rx_frames = self.tx_errors = self.rx_error_frames = 0
        self._bits_window = collections.deque()     # (t, bits, dir)
        self._tx_window = collections.deque()
        self._rx_window = collections.deque()

    def _account(self, dlc, ext, direction):
        now = time.monotonic()
        self._bits_window.append((now, frame_bits(dlc, ext)))
        (self._tx_window if direction == "TX" else self._rx_window).append(now)

    def _trim(self, now):
        for dq in (self._tx_window, self._rx_window):
            while dq and now - dq[0] > 1.0:
                dq.popleft()
        while self._bits_window and now - self._bits_window[0][0] > 1.0:
            self._bits_window.popleft()

    def _add_trace(self, direction, msg: can.Message, note=""):
        self._seq += 1
        t0 = self.connected_at or time.monotonic()
        name = ""
        if self.decoder and not msg.is_error_frame:
            try:
                name = self.decoder(msg.arbitration_id, msg.is_extended_id) or ""
            except Exception:  # noqa: BLE001
                name = ""
        self.trace.append({
            "seq": self._seq, "t": round(time.monotonic() - t0, 4), "dir": direction,
            "id": msg.arbitration_id, "ext": msg.is_extended_id, "dlc": msg.dlc,
            "data": msg.data[:msg.dlc].hex(" ").upper(), "name": name, "err": msg.is_error_frame, "note": note,
        })

    # ------------------------------------------------------- lifecycle
    @property
    def is_connected(self) -> bool:
        return self._bus is not None

    @staticmethod
    def available_channels() -> dict:
        out = {}
        for key, meta in INTERFACES.items():
            detected = []
            if key == "pcan":
                try:
                    detected = [c["channel"] for c in can.detect_available_configs(interfaces=["pcan"])]
                except Exception:  # noqa: BLE001
                    detected = []
            out[key] = {"label": meta["label"], "channels": meta["channels"], "detected": detected}
        return out

    def _open(self):
        kwargs = {"interface": self.interface, "channel": self.channel, "bitrate": self.bitrate_kbps * 1000}
        if self.interface == "virtual":
            kwargs["receive_own_messages"] = False
        if self.interface == "pcan" and self.auto_recover:
            kwargs["auto_reset"] = True          # PCAN_BUSOFF_AUTORESET in the driver
        return can.Bus(**kwargs)

    def connect(self, interface: str, channel: str, bitrate_kbps: int):
        if interface not in INTERFACES:
            raise ValueError(f"Unknown interface {interface}")
        self.disconnect()
        self.interface, self.channel, self.bitrate_kbps = interface, channel, int(bitrate_kbps)
        try:
            bus = self._open()
        except Exception as e:  # noqa: BLE001
            self.last_error = f"Connect failed: {e}"
            self.interface = None
            raise
        with self._lock:
            self._bus = bus
            self.connected_at = time.monotonic()
            self.last_error = ""
            self.recoveries = 0
            self.recovery_log.clear()
            self._bus_off = False
            self._reset_stats()
            self._stop.clear()
        self._start_rx()
        log.info("Connected %s %s @ %s kbps", interface, channel, bitrate_kbps)

    def _start_rx(self):
        self._rx_thread = threading.Thread(target=self._rx_loop, name="can-rx", daemon=True)
        self._rx_thread.start()

    def _stop_rx(self):
        self._stop.set()
        if self._rx_thread and self._rx_thread.is_alive():
            self._rx_thread.join(timeout=1.0)

    def disconnect(self):
        self._stop_rx()
        with self._lock:
            if self._bus is not None:
                try:
                    self._bus.shutdown()
                except Exception:  # noqa: BLE001
                    pass
            self._bus = None
            self.connected_at = None
            self._bus_off = False

    # ------------------------------------------------------- recovery
    def _status_code(self):
        bus = self._bus
        if bus is None or self.interface != "pcan":
            return None
        try:
            return int(bus.status())
        except Exception:  # noqa: BLE001
            return None

    @staticmethod
    def _unhealthy(code):
        return code is not None and bool(code & (0x10 | 0x40000 | 0x08))   # bus-off / passive / heavy

    def _log_recovery(self, text):
        self.recovery_log.append(f"{time.strftime('%H:%M:%S')} {text}")
        log.info("bus recovery: %s", text)

    def reset(self, reason="manual") -> dict:
        """Same as the Reset button in PCAN-View: CAN_Reset (restarts the controller, clears TX/RX queues).
        If the controller is still bus-off / passive / heavy afterwards, the channel is un-initialised and
        initialised again (like disconnect + connect in PCAN-View). Works without PCAN-View running."""
        steps = []
        if self._bus is None:
            return {"ok": False, "steps": ["not connected"]}
        self._tx_hold = True
        try:
            before = self._status_code()
            with self._lock:
                try:
                    ok = self._bus.reset() if hasattr(self._bus, "reset") else True
                    steps.append("CAN_Reset -> " + ("OK" if ok is not False else "failed"))
                except Exception as e:  # noqa: BLE001
                    ok = False
                    steps.append(f"CAN_Reset failed: {e}")
            time.sleep(0.08)
            after = self._status_code()
            if ok is False or self._unhealthy(after):
                steps.append("status 0x%05X after reset -> re-initialising channel" % (after or 0))
                self._stop_rx()
                with self._lock:
                    try:
                        self._bus.shutdown()
                    except Exception:  # noqa: BLE001
                        pass
                    try:
                        self._bus = self._open()
                        steps.append("channel re-initialised")
                    except Exception as e:  # noqa: BLE001
                        self._bus = None
                        self.connected_at = None
                        steps.append(f"re-init failed: {e}")
                        self.last_error = f"Recovery failed: {e}"
                if self._bus is not None:
                    self._stop.clear()
                    self._start_rx()
                after = self._status_code()
            with self._lock:
                self.tx_errors = 0
                self._tx_err_streak = 0
                self._bus_off = False
                if self._bus is not None:
                    self.last_error = ""
                self.recoveries += 1
            final = "OK" if not self._unhealthy(after) else "still 0x%05X" % after
            steps.append("status %s -> %s" % ("0x%05X" % before if before is not None else "-", final))
            self._log_recovery(f"{reason}: " + "; ".join(steps))
            return {"ok": self._bus is not None and not self._unhealthy(after), "steps": steps}
        finally:
            self._tx_hold = False

    def _watchdog(self):
        """Auto-recover from bus-off with back-off (1 s, 2 s, 4 s ... max 10 s)."""
        backoff, next_try = 1.0, 0.0
        while True:
            time.sleep(0.2)
            if self._bus is None:
                backoff = 1.0
                continue
            code = self._status_code()
            busoff = self._bus_off or (code is not None and code & 0x10)
            if not busoff:
                if code is not None and not self._unhealthy(code):
                    backoff = 1.0
                continue
            if not self.auto_recover:
                continue
            now = time.monotonic()
            if now >= next_try:
                self.reset(reason="auto (bus-off)")
                next_try = now + backoff
                backoff = min(10.0, backoff * 2)

    # -------------------------------------------------------------- io
    def send(self, msg: can.Message) -> bool:
        if self._tx_hold or self._bus_off:
            self.tx_skipped += 1
            return False
        with self._lock:
            bus = self._bus
            if bus is None:
                return False
            try:
                bus.send(msg, timeout=0.005)
                self.tx_frames += 1
                self._tx_err_streak = 0
                self._account(msg.dlc, msg.is_extended_id, "TX")
                self._add_trace("TX", msg)
                return True
            except Exception as e:  # noqa: BLE001
                self.tx_errors += 1
                self._tx_err_streak += 1
                self.last_error = f"TX error: {e}"
                low = str(e).lower()
                if "bus-off" in low or "busoff" in low or "bus off" in low:
                    self._bus_off = True          # stop hammering the driver until recovered
                return False

    def _rx_loop(self):
        while not self._stop.is_set():
            bus = self._bus
            if bus is None:
                break
            try:
                msg = bus.recv(timeout=0.1)
            except Exception as e:  # noqa: BLE001
                self.last_error = f"RX error: {e}"
                time.sleep(0.2)
                continue
            if msg is None:
                continue
            with self._lock:
                if msg.is_error_frame:
                    self.rx_error_frames += 1
                else:
                    self.rx_frames += 1
                self._account(msg.dlc, msg.is_extended_id, "RX")
                self._add_trace("RX", msg)

    # ---------------------------------------------------------- status
    def status(self) -> dict:
        now = time.monotonic()
        with self._lock:
            self._trim(now)
            bits = sum(b for _, b in self._bits_window)
            st = {
                "connected": self.is_connected, "interface": self.interface, "channel": self.channel,
                "bitrate_kbps": self.bitrate_kbps,
                "uptime_s": round(now - self.connected_at, 1) if self.connected_at else 0,
                "tx_frames": self.tx_frames, "rx_frames": self.rx_frames, "tx_errors": self.tx_errors,
                "rx_error_frames": self.rx_error_frames,
                "tx_fps": len(self._tx_window), "rx_fps": len(self._rx_window),
                "bus_load_pct": round(100.0 * bits / (self.bitrate_kbps * 1000), 1) if self.bitrate_kbps and
                self.is_connected else 0.0,
                "state": "DISCONNECTED", "level": "off", "detail": [], "last_error": self.last_error,
                "auto_recover": self.auto_recover, "recoveries": self.recoveries,
                "recovery_log": list(self.recovery_log)[-6:], "tx_skipped": self.tx_skipped,
            }
            if not self.is_connected:
                return st
            detail, level, state = [], "ok", "ERROR ACTIVE"
            bus = self._bus
            if self.interface == "pcan":
                code = None
                try:
                    code = bus.status()
                except Exception:  # noqa: BLE001
                    code = None
                if code is not None:
                    st["status_code"] = f"0x{code:05X}"
                    for bit, text in _PCAN_BITS:
                        if code & bit == bit and bit:
                            detail.append(text)
                    if code & 0x10:
                        level, state = "error", "BUS OFF"
                        detail.append("Bus-off: the controller saw too many errors (no ACK, bit-rate mismatch, "
                                      "wiring / termination). " + ("Auto-recovery is running." if self.auto_recover
                                                                   else "Press Reset controller."))
                    elif code & 0x40000:
                        level, state = "warn", "ERROR PASSIVE"
                    elif code & 0x0C:
                        level, state = "warn", "ERROR WARNING"
                    elif code & 0x1400 == 0x1400:
                        level, state = "error", "HW NOT FOUND"
                try:
                    bstate = bus.state
                    st["python_can_state"] = getattr(bstate, "name", str(bstate))
                except Exception:  # noqa: BLE001
                    pass
            else:
                state = "VIRTUAL OK"
            if self._bus_off and state != "BUS OFF":
                level, state = "error", "BUS OFF"
                detail.append("Driver reported bus-off on transmit - TX paused until recovery.")
            if self.tx_errors and self.tx_frames == 0:
                detail.append("Frames are not being acknowledged - check that another node is on the bus, "
                              "the bit rate matches and the bus has 120 ohm termination.")
                if level == "ok":
                    level = "warn"
            st.update(state=state, level=level, detail=detail)
            return st

    def trace_since(self, seq: int, limit: int = 300) -> list[dict]:
        with self._lock:
            items = [t for t in self.trace if t["seq"] > seq]
        return items[-limit:]
