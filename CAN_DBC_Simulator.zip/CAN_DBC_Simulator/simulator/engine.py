"""Simulation engine.

State        : physical value of every signal (DBC units) + role values (canonical units)
TX scheduler : one thread, per-message cycle time, multiplexer round-robin,
               alive-counter auto increment, preview when no bus is connected
Derivations  : pack voltage = sum(cells), max/min/avg/delta cell V & T with ids, power
Dynamics     : optional battery (SOC / OCV / thermal) and drive-cycle models
"""
from __future__ import annotations

import logging
import math
import re
import threading
import time

import can

from .analyzer import analyze, Analysis, sig_range, norm_unit, signal_kind, tokens
from .battery_model import BatteryModel, ocv
bm_ocv = ocv
from .can_interface import BusManager, frame_bits
from .config import DEFAULT_CYCLE_MS, MIN_CYCLE_MS, SYSTEMS
from .dbc_library import LoadedDbc

log = logging.getLogger(__name__)

def _mux_variants(tree, limit=256):
    """All multiplexer assignments of a cantools signal tree (nested mux ok)."""
    variants = [{}]
    for node in tree:
        if isinstance(node, dict):
            for mux_name, branches in node.items():
                new = []
                for val, sub in branches.items():
                    for sv in _mux_variants(sub, limit):
                        for base in variants:
                            new.append({**base, mux_name: val, **sv})
                            if len(new) >= limit:
                                break
                variants = new or variants
    return variants[:limit]


class Engine:
    def __init__(self, bus: BusManager):
        self.bus = bus
        self.lock = threading.RLock()
        self.loaded: LoadedDbc | None = None
        self.system = None
        self.db = None
        self.analysis: Analysis | None = None
        self.values: dict[str, dict[str, float]] = {}
        self.role_values: dict[str, float] = {}
        self.msgs: dict[str, dict] = {}
        self.vseq = 0
        self.tx_running = False
        self.options = {"auto_pack_voltage": True, "auto_stats": True, "auto_power": True,
                        "link_dc_bus": True, "counters": True}
        self.bm = BatteryModel()
        self.dyn = {
            "battery": self.bm.cfg,           # same dict: the model owns its configuration
            "drive": {"enabled": False, "max_rpm": 8000.0, "top_speed_kmh": 90.0, "max_torque_nm": 60.0,
                      "response_s": 1.5},
        }
        self._prot_sigs: dict[str, list] = {}
        self._bm_nseries = 1
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._loop, name="tx-scheduler", daemon=True)
        self._thread.start()
        self.bus.decoder = self._decode_name

    # ============================================================ loading
    def load(self, loaded: LoadedDbc, system: str):
        with self.lock:
            self.tx_running = False
            self.loaded, self.system, self.db = loaded, system, loaded.db
            self.analysis = analyze(loaded.db, system)
            self.values, self.role_values, self.msgs = {}, {}, {}
            self.bm.cfg["enabled"] = False
            focus = SYSTEMS.get(system, {}).get("panel")
            self._frame_index = {}
            for m in loaded.db.messages:
                vals = {}
                for s in m.signals:
                    init = s.initial if s.initial is not None else 0
                    if not isinstance(init, (int, float)):
                        init = 0
                    vals[s.name] = self._clamp(s, init if init is not None else 0)
                self.values[m.name] = vals
                supported = m.length <= 8
                cyc = m.cycle_time if m.cycle_time and m.cycle_time > 0 else DEFAULT_CYCLE_MS
                variants = _mux_variants(m.signal_tree) if m.is_multiplexed() else [{}]
                self.msgs[m.name] = {
                    "enabled": False, "cycle_ms": max(MIN_CYCLE_MS, int(cyc)), "supported": supported,
                    "tx_count": 0, "last_data": "", "variants": variants, "vidx": 0, "next_due": 0.0,
                    "focus": self.analysis.msg_system.get(m.name) == focus,
                }
                self._frame_index[(m.frame_id, m.is_extended_frame)] = m.name
            # default TX set: messages of the chosen system, else everything
            if not any(v["focus"] for v in self.msgs.values()):
                for v in self.msgs.values():
                    v["focus"] = True
            for v in self.msgs.values():
                v["enabled"] = v["focus"] and v["supported"]
            self._apply_role_defaults()
            self._prot_sigs = self._find_protection_flags()
            self.vseq += 1

    def _apply_role_defaults(self):
        a = self.analysis
        for key, role in a.roles.items():
            v = role.default
            if v is None:
                continue
            if role.kind == "number" and not (role.minimum <= v <= role.maximum):
                continue
            self._set_role(key, v, derive=False)
        if a.cells:
            for rk in a.cells:
                r = a.roles[rk]
                self._set_role(rk, 3.7 if r.minimum <= 3.7 <= r.maximum else (r.minimum + r.maximum) / 2,
                               derive=False)
        if "bms.pack_voltage" in a.roles and not a.cells:
            r = a.roles["bms.pack_voltage"]
            nominal = next((v for v in (350.0, 76.8, 51.2, 48.0) if r.minimum <= v <= r.maximum * 0.9), None)
            if nominal:
                self._set_role("bms.pack_voltage", nominal, derive=False)
        self._derive_all()

    # ============================================================ values
    @staticmethod
    def _clamp(sig, v: float) -> float:
        try:
            v = float(v)
        except (TypeError, ValueError):
            v = 0.0
        if math.isnan(v) or math.isinf(v):
            v = 0.0
        scale = sig.scale or 1
        off = sig.offset or 0
        raw = round((v - off) / scale)
        if sig.is_signed:
            lo, hi = -(1 << (sig.length - 1)), (1 << (sig.length - 1)) - 1
        else:
            lo, hi = 0, (1 << sig.length) - 1
        raw = min(hi, max(lo, raw))
        phys = raw * scale + off
        return round(phys, 9)

    def _sig(self, msg, sig):
        return self.db.get_message_by_name(msg).get_signal_by_name(sig)

    def _write_sig(self, msg, sig, v):
        s = self._sig(msg, sig)
        self.values[msg][sig] = self._clamp(s, v)

    def _set_role(self, key, value, derive=True, skip=None):
        role = self.analysis.roles.get(key)
        if role is None:
            return
        value = float(value)
        self.role_values[key] = value
        for b in role.bindings:
            if skip and (b.msg, b.sig) == skip:
                continue
            self._write_sig(b.msg, b.sig, b.to_sig(value))
        if derive:
            self._derive(key)

    def set_role(self, key, value):
        with self.lock:
            if self.bm.cfg["enabled"]:
                self._model_edit(key, float(value))
            self._set_role(key, value)
            self.vseq += 1

    def _model_edit(self, key, v):
        """Route a UI edit into the battery model so it sticks and then evolves physically."""
        a = self.analysis
        if key.startswith("bms.cell_v.") and key in a.cells:
            self.bm.set_cell_voltage(a.cells.index(key), v)
        elif key.startswith("bms.temp.") and key in a.temps:
            self.bm.set_temp(a.temps.index(key), v)
        elif key == "bms.soc":
            self.bm.set_pack_soc(v)
        elif key == "bms.current":
            self.bm.requested_i = v if self.bm.cfg["discharge_positive"] else -v
            if self.bm.cfg["mode"] != "manual":
                self.bm.configure(mode="manual")
        elif key == "bms.charge_mos":
            self.bm.user_chg_mos = bool(v)
        elif key == "bms.discharge_mos":
            self.bm.user_dsg_mos = bool(v)
        elif key == "bms.pack_voltage" and not a.cells and self._bm_nseries:
            self.bm.set_cell_voltage(0, v / self._bm_nseries)

    def set_signal(self, msg, sig, value):
        with self.lock:
            s = self._sig(msg, sig)
            v = self._clamp(s, value)
            self.values[msg][sig] = v
            rk = self.analysis.sig_role.get((msg, sig))
            if rk:
                b = next(b for b in self.analysis.roles[rk].bindings if (b.msg, b.sig) == (msg, sig))
                self._set_role(rk, b.to_role(v), skip=(msg, sig))
            self.vseq += 1
            return v

    def set_many_roles(self, updates: dict):
        with self.lock:
            for k, v in updates.items():
                if self.bm.cfg["enabled"]:
                    self._model_edit(k, float(v))
                self._set_role(k, v, derive=False)
            self._derive_all()
            self.vseq += 1

    # ======================================================= derivations
    def _has(self, k):
        return k in self.analysis.roles

    def _derive(self, key):
        if key.startswith("bms.cell_v.") or key == "bms.current":
            self._derive_cells()
        if key.startswith("bms.temp."):
            self._derive_temps()
        if key in ("bms.pack_voltage", "bms.current") or key.startswith("bms.cell_v."):
            self._derive_power()
        if key == "bms.pack_voltage" and self.options["link_dc_bus"] and self._has("mcu.dc_voltage"):
            self._set_role("mcu.dc_voltage", self.role_values.get("bms.pack_voltage", 0), derive=False)

    def _derive_all(self):
        self._derive_cells()
        self._derive_temps()
        self._derive_power()

    def _stats(self, keys):
        """((idx, max), (idx, min), avg) over role values; idx is 1-based."""
        vals = [(i + 1, self.role_values.get(k)) for i, k in enumerate(keys) if self.role_values.get(k) is not None]
        if not vals:
            return None
        mx = max(vals, key=lambda t: t[1])
        mn = min(vals, key=lambda t: t[1])
        return mx, mn, sum(v for _, v in vals) / len(vals)

    def _derive_cells(self):
        a = self.analysis
        if not a.cells or (not self.options["auto_stats"] and not self.options["auto_pack_voltage"]):
            return
        res = self._stats(a.cells)
        if not res:
            return
        (imx, vmx), (imn, vmn), avg = res
        if self.options["auto_stats"]:
            for k, v in (("bms.max_cell_v", vmx), ("bms.min_cell_v", vmn), ("bms.avg_cell_v", avg),
                         ("bms.delta_cell_v", vmx - vmn), ("bms.max_cell_v_id", imx), ("bms.min_cell_v_id", imn)):
                if self._has(k):
                    self._set_role(k, v, derive=False)
        if self.options["auto_pack_voltage"] and self._has("bms.pack_voltage"):
            total = sum(self.role_values.get(k, 0) for k in a.cells)
            self._set_role("bms.pack_voltage", total, derive=False)
            if self.options["link_dc_bus"] and self._has("mcu.dc_voltage"):
                self._set_role("mcu.dc_voltage", total, derive=False)

    def _derive_temps(self):
        a = self.analysis
        if not a.temps or not self.options["auto_stats"]:
            return
        res = self._stats(a.temps)
        if not res:
            return
        (imx, tmx), (imn, tmn), avg = res
        for k, v in (("bms.max_temp", tmx), ("bms.min_temp", tmn), ("bms.avg_temp", avg),
                     ("bms.delta_temp", tmx - tmn), ("bms.max_temp_id", imx), ("bms.min_temp_id", imn)):
            if self._has(k):
                self._set_role(k, v, derive=False)

    def _derive_power(self):
        if self.options["auto_power"] and self._has("bms.power"):
            p = self.role_values.get("bms.pack_voltage", 0) * self.role_values.get("bms.current", 0) / 1000.0
            role = self.analysis.roles["bms.power"]
            if norm_unit(role.unit) == "W":
                p *= 1000
            self._set_role("bms.power", p, derive=False)

    # ========================================================= dynamics
    def set_dynamics(self, cfg: dict):
        with self.lock:
            drv = cfg.get("drive")
            if isinstance(drv, dict):
                for k, v in drv.items():
                    if k in self.dyn["drive"]:
                        cur = self.dyn["drive"][k]
                        self.dyn["drive"][k] = bool(v) if isinstance(cur, bool) else type(cur)(v)
            bat = dict(cfg.get("battery") or {})
            action = bat.pop("action", None)
            was = self.bm.cfg["enabled"]
            if bat:
                self.bm.configure(**bat)
            if (self.bm.cfg["enabled"] and not was) or action == "sync":
                self._bm_start()
            if action == "clear_protections":
                self.bm.prot.clear()
                self.bm.user_chg_mos = self.bm.user_dsg_mos = True
            self.vseq += 1
            return self.dyn

    def _bm_start(self):
        """(Re)start the battery model from what the UI currently shows."""
        a = self.analysis
        cells = [self.role_values.get(k, 3.7) for k in a.cells]
        temps = [self.role_values.get(k, self.bm.cfg["ambient_c"]) for k in a.temps]
        if not temps and "bms.max_temp" in self.role_values:
            temps = [self.role_values["bms.max_temp"]]
        soc = self.role_values.get("bms.soc")
        self.bm.reset(cells, temps, soc)
        if not a.cells:
            pv = self.role_values.get("bms.pack_voltage", 0.0)
            cell = bm_ocv(self.bm.cfg["chemistry"], self.bm.cells[0]["soc"])
            self._bm_nseries = max(1, round(pv / cell)) if pv > 0 else 14
        if "bms.cycles" in self.role_values:
            self.bm.cycles_base = self.role_values["bms.cycles"]
        i = self.role_values.get("bms.current", 0.0)
        self.bm.requested_i = i if self.bm.cfg["discharge_positive"] else -i

    def _find_protection_flags(self) -> dict:
        """1-bit fault signals of battery messages the model drives (cell OV/UV, over/under temperature)."""
        pats = {
            "CELL_OV": r"(cell.*(over_?volt|volt_high|high_volt|\bhigh)|(^|_)ov(_|$)|over_?charge|full_?charge)",
            "CELL_UV": r"(cell.*(under_?volt|volt_low|low_volt|\blow)|(^|_)uv(_|$)|deep_?discharge)",
            "OT": r"(over_?temp|(^|_)ot(_|$)|temp_high|high_temp)",
            "UT": r"(under_?temp|(^|_)ut(_|$)|temp_low|low_temp)",
        }
        skip = ("sensor", "err", "fail", "board", "pcb", "mos", "fet", "sum", "pack", "soc", "diff", "motor",
                "mcu", "charger", "obc", "gun")
        out = {k: [] for k in pats}
        a = self.analysis
        for m in self.db.messages:
            if a.msg_system.get(m.name) != "battery":
                continue
            for sg in m.signals:
                if sg.length != 1 or (m.name, sg.name) in a.sig_role:
                    continue
                n = "_".join(tokens(sg.name))
                if any(w in n for w in skip):
                    continue
                for k, rx in pats.items():
                    if k.startswith("CELL") and "temp" in n:
                        continue
                    if re.search(rx, n):
                        out[k].append((m.name, sg.name))
                        break
        return out

    def set_options(self, opts: dict):
        with self.lock:
            for k, v in opts.items():
                if k in self.options:
                    self.options[k] = bool(v)
            self._derive_all()
            self.vseq += 1
            return self.options

    def _step_dynamics(self, dt):
        drv, bat = self.dyn["drive"], self.dyn["battery"]
        a = self.analysis
        changed = False
        if drv["enabled"]:
            thr = self.role_values.get("mcu.throttle", 0.0)
            brake = self.role_values.get("mcu.brake", 0.0) > 0
            rpm = self.role_values.get("mcu.rpm", 0.0)
            target = 0.0 if brake else max(0.0, min(100.0, thr)) / 100.0 * drv["max_rpm"]
            tau = drv["response_s"] * (0.4 if brake or target < rpm else 1.0)
            rpm += (target - rpm) * min(1.0, dt / max(0.05, tau))
            torque = drv["max_torque_nm"] * (thr / 100.0) * (1 - 0.6 * rpm / max(1, drv["max_rpm"]))
            if target < rpm:
                torque = -0.25 * drv["max_torque_nm"] * min(1.0, (rpm - target) / max(1, drv["max_rpm"]) * 4)
            speed = rpm / max(1, drv["max_rpm"]) * drv["top_speed_kmh"]
            for k, v in (("mcu.rpm", rpm), ("mcu.torque", torque), ("veh.speed", speed)):
                if self._has(k):
                    self._set_role(k, v, derive=False)
            dist = speed * dt / 3600.0
            for k in ("veh.odometer", "veh.trip"):
                if self._has(k):
                    self._set_role(k, self.role_values.get(k, 0.0) + dist, derive=False)
            vdc = self.role_values.get("mcu.dc_voltage") or self.role_values.get("bms.pack_voltage") or 48.0
            p_mech = torque * rpm * 2 * math.pi / 60.0
            idc = p_mech / 0.9 / max(1.0, vdc) if p_mech >= 0 else p_mech * 0.7 / max(1.0, vdc)
            for k in ("mcu.dc_current",):
                if self._has(k):
                    self._set_role(k, idc, derive=False)
            if self._has("mcu.phase_current"):
                self._set_role("mcu.phase_current", abs(torque) * 3.0, derive=False)
            if self._has("mcu.motor_temp"):
                t = self.role_values.get("mcu.motor_temp", 35.0)
                t += (abs(p_mech) / 1000.0 * 0.08 - (t - 30.0) * 0.01) * dt
                self._set_role("mcu.motor_temp", t, derive=False)
            if self._has("mcu.ctrl_temp"):
                t = self.role_values.get("mcu.ctrl_temp", 35.0)
                t += (abs(idc) * 0.004 - (t - 30.0) * 0.015) * dt
                self._set_role("mcu.ctrl_temp", t, derive=False)
            if self.options["link_dc_bus"]:
                if bat["enabled"]:
                    self.bm.requested_i = idc              # model decides what really flows (MOS / limits)
                elif self._has("bms.current"):
                    self._set_role("bms.current", idc if bat["discharge_positive"] else -idc, derive=False)
            changed = True
        if bat["enabled"]:
            self.bm.step(dt)
            self._bm_publish()
            changed = True
        if changed:
            self._derive_all()
            self.vseq += 1

    def _bm_publish(self):
        """Write the battery model state into the roles / signals."""
        bm, a = self.bm, self.analysis
        sign = 1.0 if bm.cfg["discharge_positive"] else -1.0
        vs = bm.voltages()
        if a.cells:
            for k, v in zip(a.cells, vs):
                self._set_role(k, v, derive=False)
        elif self._has("bms.pack_voltage"):
            self._set_role("bms.pack_voltage", vs[0] * self._bm_nseries, derive=False)
        if a.temps:
            for k, t in zip(a.temps, bm.temps):
                self._set_role(k, t, derive=False)
        elif bm.temps:
            for k in ("bms.max_temp", "bms.min_temp", "bms.avg_temp"):
                if self._has(k):
                    self._set_role(k, bm.temps[0], derive=False)
        for k, v in (("bms.soc", bm.pack_soc()), ("bms.remaining_cap", bm.remaining_ah()),
                     ("bms.full_cap", bm.full_ah()), ("bms.cycles", int(bm.cycles())),
                     ("bms.current", bm.i * sign), ("bms.charge_mos", 1.0 if bm.chg_mos else 0.0),
                     ("bms.discharge_mos", 1.0 if bm.dsg_mos else 0.0)):
            if self._has(k):
                self._set_role(k, v, derive=False)
            else:
                self.role_values[k] = v
        for idx, rk in a.balance.items():
            c = bm.cells[idx - 1] if idx - 1 < len(bm.cells) else None
            self._set_role(rk, 1.0 if c and c.get("bleed") else 0.0, derive=False)
        for name, sigs in self._prot_sigs.items():
            on = 1.0 if name in bm.prot else 0.0
            for m, sg in sigs:
                self._write_sig(m, sg, on)

    # ======================================================== transmission
    def _build_frame(self, name, info) -> can.Message | None:
        m = self.db.get_message_by_name(name)
        data = dict(self.values[name])
        if info["variants"] and info["variants"][0]:
            var = info["variants"][info["vidx"] % len(info["variants"])]
            info["vidx"] += 1
            data.update(var)
        if self.options["counters"]:
            for s in m.signals:
                if self.analysis.auto.get((name, s.name)) == "counter":
                    hi = sig_range(s)[1]
                    nv = self.values[name][s.name] + (s.scale or 1)
                    self.values[name][s.name] = self._clamp(s, nv if nv <= hi else 0)
        try:
            payload = m.encode(data, scaling=True, padding=False, strict=False)
        except Exception as e:  # noqa: BLE001
            info["last_error"] = str(e)[:120]
            return None
        info["last_data"] = payload.hex(" ").upper()
        return can.Message(arbitration_id=m.frame_id, is_extended_id=m.is_extended_frame,
                           data=payload, dlc=len(payload))

    def send_once(self, name):
        with self.lock:
            info = self.msgs[name]
            frame = self._build_frame(name, info)
        if frame is not None and self.bus.send(frame):
            info["tx_count"] += 1
            return True
        return False

    def set_message(self, name, enabled=None, cycle_ms=None):
        with self.lock:
            info = self.msgs[name]
            if enabled is not None:
                info["enabled"] = bool(enabled) and info["supported"]
            if cycle_ms is not None:
                info["cycle_ms"] = max(MIN_CYCLE_MS, int(cycle_ms))
            info["next_due"] = 0.0

    def set_all_messages(self, mode: str):
        with self.lock:
            for info in self.msgs.values():
                if mode == "all":
                    info["enabled"] = info["supported"]
                elif mode == "none":
                    info["enabled"] = False
                elif mode == "focus":
                    info["enabled"] = info["focus"] and info["supported"]

    def set_tx(self, running: bool):
        with self.lock:
            self.tx_running = bool(running)
            for info in self.msgs.values():
                info["next_due"] = 0.0

    def estimated_bits_per_s(self) -> float:
        """Bits/s the enabled TX set would put on the bus (for load estimate)."""
        bits = 0.0
        for m in (self.db.messages if self.db else []):
            info = self.msgs.get(m.name)
            if info and info["enabled"]:
                bits += frame_bits(m.length, m.is_extended_frame) * 1000.0 / info["cycle_ms"]
        return bits

    def _loop(self):
        last_dyn = time.monotonic()
        while not self._stop.is_set():
            now = time.monotonic()
            next_wake = now + 0.01
            to_send = []
            with self.lock:
                if self.db is not None:
                    if now - last_dyn >= 0.1:
                        dt, last_dyn = now - last_dyn, now
                        try:
                            self._step_dynamics(min(dt, 0.5))
                        except Exception:  # noqa: BLE001
                            log.exception("dynamics step failed")
                    if self.tx_running:
                        for name, info in self.msgs.items():
                            if not info["enabled"]:
                                continue
                            if info["next_due"] <= now:
                                frame = self._build_frame(name, info)
                                if frame is not None:
                                    to_send.append((info, frame))
                                period = info["cycle_ms"] / 1000.0
                                info["next_due"] = (info["next_due"] + period
                                                    if info["next_due"] and now - info["next_due"] < period
                                                    else now + period)
                            next_wake = min(next_wake, info["next_due"])
            for info, frame in to_send:
                if self.bus.send(frame):
                    info["tx_count"] += 1
            delay = next_wake - time.monotonic()
            if delay > 0:
                time.sleep(min(delay, 0.01))

    def shutdown(self):
        self._stop.set()

    # ============================================================ views
    def _decode_name(self, frame_id, ext):
        idx = getattr(self, "_frame_index", {})
        return idx.get((frame_id, ext))

    def model(self) -> dict:
        with self.lock:
            if self.db is None:
                return {}
            a = self.analysis
            msgs = []
            for m in sorted(self.db.messages, key=lambda m: m.frame_id):
                info = self.msgs[m.name]
                sigs = []
                for s in m.signals:
                    lo, hi = sig_range(s)
                    sigs.append({
                        "name": s.name, "unit": s.unit or "", "min": lo, "max": hi,
                        "step": abs(s.scale or 1), "start": s.start, "length": s.length,
                        "byte_order": s.byte_order, "signed": s.is_signed, "scale": s.scale, "offset": s.offset,
                        "choices": {int(k): str(v) for k, v in s.choices.items()} if s.choices else None,
                        "mux": bool(s.is_multiplexer), "mux_ids": s.multiplexer_ids, "kind": signal_kind(s),
                        "comment": (s.comment or "")[:200] if isinstance(s.comment, str) else "",
                        "role": a.sig_role.get((m.name, s.name)), "auto": a.auto.get((m.name, s.name)),
                    })
                msgs.append({
                    "name": m.name, "id": m.frame_id, "ext": m.is_extended_frame, "dlc": m.length,
                    "senders": m.senders, "system": a.msg_system.get(m.name), "cycle_ms": info["cycle_ms"],
                    "enabled": info["enabled"], "supported": info["supported"], "focus": info["focus"],
                    "mux_variants": len(info["variants"]) if info["variants"][0] else 0,
                    "comment": (m.comment or "")[:200] if isinstance(m.comment, str) else "", "signals": sigs,
                })
            return {
                "dbc": {"id": self.loaded.dbc_id, "system": self.system, "file": self.loaded.path.name,
                        "messages": len(self.db.messages),
                        "signals": sum(len(m.signals) for m in self.db.messages),
                        "extended": sum(1 for m in self.db.messages if m.is_extended_frame),
                        "baud_hint_kbps": self.loaded.baud_hint_kbps or SYSTEMS[self.system]["default_baud"],
                        "warnings": self.loaded.warnings[:50],
                        "nodes": [n.name for n in self.db.nodes]},
                "analysis": a.to_json(), "messages": msgs,
                "options": self.options, "dynamics": self.dyn,
            }

    def snapshot(self, with_signals=True) -> dict:
        with self.lock:
            out = {"vseq": self.vseq, "roles": dict(self.role_values), "tx_running": self.tx_running,
                   "bm": self.bm.status() if self.bm.cfg["enabled"] else None,
                   "prot_signals": {k: len(v) for k, v in self._prot_sigs.items()}}
            if with_signals:
                out["signals"] = {m: dict(v) for m, v in self.values.items()}
            return out

    def msg_stats(self) -> dict:
        with self.lock:
            return {n: {"tx": i["tx_count"], "data": i["last_data"], "en": i["enabled"], "cyc": i["cycle_ms"]}
                    for n, i in self.msgs.items()}
