"""Static configuration: paths, systems, bus options."""
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
WEB_ROOT = PROJECT_ROOT / "web"
LIBRARY_ROOT = PROJECT_ROOT / "dbc_library"
VERSION = (PROJECT_ROOT / "VERSION").read_text(encoding="utf-8").strip()

# Folder name -> display metadata. Order is the order shown in the UI.
SYSTEMS = {
    "BMS":         {"label": "Battery (BMS)",          "panel": "battery", "default_baud": 500},
    "MCU":         {"label": "Motor Controller (MCU)", "panel": "motor",   "default_baud": 500},
    "VCU_Vehicle": {"label": "Vehicle / VCU",          "panel": "vehicle", "default_baud": 500},
    "Charger":     {"label": "Charger & Station",      "panel": "charger", "default_baud": 500},
    "J1939_ICE":   {"label": "J1939 / ICE",            "panel": "vehicle", "default_baud": 250},
    "OBD2":        {"label": "OBD-II",                 "panel": "vehicle", "default_baud": 500},
    "Test":        {"label": "Test & Samples",         "panel": "signals", "default_baud": 500},
}

BAUDRATES_KBPS = [125, 250, 500, 1000]
DEFAULT_BAUD_KBPS = 500

INTERFACES = {
    "pcan":    {"label": "PEAK PCAN",               "channels": [f"PCAN_USBBUS{i}" for i in range(1, 9)]},
    "virtual": {"label": "Virtual (no hardware)",   "channels": ["vcan0"]},
}

DEFAULT_CYCLE_MS = 100
MIN_CYCLE_MS = 5
MAX_UPLOAD_BYTES = 8 * 1024 * 1024
TRACE_BUFFER = 2000
