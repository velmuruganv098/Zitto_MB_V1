"""CAN DBC Simulator - DBC-driven, UI-controllable EV ECU simulator for PCAN."""
from .config import VERSION as __version__  # noqa: F401
