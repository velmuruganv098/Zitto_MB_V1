"""HTTP server (Flask): REST API + static web UI."""
from __future__ import annotations

import logging

from flask import Flask, jsonify, request, send_from_directory

from . import dbc_library
from .can_interface import BusManager
from .config import BAUDRATES_KBPS, SYSTEMS, VERSION, WEB_ROOT
from .engine import Engine

log = logging.getLogger(__name__)


def create_app() -> Flask:
    app = Flask(__name__, static_folder=None)
    app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024
    bus = BusManager()
    engine = Engine(bus)
    app.extensions["sim"] = {"bus": bus, "engine": engine}

    def ok(**kw):
        return jsonify({"ok": True, **kw})

    def err(msg, code=400):
        return jsonify({"ok": False, "error": str(msg)}), code

    def need_dbc():
        if engine.db is None:
            raise dbc_library.DbcError("No DBC loaded - pick a system and a DBC first.")

    @app.errorhandler(dbc_library.DbcError)
    def _dbc_error(e):
        return err(e)

    @app.errorhandler(KeyError)
    def _key_error(e):
        return err(f"Unknown name: {e}", 404)

    # ------------------------------------------------------------ static
    @app.get("/")
    def index():
        return send_from_directory(WEB_ROOT, "index.html")

    @app.get("/<path:path>")
    def static_files(path):
        return send_from_directory(WEB_ROOT, path)

    # -------------------------------------------------------------- meta
    @app.get("/api/version")
    def version():
        return ok(version=VERSION, name="CAN DBC Simulator")

    @app.get("/api/config")
    def config():
        return ok(version=VERSION, baudrates=BAUDRATES_KBPS,
                  systems=[{"key": k, **v} for k, v in SYSTEMS.items()],
                  interfaces=BusManager.available_channels())

    # ----------------------------------------------------------- library
    @app.get("/api/library")
    def library():
        return ok(**dbc_library.list_library())

    @app.post("/api/library/upload")
    def upload():
        f = request.files.get("file")
        if f is None:
            return err("No file in request (field 'file').")
        info = dbc_library.save_upload(
            system=request.form.get("system", ""), customer=request.form.get("customer", "Uploaded"),
            filename=f.filename, data=f.read(), overwrite=request.form.get("overwrite") == "1")
        return ok(**info)

    # --------------------------------------------------------------- dbc
    @app.post("/api/dbc/load")
    def load_dbc():
        body = request.get_json(force=True)
        dbc_id = body.get("id", "")
        system = body.get("system") or dbc_id.split("/")[0]
        if system not in SYSTEMS:
            return err(f"Unknown system {system}")
        engine.load(dbc_library.load(dbc_id), system)
        return ok(model=engine.model())

    @app.get("/api/model")
    def model():
        return ok(model=engine.model())

    # ------------------------------------------------------------ values
    @app.post("/api/roles")
    def set_roles():
        need_dbc()
        body = request.get_json(force=True)
        updates = body.get("updates") or {}
        if len(updates) == 1:
            k, v = next(iter(updates.items()))
            engine.set_role(k, v)
        else:
            engine.set_many_roles(updates)
        return ok(state=engine.snapshot(with_signals=False))

    @app.post("/api/signals")
    def set_signals():
        need_dbc()
        body = request.get_json(force=True)
        applied = []
        for u in body.get("updates", []):
            applied.append({"msg": u["msg"], "sig": u["sig"], "value": engine.set_signal(u["msg"], u["sig"], u["value"])})
        return ok(applied=applied)

    @app.post("/api/options")
    def options():
        need_dbc()
        return ok(options=engine.set_options(request.get_json(force=True) or {}))

    @app.post("/api/dynamics")
    def dynamics():
        need_dbc()
        return ok(dynamics=engine.set_dynamics(request.get_json(force=True) or {}))

    # ---------------------------------------------------------- messages
    @app.post("/api/messages/<name>")
    def message_cfg(name):
        need_dbc()
        body = request.get_json(force=True) or {}
        engine.set_message(name, body.get("enabled"), body.get("cycle_ms"))
        return ok()

    @app.post("/api/messages/<name>/send")
    def message_send(name):
        need_dbc()
        if not bus.is_connected:
            return err("Bus not connected.")
        return ok(sent=engine.send_once(name))

    @app.post("/api/messages")
    def messages_bulk():
        need_dbc()
        engine.set_all_messages((request.get_json(force=True) or {}).get("mode", "focus"))
        return ok()

    @app.post("/api/tx")
    def tx():
        need_dbc()
        engine.set_tx(bool((request.get_json(force=True) or {}).get("running")))
        return ok(running=engine.tx_running)

    # --------------------------------------------------------------- bus
    @app.get("/api/bus/configs")
    def bus_configs():
        return ok(interfaces=BusManager.available_channels(), baudrates=BAUDRATES_KBPS)

    @app.post("/api/bus/connect")
    def bus_connect():
        body = request.get_json(force=True) or {}
        baud = int(body.get("bitrate_kbps", 500))
        if baud not in BAUDRATES_KBPS:
            return err(f"Unsupported baud rate {baud} kbps")
        if "auto_recover" in body:
            bus.auto_recover = bool(body["auto_recover"])
        try:
            bus.connect(body.get("interface", "pcan"), body.get("channel", "PCAN_USBBUS1"), baud)
        except Exception as e:  # noqa: BLE001
            return err(f"{e}", 500)
        return ok(status=bus.status())

    @app.post("/api/bus/disconnect")
    def bus_disconnect():
        engine.set_tx(False)
        bus.disconnect()
        return ok(status=bus.status())

    @app.post("/api/bus/reset")
    def bus_reset():
        res = bus.reset(reason="manual")
        return ok(result=res, status=bus.status())

    @app.post("/api/bus/options")
    def bus_options():
        body = request.get_json(force=True) or {}
        if "auto_recover" in body:
            bus.auto_recover = bool(body["auto_recover"])
        return ok(status=bus.status())

    # -------------------------------------------------------------- poll
    @app.get("/api/poll")
    def poll():
        vseq = int(request.args.get("vseq", -1))
        tseq = int(request.args.get("tseq", 0))
        want_sig = request.args.get("signals") == "1"
        want_msgs = request.args.get("msgs") == "1"
        out = {"bus": bus.status(), "tx_running": engine.tx_running}
        if engine.db is not None:
            est = engine.estimated_bits_per_s()
            out["tx_est_load_pct"] = round(100 * est / ((bus.bitrate_kbps or int(request.args.get("baud", 500)))
                                                       * 1000), 1)
            if engine.vseq != vseq:
                out["state"] = engine.snapshot(with_signals=want_sig)
            if want_msgs:
                out["msgs"] = engine.msg_stats()
        if request.args.get("trace") == "1":
            out["trace"] = bus.trace_since(tseq)
        return jsonify(out)

    return app
