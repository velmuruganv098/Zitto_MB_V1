"""Per-cell battery pack model (series string).

Each cell i:  soc_i, capacity_i (Ah), r_i (ohm)
    v_i   = OCV(soc_i) - I * r_i                         I > 0 = discharge
    soc_i -= (I + I_bleed_i) * dt / (3600 * cap_i) * 100

Operating modes
    manual     current comes from the UI (or the drive model)
    rest       I = 0
    discharge  constant current until a cell reaches the UV limit
    charge     CC at the set current until the highest cell reaches CV, then the current tapers
               to keep that cell at CV; finished at C/20 -> rest

Passive balancing (real time)
    a session starts when (Vmax - Vmin) >= start delta and the condition (charge / charge+idle / always)
    is met; every cell with (V_i - Vmin) > stop delta and V_i >= min balancing voltage bleeds
    I_bleed through its resistor. The session ends when the delta <= stop delta.
    Time to balance = excess charge of the highest cell / I_bleed - e.g. 1 Ah at 50 mA = 20 h.
    `time_scale` speeds the whole simulation up (1x = real time).

Protections (with hysteresis)  CELL_OV -> charge MOS off, CELL_UV -> discharge MOS off,
                               OT -> both off, UT -> charge MOS off
Thermal                        dT/dt = I^2 R / C_th - (T - T_amb) / tau
"""
from __future__ import annotations

import bisect
import math
import random

OCV = {  # SOC % -> cell open-circuit voltage
    "NMC": [(0, 2.60), (2, 3.05), (5, 3.30), (10, 3.45), (20, 3.56), (30, 3.62), (40, 3.68), (50, 3.74), (60, 3.82),
            (70, 3.90), (80, 3.98), (90, 4.07), (100, 4.18)],
    "LFP": [(0, 2.40), (2, 2.85), (5, 3.05), (10, 3.18), (20, 3.24), (30, 3.26), (40, 3.28), (50, 3.29), (60, 3.30),
            (70, 3.31), (80, 3.33), (90, 3.35), (95, 3.38), (100, 3.55)],
    "LTO": [(0, 1.50), (3, 1.85), (10, 2.10), (30, 2.25), (50, 2.30), (70, 2.36), (90, 2.45), (100, 2.70)],
}
CHEM_LIMITS = {   # cv, ov, uv, min balancing voltage
    "NMC": {"cv": 4.15, "ov": 4.25, "uv": 2.90, "bal_min": 3.60},
    "LFP": {"cv": 3.55, "ov": 3.65, "uv": 2.60, "bal_min": 3.30},
    "LTO": {"cv": 2.65, "ov": 2.80, "uv": 1.70, "bal_min": 2.30},
}


def ocv(chem: str, soc: float) -> float:
    pts = OCV.get(chem, OCV["NMC"])
    soc = min(100.0, max(0.0, soc))
    xs = [p[0] for p in pts]
    i = bisect.bisect_right(xs, soc)
    if i <= 0:
        return pts[0][1]
    if i >= len(pts):
        return pts[-1][1]
    (x0, y0), (x1, y1) = pts[i - 1], pts[i]
    return y0 + (y1 - y0) * (soc - x0) / (x1 - x0)


def soc_from_ocv(chem: str, v: float) -> float:
    """Inverse OCV (monotonic curves). Values outside the curve clamp to 0 / 100 %."""
    pts = OCV.get(chem, OCV["NMC"])
    if v <= pts[0][1]:
        return 0.0
    if v >= pts[-1][1]:
        return 100.0
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        if y0 <= v <= y1:
            return x0 + (x1 - x0) * (v - y0) / ((y1 - y0) or 1e-9)
    return 50.0


DEFAULTS = {
    "enabled": False, "chemistry": "NMC", "capacity_ah": 100.0, "capacity_spread_pct": 2.0, "cell_r_mohm": 1.5,
    "ambient_c": 30.0, "thermal_c_j_per_k": 900.0, "thermal_tau_s": 1800.0, "noise_mv": 0.0,
    "discharge_positive": True, "time_scale": 1.0,
    "mode": "manual", "discharge_a": 20.0, "charge_a": 20.0, "cv_v": 4.15, "cutoff_c_rate": 0.05,
    "protections": True, "ov_v": 4.25, "uv_v": 2.90, "ot_c": 60.0, "ut_charge_c": 0.0,
    "bal_enabled": True, "bal_start_mv": 30.0, "bal_stop_mv": 10.0, "bal_min_v": 3.60, "bal_current_ma": 50.0,
    "bal_when": "charge_idle",           # charge | charge_idle | always
}


class BatteryModel:
    def __init__(self):
        self.cfg = dict(DEFAULTS)
        self.cells: list[dict] = []
        self.temps: list[float] = []
        self.tbase: list[float] = []
        self.toff: list[float] = []
        self.i = 0.0                      # actual pack current, discharge positive
        self.requested_i = 0.0            # manual / drive request
        self.chg_mos = self.dsg_mos = True
        self.user_chg_mos = self.user_dsg_mos = True
        self.prot: set[str] = set()
        self.phase = "-"
        self.sim_time = 0.0
        self.throughput_ah = 0.0
        self.cycles_base = 0.0
        self.bal_session = False
        self._cv_i = 0.0

    # ----------------------------------------------------------- setup
    def configure(self, **kw):
        chem_changed = "chemistry" in kw and kw["chemistry"] != self.cfg["chemistry"]
        for k, v in kw.items():
            if k in self.cfg:
                cur = self.cfg[k]
                self.cfg[k] = v if isinstance(cur, str) else (bool(v) if isinstance(cur, bool) else float(v))
        if chem_changed:
            lim = CHEM_LIMITS.get(self.cfg["chemistry"], CHEM_LIMITS["NMC"])
            self.cfg.update(cv_v=lim["cv"], ov_v=lim["ov"], uv_v=lim["uv"], bal_min_v=lim["bal_min"])
        if "capacity_ah" in kw or "capacity_spread_pct" in kw or "cell_r_mohm" in kw:
            self._spread()
        if kw.get("mode") == "charge":
            self.phase, self._cv_i = "CC", self.cfg["charge_a"]
        elif "mode" in kw:
            self.phase = {"discharge": "DSG", "rest": "REST", "manual": "-"}.get(kw["mode"], "-")

    def _spread(self):
        rng = random.Random(42)
        sp = self.cfg["capacity_spread_pct"] / 100.0
        for c in self.cells:
            c["cap"] = self.cfg["capacity_ah"] * (1 + rng.uniform(-sp, sp))
            c["r"] = self.cfg["cell_r_mohm"] / 1000.0 * (1 + rng.uniform(-0.1, 0.1))

    def reset(self, cell_voltages: list[float], temps: list[float], soc_hint: float | None = None):
        """Start the model from the values currently shown in the UI."""
        chem = self.cfg["chemistry"]
        n = len(cell_voltages)
        self.cells = []
        for v in cell_voltages:
            soc = soc_from_ocv(chem, v) if v else (soc_hint if soc_hint is not None else 50.0)
            self.cells.append({"soc": soc, "cap": self.cfg["capacity_ah"], "r": 0.0015, "bleed": False})
        if n == 0:                                     # DBC without per-cell signals: one lumped "cell"
            self.cells = [{"soc": soc_hint if soc_hint is not None else 80.0, "cap": self.cfg["capacity_ah"],
                           "r": 0.0015, "bleed": False, "virtual": True}]
        self._spread()
        self.temps = list(temps) if temps else [self.cfg["ambient_c"]]
        self.tbase = list(self.temps)             # modelled part (I2R heating / cooling to ambient)
        self.toff = [0.0] * len(self.temps)       # user-imposed offset (hot spot, heater ...) - sticks
        self.prot.clear()
        self.chg_mos = self.dsg_mos = True
        self.sim_time = 0.0
        self.bal_session = False

    # ------------------------------------------------------- user edits
    def set_cell_voltage(self, idx: int, v: float):
        if 0 <= idx < len(self.cells):
            c = self.cells[idx]
            c["soc"] = soc_from_ocv(self.cfg["chemistry"], v + self.i * c["r"])

    def set_pack_soc(self, soc: float):
        cur = self.pack_soc()
        for c in self.cells:
            c["soc"] = min(100.0, max(0.0, c["soc"] + (soc - cur)))

    def set_temp(self, idx: int, t: float):
        """A temperature set in the UI is an imposed condition: it holds and the model's heating adds on top."""
        if 0 <= idx < len(self.temps):
            self.toff[idx] = float(t) - self.tbase[idx]
            self.temps[idx] = float(t)

    # ----------------------------------------------------------- outputs
    def cell_v(self, c) -> float:
        return ocv(self.cfg["chemistry"], c["soc"]) - self.i * c["r"]

    def voltages(self) -> list[float]:
        nz = self.cfg["noise_mv"] / 1000.0
        return [self.cell_v(c) + (random.gauss(0, nz) if nz > 0 else 0.0) for c in self.cells]

    def pack_soc(self) -> float:
        return sum(c["soc"] for c in self.cells) / max(1, len(self.cells))

    def full_ah(self) -> float:
        return min(c["cap"] for c in self.cells) if self.cells else self.cfg["capacity_ah"]

    def remaining_ah(self) -> float:
        return min(c["soc"] / 100.0 * c["cap"] for c in self.cells) if self.cells else 0.0

    def cycles(self) -> float:
        return self.cycles_base + self.throughput_ah / (2 * max(0.1, self.cfg["capacity_ah"]))

    def balance_eta_s(self) -> float | None:
        """Real-time seconds until the highest bleeding cell reaches the lowest cell."""
        ib = self.cfg["bal_current_ma"] / 1000.0
        if not self.cells or ib <= 0:
            return None
        lo = min(c["soc"] for c in self.cells)
        excess = max((c["soc"] - lo) / 100.0 * c["cap"] for c in self.cells)
        return excess / ib * 3600.0

    def status(self) -> dict:
        vs = [self.cell_v(c) for c in self.cells if not c.get("virtual")]
        delta = (max(vs) - min(vs)) * 1000 if vs else 0.0
        eta = self.balance_eta_s()
        return {
            "enabled": self.cfg["enabled"], "mode": self.cfg["mode"], "phase": self.phase,
            "sim_time_s": round(self.sim_time, 1), "time_scale": self.cfg["time_scale"],
            "current_a": round(self.i, 3), "requested_a": round(self.requested_i, 3),
            "chg_mos": self.chg_mos, "dsg_mos": self.dsg_mos, "protections": sorted(self.prot),
            "delta_mv": round(delta, 1), "bal_session": self.bal_session,
            "bleeding": [i + 1 for i, c in enumerate(self.cells) if c.get("bleed")],
            "bal_eta_s": round(eta) if eta is not None else None,
            "bal_eta_scaled_s": round(eta / max(1e-9, self.cfg["time_scale"])) if eta is not None else None,
            "cell_soc": [round(c["soc"], 3) for c in self.cells if not c.get("virtual")],
            "pack_soc": round(self.pack_soc(), 3), "remaining_ah": round(self.remaining_ah(), 3),
            "full_ah": round(self.full_ah(), 3), "cycles": round(self.cycles(), 3),
            "temp_max": round(max(self.temps), 2) if self.temps else None,
        }

    # ------------------------------------------------------------- step
    def step(self, dt_real: float):
        if not self.cfg["enabled"] or not self.cells:
            return
        total = dt_real * max(0.0, self.cfg["time_scale"])
        n = max(1, math.ceil(total / 2.0))                 # sub-steps of <= 2 s simulated
        for _ in range(n):
            self._substep(total / n)

    def _substep(self, dt: float):
        cfg = self.cfg
        self.sim_time += dt
        vs = [self.cell_v(c) for c in self.cells]
        vmax, vmin = max(vs), min(vs)
        tmax, tmin = (max(self.temps), min(self.temps)) if self.temps else (cfg["ambient_c"],) * 2

        # ---- protections (hysteresis)
        if cfg["protections"]:
            self._latch("CELL_OV", vmax >= cfg["ov_v"], vmax < cfg["ov_v"] - 0.05)
            self._latch("CELL_UV", vmin <= cfg["uv_v"], vmin > cfg["uv_v"] + 0.10)
            self._latch("OT", tmax >= cfg["ot_c"], tmax < cfg["ot_c"] - 5)
            self._latch("UT", tmin < cfg["ut_charge_c"] and self.i < 0, tmin >= cfg["ut_charge_c"] + 2)
        else:
            self.prot.clear()
        self.chg_mos = self.user_chg_mos and not (self.prot & {"CELL_OV", "OT", "UT"})
        self.dsg_mos = self.user_dsg_mos and not (self.prot & {"CELL_UV", "OT"})

        # ---- current request per mode
        mode = cfg["mode"]
        if mode == "rest":
            req = 0.0
        elif mode == "discharge":
            req = cfg["discharge_a"]
            if "CELL_UV" in self.prot:
                cfg["mode"], self.phase, req = "rest", "UV STOP", 0.0
        elif mode == "charge":
            req = self._cc_cv(vmax, dt)
        else:
            req = self.requested_i
        if req > 0 and not self.dsg_mos:
            req = 0.0
        if req < 0 and not self.chg_mos:
            req = 0.0
        self.i = req

        # ---- balancing
        allowed = {"charge": self.i < -0.05, "charge_idle": self.i <= 0.5,
                   "always": True}.get(cfg["bal_when"], True)
        delta = vmax - vmin
        if cfg["bal_enabled"] and allowed and len(self.cells) > 1:
            if not self.bal_session and delta * 1000 >= cfg["bal_start_mv"]:
                self.bal_session = True
            if self.bal_session and delta * 1000 <= cfg["bal_stop_mv"]:
                self.bal_session = False
        else:
            self.bal_session = False
        ib = cfg["bal_current_ma"] / 1000.0
        for c, v in zip(self.cells, vs):
            c["bleed"] = bool(self.bal_session and (v - vmin) * 1000 > cfg["bal_stop_mv"] and v >= cfg["bal_min_v"])

        # ---- charge integration
        for c in self.cells:
            i_cell = self.i + (ib if c["bleed"] else 0.0)
            c["soc"] = min(100.0, max(0.0, c["soc"] - i_cell * dt / (3600.0 * c["cap"]) * 100.0))
        self.throughput_ah += abs(self.i) * dt / 3600.0

        # ---- thermal (pack current heats every sensor equally, bleed resistors add a little)
        r_pack = sum(c["r"] for c in self.cells)
        p = self.i * self.i * r_pack / max(1, len(self.temps))
        a = min(1.0, dt / cfg["thermal_tau_s"])          # stable for large time-scale steps
        for k, b in enumerate(self.tbase):
            b += p / cfg["thermal_c_j_per_k"] * dt - (b - cfg["ambient_c"]) * a
            self.tbase[k] = b
            self.temps[k] = b + self.toff[k]

    def _latch(self, name, trip, clear):
        if trip:
            self.prot.add(name)
        elif clear:
            self.prot.discard(name)

    def _cc_cv(self, vmax: float, dt: float) -> float:
        cfg = self.cfg
        cutoff = cfg["cutoff_c_rate"] * cfg["capacity_ah"]
        if self.phase in ("DONE",):
            return 0.0
        if self.phase != "CV" and vmax >= cfg["cv_v"]:
            self.phase, self._cv_i = "CV", cfg["charge_a"]
        if self.phase == "CV":
            # proportional taper keeping the highest cell at cv_v
            err = vmax - cfg["cv_v"]
            self._cv_i = max(0.0, min(cfg["charge_a"], self._cv_i * (1 - min(0.5, max(-0.2, err / 0.005)) * min(1.0, dt))))
            if self._cv_i <= cutoff:
                self.phase, cfg["mode"] = "DONE", "rest"
                return 0.0
            return -self._cv_i
        self.phase = "CC"
        return -cfg["charge_a"]
