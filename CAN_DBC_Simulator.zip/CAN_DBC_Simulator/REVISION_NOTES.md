# CAN DBC Simulator — Revision Notes

Branch convention (same as the firmware repo): `dev/sim-v<version>_<Short_Description>`.
Use `python tools/bump_version.py <x.y.z> "<title>"` to open a new entry.

## V1.1.0
Base: V1.0.0 (dev/sim-v1.0.0_Initial_Release)
Branch: dev/sim-v1.1.0_Battery_Sim_BusOff_Recovery

### Issue
1. "TX error: ... the CAN controller is in bus-off state", bus heavy / bus off; Reset had to work like
   PCAN-View's Reset without PCAN-View open.
2. PDF / DOCX / XLSX specs in BB CAN DBC were not available as DBCs.
3. Temperatures could not be varied.
4. UI to be optimised and cross-verified.
5. Cell balancing had to behave in real time (start delta, cell capacity, balancing current).
6. With the simulator started the pack had to behave like a real battery.

### Updates
- can_interface.py: reset() = CAN_Reset + status check + channel re-init fallback; bus-off watchdog with
  back-off, PCAN_BUSOFF_AUTORESET, TX paused while bus-off, recovery log / count in status.
- battery_model.py (new): per-cell equivalent-circuit model, CC-CV, balancing, protections, thermal, cycles.
- engine.py: model integration (UI edits routed into the model, outputs written to roles / fault bits).
- analyzer.py: signal_kind() - special-value tables stay numeric; state codes never feed numeric roles.
- web: Battery simulator card, per-cell SOC / bleeding, temperature steppers, editing guard, bus reset feedback,
  auto-recover switch.
- tools/convert_bb_docs.py (new) + 6 *_from_spec.dbc in dbc_library and BB CAN DBC/Converted_DBC.

### Files
- simulator/battery_model.py, simulator/can_interface.py, simulator/engine.py, simulator/analyzer.py,
  simulator/server.py
- web/js/panels/battery.js, web/js/panels/sidebar.js, web/js/ui.js, web/js/store.js, web/js/app.js,
  web/js/api.js, web/css/app.css
- tools/convert_bb_docs.py, dbc_library/**/_from_spec.dbc, tests/test_battery_model.py, tests/test_bus_recovery.py
- VERSION, CHANGELOG.md, REVISION_NOTES.md, README.md

## V1.0.0
Base: none (new project)
Branch: dev/sim-v1.0.0_Initial_Release

### Issue
Need a controllable EV ECU simulator driven by the customer DBCs: pick a product and DBC, change values in a UI
(cells, SOC, rpm, speed ...) and see the matching CAN frames on the PCAN bus.

### Updates
- Flask server + REST API, python-can PCAN / virtual bus, cantools encoding, per-message scheduler.
- DBC library imported from `C:\Projects\BB CAN DBC` (183 unique files) with upload support.
- Analyzer that builds Battery / Motor / Vehicle / Charger panels from signal names, units and sizes.
- Battery and drive physics models, auto-derived pack statistics.
- PCAN bus status panel, TX table, bus trace.

### Files
- simulator/ (config, dbc_library, analyzer, engine, can_interface, server)
- web/ (index.html, css/app.css, js/*)
- dbc_library/, tools/, tests/
