"""One-shot importer: copy every *unique* DBC from the 'BB CAN DBC' collection
into dbc_library/<System>/<Customer>/ with clean names.

    python tools/import_bb_dbc.py "C:\\Projects\\BB CAN DBC"

- byte-identical copies are skipped (MD5)
- hidden Unicode chars in names (Google-Drive artefact) are removed
- cloud-export UUID files are renamed <project>__<uuid8>.dbc
- a manifest (dbc_library/IMPORT_MANIFEST.csv) records source -> target
"""
from __future__ import annotations

import csv
import hashlib
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LIB = ROOT / "dbc_library"
SKIP_EXT = (".html", ".htm", ".ipynb", ".txt", ".pdf", ".zip", ".png", ".xlsx", ".sql", ".docx", ".csv")
BO = re.compile(r"^BO_\s+\d+\s+(\w+)", re.M)


def names_of(text):
    return set(BO.findall(text))


def classify(rel: str, names: set[str]) -> tuple[str, str]:
    """Return (system_folder, customer_folder)."""
    p = rel.lower()
    has = lambda *n: any(x in names for x in n)            # noqa: E731
    pre = lambda s: any(n.startswith(s) for n in names)    # noqa: E731
    if pre("OBD2"): return "OBD2", "Generic"
    if "/bosch/" in p or "bosch_j1939" in p: return "J1939_ICE", "Bosch"
    if "/mytvs/" in p: return "J1939_ICE", "myTVS"
    if "tvs" in p: return "J1939_ICE", "TVS"
    if "wiman" in p: return "J1939_ICE", "Wiman_EzeeInfo"
    if "testproject" in p or "sample.dbc" in p or "byte_beam_dbc" in p or "testinggalaxy" in p:
        return "Test", "Bytebeam_Samples"
    if pre("BMS_Pack_Voltg_Curr") or pre("DBGbms_") or pre("DBGdtu_") or "matter" in p or "dbc_files_bytebeam" in p:
        return "VCU_Vehicle", "Matter"
    if has("GPIO_Output", "station_session_info", "heater_chiller_sequence"): return "Charger", "Exponent_ePump_P4"
    if has("Rectifier_Status_Faults"): return "Charger", "Exponent_Rectifier"
    if pre("CI_Message") or pre("CI_Data"): return "Charger", "Exponent_CI_Telemetry"
    if pre("gbt_") or pre("osm_msg") or pre("ticm_msg") or has("min_max_voltage_temp", "bms_fw_hw_version",
                                                                "Debug_SOC_Override", "afe_config_details",
                                                                "bms_oem_hw_pack_version"):
        return "BMS", "Exponent_ePack"
    if pre("m_bms_"): return "BMS", "BRE_Piccolo"
    if has("StationData1") or pre("BS1_SF"): return "Charger", "Electorq_SwapStation"
    if pre("BMSF_") or pre("MCU_All_"): return "VCU_Vehicle", "Simple_Energy"
    if "river" in p: return "VCU_Vehicle", "River"
    if "lxg" in p or "royalenfield" in p: return "VCU_Vehicle", "Royal_Enfield"
    if "evage" in p or "n1_gen" in p: return "VCU_Vehicle", "EVage"
    if any(k in p for k in ("tec_", "energy_company", "theenergy")): return "BMS", "TEC_EnergyCompany"
    if "lohum" in p: return "BMS", "Lohum"
    if "lectrix" in p or "master_dbc" in p: return "VCU_Vehicle", "Lectrix"
    if "jbm" in p: return "BMS", "JBM"
    if "fes_bms" in p or "fashmo" in p: return "BMS", "Fashmo_FES"
    if "glx_v2" in p or "bullwork" in p: return "VCU_Vehicle", "Bullwork"
    table = {
        "2w_vcan": ("VCU_Vehicle", "2W_VCAN_Generic"), "amem_mc50": ("MCU", "AMeM"),
        "mc_database_scooter": ("MCU", "Scooter_MC"), "numeros": ("VCU_Vehicle", "Numeros"),
        "l2outputcan": ("BMS", "L2_Output"), "log9": ("BMS", "Log9"), "vidur": ("BMS", "Vidur"),
        "corrit": ("BMS", "Corrit"), "smart_charger": ("Charger", "Daly_Smart_Charger"),
        "ekaevbus": ("BMS", "EKA_eBus"), "freshbus": ("VCU_Vehicle", "FreshBus"),
        "kptl": ("VCU_Vehicle", "KPTL_eBus"), "vdlpinnacle": ("VCU_Vehicle", "VDL_Pinnacle"),
        "ebiketest": ("VCU_Vehicle", "eBike_Test"),
    }
    for k, v in table.items():
        if k in p: return v
    return "Test", "Unsorted"


def clean_name(rel: str) -> str:
    rel = re.sub("[\ue000-\uf8ff]", "", rel)
    parts = rel.split("/")
    if parts[0] == "dbcs" and len(parts) >= 5:          # dbcs/dbcs/<tenant>/<project>/<uuid>.dbc
        return f"{parts[-2]}__{parts[-1][:8]}.dbc"
    name = parts[-1]
    name = re.sub(r"\s*\(\d+\)", "", name)              # drop ' (1)' download suffix
    name = re.sub(r"\.dbc.*$", "", name, flags=re.I)
    name = re.sub(r"[^A-Za-z0-9_.\-]+", "_", name).strip("_")
    return name + ".dbc"


def main(src: Path):
    files = []
    for f in src.rglob("*"):
        if not f.is_file() or "__MACOSX" in f.parts: continue
        low = f.name.lower()
        if "dbc" not in low or low.endswith(SKIP_EXT): continue
        data = f.read_bytes()
        if b"BO_ " not in data: continue
        rel = f.relative_to(src).as_posix()
        files.append((rel, f, data))
    # prefer root, non-"(n)" names as the canonical copy
    files.sort(key=lambda t: (t[0].startswith("dbcs/"), "(" in t[0], t[0].lower()))
    seen, rows, taken = {}, [], set()
    for rel, f, data in files:
        md5 = hashlib.md5(data).hexdigest()
        if md5 in seen:
            rows.append((rel, "", seen[md5], "duplicate")); continue
        text = data.decode("utf-8", "replace")
        system, customer = classify(re.sub("[\ue000-\uf8ff]", "", rel), names_of(text))
        name = clean_name(rel)
        target = LIB / system / customer / name
        i = 2
        while target.as_posix().lower() in taken:
            target = target.with_name(f"{Path(name).stem}_{i}.dbc"); i += 1
        taken.add(target.as_posix().lower())
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(f, target)
        tid = target.relative_to(LIB).as_posix()
        seen[md5] = tid
        rows.append((rel, tid, "", "imported"))
    with open(LIB / "IMPORT_MANIFEST.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["source (BB CAN DBC)", "library id", "duplicate of", "status"])
        w.writerows(sorted(rows, key=lambda r: (r[3], r[1] or r[2])))
    n = sum(1 for r in rows if r[3] == "imported")
    print(f"imported {n} unique DBCs, skipped {len(rows) - n} duplicates -> {LIB}")


if __name__ == "__main__":
    main(Path(sys.argv[1] if len(sys.argv) > 1 else r"C:\Projects\BB CAN DBC"))
