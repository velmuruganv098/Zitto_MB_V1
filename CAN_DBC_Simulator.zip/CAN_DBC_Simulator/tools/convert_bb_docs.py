"""Convert the CAN specifications found in 'BB CAN DBC' (PDF / DOCX / XLSX) into DBC files.

    python tools/convert_bb_docs.py ["C:\\Projects\\BB CAN DBC"]

Every DBC is built with cantools, written to
    dbc_library/<System>/<Customer>/<name>_from_spec.dbc      (simulator library)
    <BB CAN DBC>/Converted_DBC/<name>_from_spec.dbc           (next to the sources)
then re-loaded and every message encoded once as a self-check.
Assumptions the source documents leave open are written into the DBC as CM_ comments.
"""
from __future__ import annotations

import re
import shutil
import sys
from pathlib import Path

import cantools
from cantools.database.can import Database, Message, Node
from cantools.database.can import Signal as _Signal
from cantools.database.conversion import BaseConversion


def Signal(name, start, length, scale=1, offset=0, choices=None, **kw):
    """cantools >= 39 takes a conversion object; keep the familiar scale/offset/choices API."""
    kw["conversion"] = BaseConversion.factory(scale=scale, offset=offset, choices=choices)
    return _Signal(name, start, length, **kw)

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from simulator.engine import _mux_variants  # noqa: E402
LIB = ROOT / "dbc_library"


# ------------------------------------------------------------------ helpers
def le(name, byte, length=8, **kw):
    """Intel signal starting at byte `byte` (0-based)."""
    return Signal(name, start=byte * 8 + kw.pop("bit", 0), length=length, byte_order="little_endian", **kw)


def be(name, byte, length=16, **kw):
    """Motorola signal whose MSB is in byte `byte` (0-based)."""
    return Signal(name, start=byte * 8 + 7, length=length, byte_order="big_endian", **kw)


def bit(name, byte, b, **kw):
    return Signal(name, start=byte * 8 + b, length=1, byte_order="little_endian", **kw)


def mux(sig: Signal, ids, parent) -> Signal:
    sig.multiplexer_ids = list(ids)
    sig.multiplexer_signal = parent
    return sig


def write(db: Database, system: str, customer: str, name: str, src_root: Path) -> Path:
    text = db.as_dbc_string()
    # cantools writes nested multiplexors as plain "M"; Vector syntax is m<id>M
    for m in db.messages:
        for s in m.signals:
            if s.is_multiplexer and s.multiplexer_ids:
                text = text.replace(f" SG_ {s.name} M :", f" SG_ {s.name} m{s.multiplexer_ids[0]}M :")
    # self check: reload + encode every message
    chk = cantools.database.load_string(text, strict=False)
    for m in chk.messages:
        base = {s.name: 0 for s in m.signals}
        for var in (_mux_variants(m.signal_tree) if m.is_multiplexed() else [{}]):
            m.encode({**base, **var}, strict=False)
    out = LIB / system / customer / f"{name}_from_spec.dbc"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text, encoding="utf-8")
    conv = src_root / "Converted_DBC"
    conv.mkdir(exist_ok=True)
    shutil.copyfile(out, conv / out.name)
    print(f"  {out.relative_to(ROOT)}  ({len(chk.messages)} msgs, {sum(len(m.signals) for m in chk.messages)} signals)")
    return out


def comment(obj, text):
    obj.comment = text
    return obj


# ============================================================ 1. Daly BMS
def daly():
    """Daly CAN Communications Protocol V1.0 (Daly_CAN_com_FIXED_Battery.pdf). 250 kbps, 29-bit,
    responses 0x18<DataID>4001 (BMS 0x01 -> upper computer 0x40), multi-byte values big-endian."""
    rid = lambda did: 0x18004001 | (did << 16)   # noqa: E731
    msgs = []
    msgs.append(Message(rid(0x90), "Daly_SOC_Total_Voltage_Current", 8, [
        be("Cumulative_Total_Voltage", 0, scale=0.1, unit="V", minimum=0, maximum=6553.5),
        be("Gather_Total_Voltage", 2, scale=0.1, unit="V", minimum=0, maximum=6553.5),
        be("Current", 4, scale=0.1, offset=-3000, unit="A", minimum=-3000, maximum=3553.5),
        be("SOC", 6, scale=0.1, unit="%", minimum=0, maximum=100),
    ], senders=["BMS"], is_extended_frame=True, cycle_time=1000))
    msgs.append(Message(rid(0x91), "Daly_Max_Min_Voltage", 8, [
        be("Max_Cell_Voltage", 0, unit="mV", minimum=0, maximum=5000), le("Max_Cell_Voltage_No", 2),
        be("Min_Cell_Voltage", 3, unit="mV", minimum=0, maximum=5000), le("Min_Cell_Voltage_No", 5),
    ], senders=["BMS"], is_extended_frame=True, cycle_time=1000))
    msgs.append(Message(rid(0x92), "Daly_Max_Min_Temperature", 8, [
        le("Max_Temperature", 0, offset=-40, unit="degC", minimum=-40, maximum=215), le("Max_Temperature_Cell_No", 1),
        le("Min_Temperature", 2, offset=-40, unit="degC", minimum=-40, maximum=215), le("Min_Temperature_Cell_No", 3),
    ], senders=["BMS"], is_extended_frame=True, cycle_time=1000))
    msgs.append(Message(rid(0x93), "Daly_Charge_Discharge_MOS_Status", 8, [
        le("State", 0, choices={0: "Stationary", 1: "Charge", 2: "Discharge"}),
        le("Charge_MOS_State", 1, choices={0: "OFF", 1: "ON"}),
        le("Discharge_MOS_State", 2, choices={0: "OFF", 1: "ON"}),
        le("BMS_Life", 3, unit="cycles"),
        be("Remain_Capacity", 4, length=32, unit="mAh"),
    ], senders=["BMS"], is_extended_frame=True, cycle_time=1000))
    st = [le("No_Of_Battery_String", 0), le("No_Of_Temperature", 1),
          le("Charger_Status", 2, choices={0: "Disconnect", 1: "Access"}),
          le("Load_Status", 3, choices={0: "Disconnect", 1: "Access"})]
    st += [bit(f"DI{i + 1}_State", 4, i) for i in range(4)] + [bit(f"DO{i + 1}_State", 4, 4 + i) for i in range(4)]
    msgs.append(Message(rid(0x94), "Daly_Status_Information_1", 8, st, senders=["BMS"], is_extended_frame=True,
                        cycle_time=1000))
    # 0x95 cell voltages: frame number + 3 cells per frame, 16 frames = 48 cells
    fr = Signal("Cell_Voltage_Frame_No", 0, 8, is_multiplexer=True)
    sigs = [fr]
    for f in range(16):
        for k in range(3):
            n = f * 3 + k + 1
            sigs.append(mux(be(f"Cell_{n}_Voltage", 1 + 2 * k, unit="mV", minimum=0, maximum=5000), [f], fr.name))
    msgs.append(comment(Message(rid(0x95), "Daly_Cell_Voltages", 8, sigs, senders=["BMS"], is_extended_frame=True,
                                cycle_time=1000),
                        "Byte0 frame number (spec: starting from 0, 0xFF invalid); frame n carries cells 3n+1..3n+3."))
    ft = Signal("Cell_Temp_Frame_No", 0, 8, is_multiplexer=True)
    sigs = [ft]
    for f in range(3):
        for k in range(7):
            n = f * 7 + k + 1
            if n > 16:
                break
            sigs.append(mux(le(f"Cell_Temp_{n}", 1 + k, offset=-40, unit="degC", minimum=-40, maximum=215), [f], ft.name))
    msgs.append(Message(rid(0x96), "Daly_Cell_Temperatures", 8, sigs, senders=["BMS"], is_extended_frame=True,
                        cycle_time=1000))
    msgs.append(Message(rid(0x97), "Daly_Cell_Balance_State", 8,
                        [bit(f"Cell_{n}_Balance_State", (n - 1) // 8, (n - 1) % 8, choices={0: "Closed", 1: "Open"})
                         for n in range(1, 49)], senders=["BMS"], is_extended_frame=True, cycle_time=1000))
    flt = {0: ["Cell_Volt_High_L1", "Cell_Volt_High_L2", "Cell_Volt_Low_L1", "Cell_Volt_Low_L2",
               "Sum_Volt_High_L1", "Sum_Volt_High_L2", "Sum_Volt_Low_L1", "Sum_Volt_Low_L2"],
           1: ["Chg_Temp_High_L1", "Chg_Temp_High_L2", "Chg_Temp_Low_L1", "Chg_Temp_Low_L2",
               "Dischg_Temp_High_L1", "Dischg_Temp_High_L2", "Dischg_Temp_Low_L1", "Dischg_Temp_Low_L2"],
           2: ["Chg_Overcurrent_L1", "Chg_Overcurrent_L2", "Dischg_Overcurrent_L1", "Dischg_Overcurrent_L2",
               "SOC_High_L1", "SOC_High_L2", "SOC_Low_L1", "SOC_Low_L2"],
           3: ["Diff_Volt_L1", "Diff_Volt_L2", "Diff_Temp_L1", "Diff_Temp_L2"],
           4: ["Chg_MOS_Temp_High_Alarm", "Dischg_MOS_Temp_High_Alarm", "Chg_MOS_Temp_Sensor_Err",
               "Dischg_MOS_Temp_Sensor_Err", "Chg_MOS_Adhesion_Err", "Dischg_MOS_Adhesion_Err",
               "Chg_MOS_Open_Circuit_Err", "Dischg_MOS_Open_Circuit_Err"],
           5: ["AFE_Collect_Chip_Err", "Voltage_Collect_Dropped", "Cell_Temp_Sensor_Err", "EEPROM_Err", "RTC_Err",
               "Precharge_Failure", "Communication_Failure", "Internal_Communication_Failure"],
           6: ["Current_Module_Fault", "Sum_Voltage_Detect_Fault", "Short_Circuit_Protect_Fault",
               "Low_Volt_Forbidden_Chg_Fault"]}
    sigs = [bit(n, byte, b) for byte, names in flt.items() for b, n in enumerate(names)]
    sigs.append(le("Fault_Code", 7))
    msgs.append(Message(rid(0x98), "Daly_Battery_Failure_Status", 8, sigs, senders=["BMS"], is_extended_frame=True,
                        cycle_time=1000))
    db = Database(msgs, nodes=[Node("BMS"), Node("Upper_Computer")])
    db.dbc.attributes if db.dbc else None
    return db


# ============================================================== 2. EF BMS
def ef_bms():
    """EF BMS CAN Format 0.4 (EF_BMS_CAN_Format_0.4.pdf). 500 kbps, 29-bit, example BMS id ABCDEF."""
    bc_sigs = [
        comment(Signal("Load_Status", 3, 3, choices={0: "No Load", 1: "Load connected", 2: "Charger connected",
                                                     3: "Discharging", 4: "Charging"}),
                "Spec: 'Load Status = State & 0x28' - modelled as bits 3..5 of D0; verify with the BMS."),
        bit("DSG_Switch", 0, 6, choices={0: "OFF", 1: "ON"}),
        bit("CHG_Switch", 0, 7, choices={0: "OFF", 1: "ON"}),
        le("Current", 2, 16, is_signed=True, scale=0.01, unit="A", minimum=-327.68, maximum=327.67),
        le("Pack_Voltage", 4, 16, scale=0.01, unit="V", minimum=0, maximum=655.35),
    ]
    a1 = ["Short_Circuit", "Cell_Over_Volt", "Cell_Under_Volt", "Over_Current_Discharging", "Over_Temp",
          "Over_Current_Charging"]
    a2 = ["Over_Current_Cont_Discharging", "Under_Temp", "Board_Over_Temp", "Board_Under_Temp", "Cell_Conn_Broken",
          "PRL_Fault", "Cell_Diff_Fault", "Pack_OV_Fault"]
    bc_sigs += [bit(f"Alert1_{n}", 6, i) for i, n in enumerate(a1)]
    bc_sigs += [bit(f"Alert2_{n}", 7, i) for i, n in enumerate(a2)]
    broadcast = Message(0x00ABCDEF, "EF_BMS_Broadcast", 8, bc_sigs, senders=["BMS"], is_extended_frame=True,
                        cycle_time=500,
                        comment="Packet 1: pack voltage, current, state, alerts. Id = BMS id (example ABCDEF).")
    cmd = Signal("Command", 0, 8, is_multiplexer=True,
                 choices={0x06: "Temperatures", 0x0A: "Cell voltages", 0x0E: "SOH SOC cycles",
                          0x14: "Chemistry capacity", 0x36: "Balancing", 0x39: "FET control"})
    sigs = [cmd]
    sigs += [mux(le("SOH", 1, unit="%", minimum=0, maximum=100), [0x0E], "Command"),
             mux(le("SOC", 2, unit="%", minimum=0, maximum=100), [0x0E], "Command"),
             mux(le("Cycle_Count", 6, 16), [0x0E], "Command")]
    sigs.append(mux(comment(le("Temp_Info_D1", 1), "D1 of the temperature response (01 in the spec example)."),
                    [0x06], "Command"))
    sigs += [mux(le(f"Temp_T{i}", 1 + i, is_signed=True, unit="degC", minimum=-128, maximum=127), [0x06], "Command")
             for i in range(1, 7)]
    pkt = mux(Signal("Cell_Packet_No", 8, 8, is_multiplexer=True), [0x0A], "Command")
    sigs.append(pkt)
    sigs.append(mux(le("Cell_Count", 3), [0], "Cell_Packet_No"))
    for p in range(1, 8):                      # 7 packets x 3 cells = 21 (covers 15S/16S/20S)
        for k in range(3):
            n = (p - 1) * 3 + k + 1
            sigs.append(mux(le(f"Cell_{n}_Voltage", 2 + 2 * k, 16, unit="mV", minimum=0, maximum=5000), [p],
                            "Cell_Packet_No"))
    sigs.append(mux(le("Balancing_Config", 1, choices={0: "Disabled", 1: "Charging only", 2: "Charging and idle"}),
                    [0x36], "Command"))
    sigs += [mux(bit(f"Cell_{n}_Balancing", 2 + (n - 1) // 8, (n - 1) % 8), [0x36], "Command") for n in range(1, 33)]
    sigs += [mux(le("Chemistry", 1, choices={0: "NMC", 1: "NMC", 2: "LFP"}), [0x14], "Command"),
             mux(le("Capacity", 2, 16, scale=0.1, unit="Ah"), [0x14], "Command")]
    sigs.append(mux(le("FET_Control_State", 1, choices={0: "Error", 1: "OK"}), [0x39], "Command"))
    resp = Message(0x03ABCDEF, "EF_BMS_Response", 8, sigs, senders=["BMS"], is_extended_frame=True, cycle_time=200,
                   comment="Packets 2-7: responses on the request id, D0 = command. Requests (DLC 1, D0 = command) "
                           "and the FET control request (D1 Dsg FET, D2 Chg FET: 0 no change / 1 off / 2 on) use the "
                           "same id. SOH/SOC byte positions follow the spec table order (D1, D2).")
    return Database([broadcast, resp], nodes=[Node("BMS"), Node("Host")])


# ======================================================= 3. TEC V3.5 (PDF)
def tec():
    """dbc_file_1sept23.pdf - TEC BMS CAN V3.5, 250 kbps. Byte numbering in the spec is 1-based."""
    B = lambda n: n - 1                                   # noqa: E731
    msgs, cyc = [], 1000

    def cells(fid, name, names, scale=0.001, unit="V", signed=False, mn=0, mx=65.535):
        return Message(fid, name, 8, [le(nm, B(1 + 2 * i), 16, scale=scale, unit=unit, is_signed=signed, minimum=mn,
                                         maximum=mx) for i, nm in enumerate(names)],
                       senders=["BMS"], is_extended_frame=True, cycle_time=cyc)
    msgs.append(cells(0x41FFAEA, "CellVoltage1", ["C1", "C2", "C3", "C4"]))
    msgs.append(cells(0x51FFAEA, "CellVoltage2", ["C5", "C6", "C7", "C8"]))
    msgs.append(comment(cells(0x61FFAEA, "CellVoltage3", ["C9", "C10", "C11", "C12"]),
                        "Spec lists C11 twice; the 4th value is C12."))
    msgs.append(cells(0x71FFAEA, "CellVoltage4", ["C13", "C14", "C15", "C16"]))
    msgs.append(cells(0x420FAEA, "CellVoltage5", ["C17", "C18", "C19", "C20"]))
    msgs.append(cells(0x520FAEA, "CellVoltage6", ["Cavg", "Vstack", "Cvmin", "Cvmax"]))
    msgs.append(Message(0x821FAEA, "Current", 8, [
        le("CurrentCSA", 0, 16, is_signed=True, scale=0.1, unit="A", minimum=-3276.8, maximum=3276.7),
        le("CurrentAFE", 2, 16, is_signed=True, scale=0.1, unit="A", minimum=-3276.8, maximum=3276.7),
        le("SOC", B(7), unit="%", minimum=0, maximum=100), le("SOH", B(8), unit="%", minimum=0, maximum=100),
    ], senders=["BMS"], is_extended_frame=True, cycle_time=cyc))
    for fid, name, names in ((0x1422FAEA, "Temperature1", ["T1", "T2", "T3", "T4"]),
                             (0x1424FAEA, "Temperature2", ["T5", "T6", "T7", "T8"]),
                             (0x1425FAEA, "Temperature3", ["T9", "T10", "T11", "T12"]),
                             (0x1426FAEA, "Temperature4", ["T13", "T14", "Tmin", "Tmax"])):
        msgs.append(cells(fid, name, names, scale=0.01, unit="degC", signed=True, mn=-327.68, mx=327.67))
    e1 = ["FullCharge_OV", "UV", "OC", "RegenErr", "OT", "SCE", "CTO", "RDY"]
    e2 = ["TempGradErr", "VoltageGradErr", "ChargerTimeoutCutoff", "SDCardErr", "NTCFailure", "ShuntOffsetError",
          "DeepDischargeWarning"]
    e3 = {0: "CCOMER", 1: "FETERR", 2: "FETOT", 3: "SDCardErr_3", 5: "FuseFailure"}
    st = [bit(f"ES1_{n}", 0, i) for i, n in enumerate(e1)] + [bit(f"ES2_{n}", 1, i) for i, n in enumerate(e2)]
    st.append(le("VehicleState", B(3), choices={0: "Idle", 1: "Discharge", 2: "Charger0EVQ", 3: "Balancing",
                                                4: "Error", 5: "Charging_1DronePower", 6: "Charging_2GBT",
                                                7: "Charging_3Solterra"}))
    st += [bit(f"ES3_{n}", B(4), b) for b, n in e3.items()]
    st += [le("SDCardFileNo", B(5), 16), le("FANStatus", B(7), choices={0: "NoFan", 1: "FanOn", 2: "FanOff"}),
           le("CycleCount", B(8))]
    msgs.append(Message(0xC23FAEA, "State", 8, st, senders=["BMS"], is_extended_frame=True, cycle_time=cyc))
    msgs.append(Message(0x1A14FBEB, "Authentication", 8, [
        le("SWversionMajor", B(2)), le("SWversionMinor", B(3)), le("HWversionMajor", B(4)), le("HWversionMinor", B(5)),
        le("CellType", B(6)), le("RatedCapacity", B(7), unit="Ah"), le("CustomerID", B(8))],
        senders=["BMS"], is_extended_frame=True, cycle_time=cyc))
    msgs.append(Message(0xE14FBEB, "ChargeParameters", 8, [
        le("ChargeCurrentDemand", 0, 16, scale=0.1, unit="A", minimum=0, maximum=6553.5),
        le("ReserveSwitch", B(3), choices={1: "OFF", 2: "ON"}), le("ChargerError_1", B(4)), le("ChargerError_2", B(5)),
        le("CapacityActive", B(7), 16, scale=0.01, unit="Ah", minimum=0, maximum=655.35)],
        senders=["BMS"], is_extended_frame=True, cycle_time=cyc))
    msgs.append(Message(0x1914EAFA, "Battery_ID", 8, [le("Battery_ID_Raw", 0, 64)], senders=["BMS"],
                        is_extended_frame=True, cycle_time=10000,
                        comment="Spec: Byte0-7 (not decoded further)."))
    return Database(msgs, nodes=[Node("BMS")])


# ================================================ 4. River telematics PRD
def river_tel():
    """PRD for Telematics 3.6 (River) - frames transmitted by the TEL unit, CAN 2.0A."""
    def ver(fid, name, rem):
        return Message(fid, name, 8, [
            le("ECU", 0, comment="ASCII 'T' = telematics"), le("Year", 1, comment="24 = 2024"), le("Month", 2),
            le("SW_MSB", 3), le("SW_LSB", 4), le("Dot", 5, comment="ASCII '.'"), le("TEL_SW_SubVersion", 6),
            le("Vehicle_Batch", 7, choices={0x54: "T (test)", 0x50: "P (production)"})],
            senders=["TEL"], cycle_time=10000, comment=rem)
    msgs = [ver(0x703, "TEL_Controller_FW_Version", "Controller firmware version info"),
            ver(0x726, "TEL_Processor_FW_Version", "Processor firmware version info"),
            ver(0x725, "TEL_Hardware_Version", "Hardware version info"),
            Message(0x333, "TEL_Lat_Long_Signal", 8, [le("TEL_Lat_Long_Signal_Raw", 0, 64)], senders=["TEL"],
                    cycle_time=1000, comment="Lat, Long and signal strength - byte layout is defined in River DBC "
                                             "v4.20, not in the PRD; kept as a raw 64-bit value.")]
    return Database(msgs, nodes=[Node("TEL"), Node("VCU")])


# =============================================== 5. Log9 immobilization
def log9_tel():
    """Telematics Requirements V1.1 (Log9) Appendix 1 - immobilization over J1939 PDU1.
    BMU SA 0x03 (Log9_V1.1.dbc); telematics SA assumed 0xF4 (ACU in Log9_V1.1.dbc); PGNs read as hex."""
    def jid(pf, da, sa):
        return 0x18000000 | (pf << 16) | (da << 8) | sa
    req = lambda: [le("Parameter_ID", 0, 16, comment="0x04B0 = immobilization"),  # noqa: E731
                   le("Immobilization_Request", 4, choices={0: "Clear", 1: "Set"})]
    rsp = lambda: [le("Parameter_ID", 0, 16), le("Result", 3, choices={0: "Failure", 1: "Success"}),  # noqa: E731
                   le("Immobilization_Status", 4, choices={0: "Clear", 1: "Set"})]
    msgs = [
        Message(jid(0x92, 0x03, 0xF4), "TEL_Immob_Write_Request", 8, req(), senders=["TEL"], is_extended_frame=True,
                cycle_time=1000, comment="PGN 0x9200 - repeat until BMS confirms."),
        Message(jid(0x93, 0xF4, 0x03), "BMU_Immob_Write_Response", 8, rsp(), senders=["BMU"], is_extended_frame=True,
                cycle_time=1000, comment="PGN 0x9300"),
        Message(jid(0x90, 0x03, 0xF4), "TEL_Immob_Read_Request", 8, [le("Parameter_ID", 0, 16)], senders=["TEL"],
                is_extended_frame=True, cycle_time=1000, comment="PGN 0x9000"),
        Message(jid(0x91, 0xF4, 0x03), "BMU_Immob_Read_Response", 8, rsp(), senders=["BMU"], is_extended_frame=True,
                cycle_time=1000, comment="PGN 0x9100"),
    ]
    return Database(msgs, nodes=[Node("TEL"), Node("BMU")])


# ================================================= 6. EzeeInfo J1939 PGNs
EZEE_PGNS = {65266: "KMPL / Mileage (LFE1)", 65244: "Idling instances (IO)", 61445: "Gear utilization (ETC2)",
             65201: "Odometer (per sheet)", 65270: "Air filter dP / intake manifold temp (IC1)",
             64878: "DEF consumption", 65190: "Turbo boost pressure", 64777: "Engine total fuel used (LFC1)",
             65268: "Tyre pressure (TIRE)"}


def ezeeinfo(missing: list):
    """ezeeinfo_data.xlsx / ezeeinfo_parameters.xlsx list the J1939 PGNs to log. The message definitions are
    taken verbatim from the J1939 DBCs already in the library (wiman / tvs / bosch)."""
    pool = {}
    for f in sorted((LIB / "J1939_ICE").rglob("*.dbc")):
        if "_from_spec" in f.name:
            continue
        db = cantools.database.load_file(str(f), strict=False)
        for m in db.messages:
            if m.frame_id < 0x40000:           # some DBCs store the bare PGN as the id
                pgn = m.frame_id
            else:
                pgn = (m.frame_id >> 8) & 0x3FFFF
                if (pgn >> 8) & 0xFF < 0xF0:   # PDU1: destination byte is not part of the PGN
                    pgn &= 0x3FF00
            if m.signals and (pgn not in pool or len(m.signals) > len(pool[pgn].signals)):
                pool[pgn] = m
    msgs = []
    for pgn, what in EZEE_PGNS.items():
        m = pool.get(pgn)
        if m is None:
            missing.append(f"PGN {pgn} ({what})")
            continue
        clean = [_Signal(sg.name, sg.start, sg.length, byte_order=sg.byte_order, is_signed=sg.is_signed,
                         conversion=sg.conversion, minimum=sg.minimum, maximum=sg.maximum, unit=sg.unit,
                         comment=sg.comment, is_multiplexer=sg.is_multiplexer, multiplexer_ids=sg.multiplexer_ids,
                         multiplexer_signal=sg.multiplexer_signal, spn=sg.spn)
                 for sg in m.signals]           # drop vendor attributes of the source file
        print(f"    PGN {pgn:<6} {what:<45} <- {m.name} (0x{m.frame_id:X}, {len(m.signals)} signals)")
        msgs.append(Message(m.frame_id, m.name, m.length, clean, senders=m.senders,
                            is_extended_frame=m.is_extended_frame, cycle_time=m.cycle_time,
                            comment=f"EzeeInfo parameter: {what}. PGN {pgn}. Layout copied from the library "
                                    f"J1939 DBCs.", strict=False))
    return Database(msgs)


# ======================================================================
def main(src: Path):
    print(f"Converting specifications from {src}")
    missing = []
    write(daly(), "BMS", "Daly", "Daly_BMS_CAN_V1.0", src)
    write(ef_bms(), "BMS", "EF_BMS", "EF_BMS_CAN_Format_0.4", src)
    write(tec(), "BMS", "TEC_EnergyCompany", "TEC_CAN_V3.5_1Sept23", src)
    write(river_tel(), "VCU_Vehicle", "River", "River_TEL_PRD_3.6", src)
    write(log9_tel(), "BMS", "Log9", "Log9_Telematics_Immobilization_V1.1", src)
    write(ezeeinfo(missing), "J1939_ICE", "Wiman_EzeeInfo", "EzeeInfo_J1939_Parameters", src)
    if missing:
        print("  EzeeInfo PGNs not found in any library J1939 DBC:", ", ".join(missing))


if __name__ == "__main__":
    main(Path(sys.argv[1] if len(sys.argv) > 1 else r"C:\Projects\BB CAN DBC"))
