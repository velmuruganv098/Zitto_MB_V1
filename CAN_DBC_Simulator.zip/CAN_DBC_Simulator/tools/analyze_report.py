"""Print what the analyzer detects for every DBC in the library (or a filter).

    python tools/analyze_report.py            # summary for all
    python tools/analyze_report.py TEC -v     # verbose for ids containing 'TEC'
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from simulator import dbc_library                     # noqa: E402
from simulator.analyzer import analyze                # noqa: E402

flt = next((a for a in sys.argv[1:] if not a.startswith("-")), "")
verbose = "-v" in sys.argv
fails = 0
for sysinfo in dbc_library.list_library()["systems"]:
    for f in sysinfo["files"]:
        if flt.lower() not in f["id"].lower():
            continue
        try:
            ld = dbc_library.load(f["id"])
            a = analyze(ld.db, sysinfo["key"])
        except Exception as e:  # noqa: BLE001
            fails += 1
            print(f"FAIL {f['id']}: {e}")
            continue
        singles = sorted(k for k, r in a.roles.items() if r.index is None)
        print(f"{f['id']:<75} cells={len(a.cells):3d} temps={len(a.temps):3d} bal={len(a.balance):3d} "
              f"panels={','.join(a.panels)}")
        if verbose:
            for k in singles:
                r = a.roles[k]
                print(f"    {k:<20} [{r.minimum:g}..{r.maximum:g} {r.unit}] {r.kind:<6} <- "
                      + ", ".join(f"{b.msg}.{b.sig}" + (f"*{b.factor:g}" if b.factor != 1 else "")
                                  for b in r.bindings[:4]) + (" ..." if len(r.bindings) > 4 else ""))
            for rk in a.cells[:40]:
                r = a.roles[rk]
                print(f"    {rk:<16} {r.source} x{r.bindings[0].factor:g} [{r.minimum:g}..{r.maximum:g}]")
            for rk in a.temps[:24]:
                print(f"    {rk:<16} {a.roles[rk].source}")
print("failures:", fails)
