"""Bump the simulator version and open a CHANGELOG / REVISION_NOTES entry.

    python tools/bump_version.py 1.1.0 "Short title of the change"

Then create the matching branch (same convention as the firmware repo):
    git checkout -b dev/sim-v1.1.0_Short_Title
"""
import datetime
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main():
    if len(sys.argv) < 3 or not re.fullmatch(r"\d+\.\d+\.\d+", sys.argv[1]):
        sys.exit(__doc__)
    new, title = sys.argv[1], " ".join(sys.argv[2:])
    old = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    (ROOT / "VERSION").write_text(new + "\n", encoding="utf-8")
    today = datetime.date.today().isoformat()

    cl = ROOT / "CHANGELOG.md"
    text = cl.read_text(encoding="utf-8")
    entry = f"## [{new}] - {today}\n### {title}\n- \n\n"
    text = text.replace("## [", entry + "## [", 1)
    cl.write_text(text, encoding="utf-8")

    rn = ROOT / "REVISION_NOTES.md"
    notes = rn.read_text(encoding="utf-8")
    branch = "dev/sim-v" + new + "_" + re.sub(r"\W+", "_", title).strip("_")
    block = (f"## V{new}\nBase: V{old}\nBranch: {branch}\n\n### Issue\n- \n\n### Updates\n- \n\n### Files\n- \n\n")
    notes = notes.replace("\n## V", "\n" + block + "## V", 1)
    rn.write_text(notes, encoding="utf-8")
    print(f"{old} -> {new}\nsuggested branch: {branch}")


if __name__ == "__main__":
    main()
